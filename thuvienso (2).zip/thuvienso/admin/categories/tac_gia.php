<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";   

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$base_url = "../../";
$page_title = "Quản lý Tác giả";

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {

        $action = $_POST['action'] ?? '';

        if ($action === 'add') {
            $ma      = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
            $ten     = trim($_POST['ten'] ?? '');
            $mapb    = !empty($_POST['mapb']) ? $_POST['mapb'] : null;
            $hocvi   = trim($_POST['hocvi'] ?? '');
            $chucvu  = trim($_POST['chucvu'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');

            $stmt = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, MaPB, HocVi, ChucVu, Email, SoDienThoai) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $ma, $ten, $mapb, $hocvi, $chucvu, $email, $sdt);
            if ($stmt->execute()) {
                $msg = "Đã thêm tác giả <b>" . htmlspecialchars($ma) . "</b>!";
                $msg_type = 'success';

                ghi_log($conn, 'CREATE',
                    "Thêm tác giả $ten ($ma)",
                    'tac_gia', $ma);
            }
            $stmt->close();

        }
        elseif ($action === 'edit') {
            $id      = $_POST['id'] ?? '';
            $ten     = trim($_POST['ten'] ?? '');
            $mapb    = !empty($_POST['mapb']) ? $_POST['mapb'] : null;
            $hocvi   = trim($_POST['hocvi'] ?? '');
            $chucvu  = trim($_POST['chucvu'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');

            $stmt = $conn->prepare("UPDATE tac_gia SET HoTen=?, MaPB=?, HocVi=?, ChucVu=?, Email=?, SoDienThoai=? WHERE MaTG=?");
            $stmt->bind_param("sssssss", $ten, $mapb, $hocvi, $chucvu, $email, $sdt, $id);
            if ($stmt->execute()) {
                $msg = "Đã cập nhật tác giả <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = 'success';
                ghi_log($conn, 'UPDATE',
                    "Cập nhật tác giả $id ($ten)",
                    'tac_gia', $id);
            }
            $stmt->close();

        }
        elseif ($action === 'delete') {
            $id = $_POST['id'] ?? '';
            $stmt_info = $conn->prepare("SELECT HoTen FROM tac_gia WHERE MaTG=? LIMIT 1");
            $stmt_info->bind_param("s", $id);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            $stmt = $conn->prepare("DELETE FROM tac_gia WHERE MaTG=?");
            $stmt->bind_param("s", $id);
            if ($stmt->execute()) {
                $msg = "Đã xóa tác giả <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = 'success';
                $ten_tg = $info['HoTen'] ?? $id;
                ghi_log($conn, 'DELETE',
                    "Xóa tác giả $id ($ten_tg)",
                    'tac_gia', $id);

            } else {
                $msg = "Không thể xóa, tác giả đang có tài liệu liên kết!";
                $msg_type = 'danger';
            }
            $stmt->close();

        }
        elseif ($action === 'delete_multi') {
            $ids = $_POST['ids'] ?? [];
            $success = 0; $failed = 0;
            $deleted_ids = [];

            foreach ($ids as $id) {
                $stmt = $conn->prepare("DELETE FROM tac_gia WHERE MaTG=?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $success++;
                    $deleted_ids[] = $id;
                } else {
                    $failed++;
                }
                $stmt->close();
            }

            $msg = "Đã xóa <b>$success</b> tác giả" . ($failed ? ", <b>$failed</b> lỗi!" : "!");
            $msg_type = $failed ? 'warning' : 'success';
            if ($success > 0) {
                $ids_str = implode(', ', array_slice($deleted_ids, 0, 5));
                if (count($deleted_ids) > 5) {
                    $ids_str .= '... (và ' . (count($deleted_ids) - 5) . ' tác giả khác)';
                }
                ghi_log($conn, 'DELETE',
                    "Bulk xóa $success tác giả: $ids_str",
                    'tac_gia', '');
            }
        }
    }
}

$res = $conn->query("
    SELECT tg.*, pb.TenPhongBan
    FROM tac_gia tg
    LEFT JOIN phong_ban pb ON tg.MaPB = pb.MaPB
    ORDER BY tg.NgayTao DESC
");
$count_q = $res ? $res->num_rows : 0;

$pb_list = $conn->query("SELECT MaPB, TenPhongBan FROM phong_ban WHERE TrangThai=1 ORDER BY TenPhongBan");

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Tác giả</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Tác giả</h1>
                <p>Quản lý danh sách tác giả và giảng viên</p>
            </div>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#475569;">
                <i class="fa-solid fa-plus-circle" style="color:#2563eb;"></i> Thêm Tác giả mới
            </h3>
            <form method="POST" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="add">
                <input type="text"  name="ten"    placeholder="Họ tên tác giả..." required style="flex:1; min-width:180px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="text"  name="hocvi"  placeholder="Học vị..." style="width:100px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="text"  name="chucvu" placeholder="Chức vụ..." style="width:110px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <select name="mapb" style="width:180px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                    <option value="">-- Chọn Khoa --</option>
                    <?php $pb_list->data_seek(0); while ($pb = $pb_list->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($pb['MaPB']) ?>"><?= htmlspecialchars($pb['TenPhongBan']) ?></option>
                    <?php endwhile; ?>
                </select>
                <input type="email" name="email" placeholder="Email..." style="flex:1; min-width:150px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="text"  name="sdt"   placeholder="SĐT..." style="width:110px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm mới
                </button>
            </form>
        </div>

        <div class="toolbar">
            <input type="text" placeholder="Tìm tác giả..." onkeyup="filterTable('tableTacGia', this.value)">
            <button type="button" class="btn btn-danger btn-sm" onclick="deleteSelected('tableTacGia', 'tác giả')">
                <i class="fa-solid fa-trash"></i> Xóa đã chọn (<span id="countTacGia">0</span>)
            </button>
        </div>

        <div class="table-wrap">
            <form method="POST" id="formTacGia">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="delete_multi">
                <table class="data-table" id="tableTacGia">
                    <thead>
                        <tr>
                            <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this, 'tableTacGia')"></th>
                            <th style="width:100px;">Mã TG</th>
                            <th>Họ và Tên</th>
                            <th>Khoa</th>
                            <th>Học vị</th>
                            <th>Chức vụ</th>
                            <th>Email</th>
                            <th>SĐT</th>
                            <th style="width:140px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0):
                            while ($r = $res->fetch_assoc()):
                                $json = htmlspecialchars(json_encode([
                                    "MaTG" => $r["MaTG"],
                                    "HoTen" => $r["HoTen"],
                                    "MaPB" => $r["MaPB"],
                                    "HocVi" => $r["HocVi"],
                                    "ChucVu" => $r["ChucVu"],
                                    "Email" => $r["Email"],
                                    "SoDienThoai" => $r["SoDienThoai"]
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= htmlspecialchars($r['MaTG']) ?>" class="row-checkbox" data-table="tableTacGia"></td>
                                <td><span class="code-badge"><?= htmlspecialchars($r['MaTG']) ?></span></td>
                                <td><b><?= htmlspecialchars($r['HoTen']) ?></b></td>
                                <td><?= htmlspecialchars($r['TenPhongBan'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['HocVi'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['ChucVu'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['Email'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['SoDienThoai'] ?? '—') ?></td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)'><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($r['MaTG'], ENT_QUOTES) ?>', 'tác giả')"><i class="fa-solid fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr class="empty-row"><td colspan="9"><i class="fa-regular fa-user"></i> Chưa có tác giả nào.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <div class="table-footer" style="margin-top:14px;">
            <span>Tổng: <b><?= (int)$count_q ?></b> tác giả</span>
        </div>

    </main>
</div>

<div class="modal-backdrop" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Sửa Tác giả</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="modalId">
            <div class="modal-body">
                <div class="form-group">
                    <label>Họ tên <span class="required">*</span></label>
                    <input type="text" name="ten" id="m_ten" required>
                </div>
                <div class="form-group">
                    <label>Khoa</label>
                    <select name="mapb" id="m_mapb">
                        <option value="">-- Chưa chọn --</option>
                        <?php $pb_list->data_seek(0); while ($pb = $pb_list->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($pb['MaPB']) ?>"><?= htmlspecialchars($pb['TenPhongBan']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Học vị</label>
                    <input type="text" name="hocvi" id="m_hocvi">
                </div>
                <div class="form-group">
                    <label>Chức vụ</label>
                    <input type="text" name="chucvu" id="m_chucvu">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="m_email">
                </div>
                <div class="form-group">
                    <label>SĐT</label>
                    <input type="text" name="sdt" id="m_sdt">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function toggleAll(masterCb, tableId) {
    document.querySelectorAll('#' + tableId + ' .row-checkbox').forEach(cb => cb.checked = masterCb.checked);
    updateCount(tableId);
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', () => updateCount(cb.dataset.table));
    });
});
function updateCount(tableId) {
    const count = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked').length;
    const el = document.getElementById('count' + tableId.replace('table', ''));
    if (el) el.textContent = count;
}
function deleteSelected(tableId, typeName) {
    const checked = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked');
    if (checked.length === 0) {
        Swal.fire({ icon: 'info', title: 'Chưa chọn gì', text: 'Vui lòng chọn ít nhất 1 dòng!', confirmButtonColor: '#2563eb' });
        return;
    }
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Bạn sắp xóa <b>' + checked.length + '</b> ' + typeName,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) document.getElementById('form' + tableId.replace('table', '')).submit();
    });
}
function confirmDelete(id, typeName) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Xóa ' + typeName + ' <b>' + escapeHtml(id) + '</b>?',
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
function openEditModal(data) {
    document.getElementById('modalId').value = data.MaTG || '';
    document.getElementById('m_ten').value = data.HoTen || '';
    document.getElementById('m_mapb').value = data.MaPB || '';
    document.getElementById('m_hocvi').value = data.HocVi || '';
    document.getElementById('m_chucvu').value = data.ChucVu || '';
    document.getElementById('m_email').value = data.Email || '';
    document.getElementById('m_sdt').value = data.SoDienThoai || '';
    document.getElementById('editModal').classList.add('show');
}
function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); });
});
function filterTable(tableId, keyword) {
    const kw = keyword.toLowerCase().trim();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
        if (row.classList.contains('empty-row')) return;
        row.style.display = (!kw || row.textContent.toLowerCase().includes(kw)) ? '' : 'none';
    });
}
</script>

<?php include "../../includes/footer.php"; ?>