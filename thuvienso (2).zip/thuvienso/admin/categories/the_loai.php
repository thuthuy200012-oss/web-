<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$base_url = "../../";
$page_title = "Quản lý Thể loại";
$current_page = 'the-loai';

$msg = '';
$msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ!";
        $msg_type = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $ten_loai   = trim($_POST['ten_loai'] ?? '');
            $slug       = trim($_POST['slug'] ?? '');
            $mo_ta      = trim($_POST['mo_ta'] ?? '');
            $thu_tu     = (int)($_POST['thu_tu'] ?? 0);
            $trang_thai = isset($_POST['trang_thai']) ? 1 : 0;

            if (empty($ten_loai)) {
                $msg = "Vui lòng nhập tên thể loại!";
                $msg_type = 'danger';
            } else {
                $ma_loai = generate_unique_id($conn, 'loaitailieu', 'MaLoai', 'L');

                if (empty($slug)) {
                    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $ten_loai));
                }

                $stmt = $conn->prepare("
                    INSERT INTO loaitailieu (MaLoai, TenLoai, Slug, MoTa, ThuTu, TrangThai)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("ssssii", $ma_loai, $ten_loai, $slug, $mo_ta, $thu_tu, $trang_thai);

                if ($stmt->execute()) {
                    ghi_log($conn, 'CREATE', "Thêm thể loại: $ten_loai ($ma_loai)", 'loaitailieu', $ma_loai);
                    $_SESSION['flash_msg'] = "Đã thêm thể loại <b>$ten_loai</b>!";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: the_loai.php");
                    exit();
                } else {
                    error_log("the_loai add error: " . $conn->error);
                    $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'edit') {
            $ma_loai    = $_POST['ma_loai'] ?? '';
            $ten_loai   = trim($_POST['ten_loai'] ?? '');
            $slug       = trim($_POST['slug'] ?? '');
            $mo_ta      = trim($_POST['mo_ta'] ?? '');
            $thu_tu     = (int)($_POST['thu_tu'] ?? 0);
            $trang_thai = isset($_POST['trang_thai']) ? 1 : 0;

            if (empty($ten_loai)) {
                $msg = "Vui lòng nhập tên thể loại!";
                $msg_type = 'danger';
            } else {
                $stmt = $conn->prepare("
                    UPDATE loaitailieu
                    SET TenLoai=?, Slug=?, MoTa=?, ThuTu=?, TrangThai=?
                    WHERE MaLoai=?
                ");
                $stmt->bind_param("sssiss", $ten_loai, $slug, $mo_ta, $thu_tu, $trang_thai, $ma_loai);

                if ($stmt->execute()) {
                    ghi_log($conn, 'UPDATE', "Cập nhật thể loại: $ten_loai ($ma_loai)", 'loaitailieu', $ma_loai);
                    $_SESSION['flash_msg'] = "Đã cập nhật thể loại <b>$ten_loai</b>!";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: the_loai.php");
                    exit();
                } else {
                    error_log("the_loai edit error: " . $conn->error);
                    $msg = "Đã xảy ra lỗi!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'delete') {
            $ma_loai = $_POST['ma_loai'] ?? '';

            $stmt_info = $conn->prepare("SELECT TenLoai FROM loaitailieu WHERE MaLoai=? LIMIT 1");
            $stmt_info->bind_param("s", $ma_loai);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            if ($info) {
                $stmt_check = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE LoaiTaiLieu = ?");
                $stmt_check->bind_param("s", $info['TenLoai']);
                $stmt_check->execute();
                $count_used = $stmt_check->get_result()->fetch_assoc()['c'] ?? 0;
                $stmt_check->close();

                if ($count_used > 0) {
                    $msg = "Không thể xóa! Có <b>$count_used</b> tài liệu đang dùng thể loại này.";
                    $msg_type = 'danger';
                } else {
                    $stmt = $conn->prepare("DELETE FROM loaitailieu WHERE MaLoai=?");
                    $stmt->bind_param("s", $ma_loai);
                    if ($stmt->execute()) {
                        ghi_log($conn, 'DELETE', "Xóa thể loại: {$info['TenLoai']} ($ma_loai)", 'loaitailieu', $ma_loai);
                        $_SESSION['flash_msg'] = "Đã xóa thể loại!";
                        $_SESSION['flash_type'] = 'success';
                    } else {
                        $_SESSION['flash_msg'] = "Không thể xóa!";
                        $_SESSION['flash_type'] = 'danger';
                    }
                    $stmt->close();
                    header("Location: the_loai.php");
                    exit();
                }
            }
        }
    }
}

$msg = $_SESSION['flash_msg'] ?? $msg;
$msg_type = $_SESSION['flash_type'] ?? $msg_type;
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);
$per_page = 10;
$page     = max(1, (int)($_GET['page'] ?? 1));
$offset   = ($page - 1) * $per_page;

$total_loai = $conn->query("SELECT COUNT(*) AS c FROM loaitailieu")->fetch_assoc()['c'] ?? 0;
$total_pages = max(1, ceil($total_loai / $per_page));

if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $per_page;

$list = $conn->query("
    SELECT l.*, 
           (SELECT COUNT(*) FROM tai_lieu WHERE LoaiTaiLieu = l.TenLoai) AS SoTaiLieu
    FROM loaitailieu l
    ORDER BY l.ThuTu ASC, l.TenLoai ASC
    LIMIT $per_page OFFSET $offset
");

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    .categories-layout .card,
    .categories-layout .card *,
    .categories-layout input,
    .categories-layout select,
    .categories-layout textarea,
    .categories-layout button,
    .categories-layout .btn,
    .categories-layout .btn-icon {
        border-radius: 0 !important;
    }

    .categories-list table,
    .categories-list thead th,
    .categories-list tbody td,
    .data-table,
    .data-table th,
    .data-table td {
        border-radius: 0 !important;
    }

    .badge,
    .code-badge {
        border-radius: 0 !important;
    }

    .pagination,
    .page-btn {
        border-radius: 0 !important;
    }

    .form-hint {
        border-radius: 0 !important;
    }

    .categories-layout {
        display: grid;
        grid-template-columns: 1fr 380px;
        gap: 20px;
        align-items: start;
    }
    @media (max-width: 1024px) {
        .categories-layout {
            grid-template-columns: 1fr;
        }
    }

    /* Pagination style */
    .pagination {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-top: 24px;
        flex-wrap: wrap;
    }
    .page-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 40px;
        height: 40px;
        padding: 0 12px;
        background: #fff;
        border: 1px solid #e2e8f0;
        color: #475569;
        font-weight: 600;
        font-size: 14px;
        text-decoration: none;
        transition: all 0.2s;
    }
    .page-btn:hover {
        background: #f0fdf4;
        border-color: #16a34a;
        color: #16a34a;
    }
    .page-btn.active {
        background: #16a34a;
        border-color: #16a34a;
        color: #fff;
    }
    .page-btn.disabled {
        opacity: 0.4;
        pointer-events: none;
    }
</style>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Thể loại</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Thể loại</h1>
                <p>Quản lý các thể loại tài liệu (Giáo trình, Luận văn, Đề tài NCKH...)</p>
            </div>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="categories-layout">
            <div class="categories-list">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tên thể loại</th>
                            <th>Slug</th>
                            <th>Thứ tự</th>
                            <th>Trạng thái</th>
                            <th>Số tài liệu</th>
                            <th style="width:100px;">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($list && $list->num_rows > 0): ?>
                            <?php while ($r = $list->fetch_assoc()): ?>
                                <tr>
                                    <td><b><?= htmlspecialchars($r['TenLoai']) ?></b></td>
                                    <td><code><?= htmlspecialchars($r['Slug'] ?? '—') ?></code></td>
                                    <td><?= (int)$r['ThuTu'] ?></td>
                                    <td>
                                        <?php if (!empty($r['TrangThai'])): ?>
                                            <span class="badge badge-success">Hoạt động</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Ẩn</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><b><?= (int)$r['SoTaiLieu'] ?></b></td>
                                    <td>
                                        <div class="actions">
                                            <button type="button" class="btn-icon btn-edit"
                                                data-ma="<?= htmlspecialchars($r['MaLoai'], ENT_QUOTES) ?>"
                                                data-ten="<?= htmlspecialchars($r['TenLoai'], ENT_QUOTES) ?>"
                                                data-slug="<?= htmlspecialchars($r['Slug'] ?? '', ENT_QUOTES) ?>"
                                                data-mota="<?= htmlspecialchars($r['MoTa'] ?? '', ENT_QUOTES) ?>"
                                                data-thutu="<?= (int)$r['ThuTu'] ?>"
                                                data-trangthai="<?= (int)($r['TrangThai'] ?? 0) ?>"
                                                onclick="editItem(this)">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button type="button" class="btn-icon btn-del"
                                                onclick="confirmDelete('<?= htmlspecialchars($r['MaLoai'], ENT_QUOTES) ?>', '<?= htmlspecialchars($r['TenLoai'], ENT_QUOTES) ?>')">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr class="empty-row">
                                <td colspan="6">Chưa có thể loại nào</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php
                        $qs = $_GET;
                        $qs['page'] = max(1, $page - 1);
                        ?>
                        <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page <= 1 ? 'disabled' : '' ?>">‹</a>

                        <?php
                        $start = max(1, $page - 2);
                        $end   = min($total_pages, $page + 2);
                        if ($start > 1) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                        for ($i = $start; $i <= $end; $i++):
                            $qs['page'] = $i;
                        ?>
                            <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                        <?php endfor;
                        if ($end < $total_pages) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                        ?>

                        <?php $qs['page'] = min($total_pages, $page + 1); ?>
                        <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page >= $total_pages ? 'disabled' : '' ?>">›</a>
                    </div>

                    <div style="text-align: center; margin-top: 12px; color: #64748b; font-size: 13px;">
                        Trang <b><?= $page ?></b> / <b><?= $total_pages ?></b> — Tổng <b><?= $total_loai ?></b> thể loại
                    </div>
                <?php endif; ?>
            </div>
            <div class="categories-form">
                <div class="card" style="padding: 20px;">
                    <h3 id="formTitle" style="margin:0 0 16px; font-size:15px; color:#0f172a;">
                        <i class="fa-solid fa-plus-circle" style="color:#16a34a;"></i> Thêm thể loại mới
                    </h3>
                    <form method="POST" id="categoryForm">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="ma_loai" id="formMaLoai" value="">

                        <div class="form-group">
                            <label>Tên thể loại <span style="color:red;">*</span></label>
                            <input type="text" name="ten_loai" id="formTenLoai" required placeholder="VD: Giáo trình">
                        </div>

                        <div class="form-group">
                            <label>Slug</label>
                            <input type="text" name="slug" id="formSlug" placeholder="Để trống để tự sinh">
                        </div>

                        <div class="form-group">
                            <label>Mô tả</label>
                            <textarea name="mo_ta" id="formMoTa" rows="3" placeholder="Mô tả ngắn..."></textarea>
                        </div>

                        <div class="form-group">
                            <label>Thứ tự hiển thị</label>
                            <input type="number" name="thu_tu" id="formThuTu" value="0" min="0">
                        </div>

                        <div class="form-group">
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                <input type="checkbox" name="trang_thai" id="formTrangThai" value="1" checked>
                                Hoạt động
                            </label>
                        </div>

                        <div style="display:flex; gap:10px;">
                            <button type="submit" class="btn btn-primary" id="submitBtn" style="flex:1;">
                                <i class="fa-solid fa-plus"></i> Thêm mới
                            </button>
                            <button type="button" class="btn btn-secondary" id="cancelBtn" style="display:none;" onclick="cancelEdit()">
                                <i class="fa-solid fa-xmark"></i> Hủy
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </main>
</div>
<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="ma_loai" id="deleteMaLoai">
</form>

<script>
function editItem(btn) {
    const ma = btn.getAttribute('data-ma');
    const ten = btn.getAttribute('data-ten');
    const slug = btn.getAttribute('data-slug');
    const mota = btn.getAttribute('data-mota');
    const thutu = btn.getAttribute('data-thutu');
    const trangthai = btn.getAttribute('data-trangthai');

    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-pen" style="color:#f59e0b;"></i> Sửa thể loại';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('formMaLoai').value = ma;
    document.getElementById('formTenLoai').value = ten;
    document.getElementById('formSlug').value = slug;
    document.getElementById('formMoTa').value = mota;
    document.getElementById('formThuTu').value = thutu;
    document.getElementById('formTrangThai').checked = (trangthai == 1);

    document.getElementById('submitBtn').innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Cập nhật';
    document.getElementById('cancelBtn').style.display = 'inline-flex';

    document.getElementById('categoryForm').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function cancelEdit() {
    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-plus-circle" style="color:#16a34a;"></i> Thêm thể loại mới';
    document.getElementById('formAction').value = 'add';
    document.getElementById('formMaLoai').value = '';
    document.getElementById('formTenLoai').value = '';
    document.getElementById('formSlug').value = '';
    document.getElementById('formMoTa').value = '';
    document.getElementById('formThuTu').value = 0;
    document.getElementById('formTrangThai').checked = true;

    document.getElementById('submitBtn').innerHTML = '<i class="fa-solid fa-plus"></i> Thêm mới';
    document.getElementById('cancelBtn').style.display = 'none';
}

function confirmDelete(ma, ten) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa thể loại <b>${ten}</b>?`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteMaLoai').value = ma;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include "../../includes/footer.php"; ?>