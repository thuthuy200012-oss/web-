<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$base_url = "../../";
$page_title = "Quản lý Ngành";
$current_page = 'nganh';
$msg = '';
$msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ!";
        $msg_type = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        $make_slug = function($str) {
            $str = mb_strtolower($str, 'UTF-8');
            $str = preg_replace('/[áàảãạăắằẳẵặâấầẩẫậ]/u', 'a', $str);
            $str = preg_replace('/[éèẻẽẹêếềểễệ]/u', 'e', $str);
            $str = preg_replace('/[íìỉĩị]/u', 'i', $str);
            $str = preg_replace('/[óòỏõọôốồổỗộơớờởỡợ]/u', 'o', $str);
            $str = preg_replace('/[úùủũụưứừửữự]/u', 'u', $str);
            $str = preg_replace('/[ýỳỷỹỵ]/u', 'y', $str);
            $str = preg_replace('/[đ]/u', 'd', $str);
            $str = preg_replace('/[^a-z0-9]+/', '-', $str);
            return trim($str, '-');
        };
        if ($action === 'add') {
            $ten_nganh  = trim($_POST['ten_nganh'] ?? '');
            $ma_pb      = trim($_POST['ma_pb'] ?? '');
            $slug       = trim($_POST['slug'] ?? '');

            if (empty($ten_nganh)) {
                $msg = "Vui lòng nhập tên ngành!";
                $msg_type = 'danger';
            } else {
                $ma_nganh = generate_unique_id($conn, 'nganh', 'MaNganh', 'N');
                if ($ma_pb === '') $ma_pb = null;
                if ($slug === '') $slug = $make_slug($ten_nganh);

                $stmt = $conn->prepare("
                    INSERT INTO nganh (MaNganh, TenNganh, MaPB, Slug)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->bind_param("ssss", $ma_nganh, $ten_nganh, $ma_pb, $slug);

                if ($stmt->execute()) {
                    ghi_log($conn, 'CREATE', "Thêm ngành: $ten_nganh ($ma_nganh)", 'nganh', $ma_nganh);
                    $_SESSION['flash_msg'] = "Đã thêm ngành <b>$ten_nganh</b>!";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: nganh.php");
                    exit();
                } else {
                    error_log("nganh add error: " . $conn->error);
                    $msg = "Đã xảy ra lỗi!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'edit') {
            $ma_nganh   = $_POST['ma_nganh'] ?? '';
            $ten_nganh  = trim($_POST['ten_nganh'] ?? '');
            $ma_pb      = trim($_POST['ma_pb'] ?? '');
            $slug       = trim($_POST['slug'] ?? '');

            if (empty($ten_nganh)) {
                $msg = "Vui lòng nhập tên ngành!";
                $msg_type = 'danger';
            } else {
                if ($ma_pb === '') $ma_pb = null;
                if ($slug === '') $slug = $make_slug($ten_nganh);

                $stmt = $conn->prepare("
                    UPDATE nganh
                    SET TenNganh=?, MaPB=?, Slug=?
                    WHERE MaNganh=?
                ");
                $stmt->bind_param("ssss", $ten_nganh, $ma_pb, $slug, $ma_nganh);

                if ($stmt->execute()) {
                    ghi_log($conn, 'UPDATE', "Cập nhật ngành: $ten_nganh ($ma_nganh)", 'nganh', $ma_nganh);
                    $_SESSION['flash_msg'] = "Đã cập nhật ngành <b>$ten_nganh</b>!";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: nganh.php");
                    exit();
                } else {
                    $msg = "Đã xảy ra lỗi!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'delete') {
            $ma_nganh = $_POST['ma_nganh'] ?? '';

            $stmt_check = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE MaNganh=?");
            $stmt_check->bind_param("s", $ma_nganh);
            $stmt_check->execute();
            $count_used = $stmt_check->get_result()->fetch_assoc()['c'] ?? 0;
            $stmt_check->close();

            if ($count_used > 0) {
                $msg = "Không thể xóa! Có <b>$count_used</b> tài liệu thuộc ngành này.";
                $msg_type = 'danger';
            } else {
                $stmt = $conn->prepare("DELETE FROM nganh WHERE MaNganh=?");
                $stmt->bind_param("s", $ma_nganh);
                if ($stmt->execute()) {
                    ghi_log($conn, 'DELETE', "Xóa ngành: $ma_nganh", 'nganh', $ma_nganh);
                    $_SESSION['flash_msg'] = "Đã xóa ngành!";
                    $_SESSION['flash_type'] = 'success';
                } else {
                    $_SESSION['flash_msg'] = "Không thể xóa!";
                    $_SESSION['flash_type'] = 'danger';
                }
                $stmt->close();
                header("Location: nganh.php");
                exit();
            }
        }
    }
}

$msg = $_SESSION['flash_msg'] ?? $msg;
$msg_type = $_SESSION['flash_type'] ?? $msg_type;
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);

$list = $conn->query("
    SELECT n.*, p.TenPhongBan,
           (SELECT COUNT(*) FROM tai_lieu WHERE MaNganh = n.MaNganh) AS SoTaiLieu
    FROM nganh n
    LEFT JOIN phong_ban p ON n.MaPB = p.MaPB
    ORDER BY n.TenNganh ASC
");
$pb_list = [];
$res_pb = $conn->query("SELECT MaPB, TenPhongBan FROM phong_ban ORDER BY TenPhongBan");
if ($res_pb) {
    while ($pb = $res_pb->fetch_assoc()) {
        $pb_list[] = $pb;
    }
}

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Ngành</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Ngành</h1>
                <p>Quản lý các ngành học thuộc các khoa/phòng ban</p>
            </div>
        </div>
        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="categories-layout">
            <div class="categories-list">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tên ngành</th>
                            <th>Khoa</th>
                            <th>Slug</th>
                            <th style="width:100px;">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($list && $list->num_rows > 0): ?>
                            <?php while ($r = $list->fetch_assoc()): ?>
                                <tr>
                                    <td><b><?= htmlspecialchars($r['TenNganh']) ?></b></td>
                                    <td><?= htmlspecialchars($r['TenPhongBan'] ?? '—') ?></td>
                                    <td><code><?= htmlspecialchars($r['Slug'] ?? '—') ?></code></td>
                                    <td>
                                        <div class="actions">
                                            <button type="button" class="btn-icon btn-edit"
                                                data-ma="<?= htmlspecialchars($r['MaNganh'], ENT_QUOTES) ?>"
                                                data-ten="<?= htmlspecialchars($r['TenNganh'], ENT_QUOTES) ?>"
                                                data-mapb="<?= htmlspecialchars($r['MaPB'] ?? '', ENT_QUOTES) ?>"
                                                data-slug="<?= htmlspecialchars($r['Slug'] ?? '', ENT_QUOTES) ?>"
                                                onclick="editItem(this)">
                                                <i class="fa-solid fa-pen"></i>
                                            </button>
                                            <button type="button" class="btn-icon btn-del"
                                                onclick="confirmDelete('<?= htmlspecialchars($r['MaNganh'], ENT_QUOTES) ?>', '<?= htmlspecialchars($r['TenNganh'], ENT_QUOTES) ?>')">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr class="empty-row"><td colspan="4">Chưa có ngành nào</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="categories-form">
                <div class="card" style="padding: 20px;">
                    <h3 id="formTitle" style="margin:0 0 16px; font-size:15px; color:#0f172a;">
                        <i class="fa-solid fa-plus-circle" style="color:#16a34a;"></i> Thêm ngành mới
                    </h3>
                    <form method="POST" id="categoryForm">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="ma_nganh" id="formMaNganh" value="">

                        <div class="form-group">
                            <label>Tên ngành <span style="color:red;">*</span></label>
                            <input type="text" name="ten_nganh" id="formTenNganh" required placeholder="VD: Công nghệ thông tin">
                        </div>

                        <div class="form-group">
                            <label>Khoa</label>
                            <select name="ma_pb" id="formMaPB">
                                <option value="">-- Chọn khoa --</option>
                                <?php foreach ($pb_list as $pb): ?>
                                    <option value="<?= htmlspecialchars($pb['MaPB']) ?>">
                                        <?= htmlspecialchars($pb['TenPhongBan']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Slug</label>
                            <input type="text" name="slug" id="formSlug" placeholder="Để trống để tự sinh">
                        </div>

                        <div style="display:flex; gap:10px;">
                            <button type="submit" class="btn btn-primary" id="submitBtn" style="flex:1;">
                                <i class="fa-solid fa-plus"></i> Thêm mới
                            </button>
                            <button type="button" class="btn btn-secondary" id="cancelBtn" style="display:none;" onclick="cancelEdit()">
                                <i class="fa-solid fa-xmark"></i> Hủy
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>

    </main>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="ma_nganh" id="deleteMaNganh">
</form>

<script>
function editItem(btn) {
    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-pen" style="color:#f59e0b;"></i> Sửa ngành';
    document.getElementById('formAction').value = 'edit';
    document.getElementById('formMaNganh').value = btn.getAttribute('data-ma');
    document.getElementById('formTenNganh').value = btn.getAttribute('data-ten');
    document.getElementById('formMaPB').value = btn.getAttribute('data-mapb');
    document.getElementById('formSlug').value = btn.getAttribute('data-slug');

    document.getElementById('submitBtn').innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Cập nhật';
    document.getElementById('cancelBtn').style.display = 'inline-flex';
    document.getElementById('categoryForm').scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function cancelEdit() {
    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-plus-circle" style="color:#16a34a;"></i> Thêm ngành mới';
    document.getElementById('formAction').value = 'add';
    document.getElementById('formMaNganh').value = '';
    document.getElementById('formTenNganh').value = '';
    document.getElementById('formMaPB').value = '';
    document.getElementById('formSlug').value = '';

    document.getElementById('submitBtn').innerHTML = '<i class="fa-solid fa-plus"></i> Thêm mới';
    document.getElementById('cancelBtn').style.display = 'none';
}

function confirmDelete(ma, ten) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa ngành <b>${ten}</b>?`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteMaNganh').value = ma;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include "../../includes/footer.php"; ?>