<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$base_url = "../../";
$page_title = "Quản lý Từ khóa";
$current_page = 'tu-khoa';

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ!";
        $msg_type = 'danger';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'add') {
            $ten_tk = trim($_POST['ten_tk'] ?? '');
            $mo_ta  = trim($_POST['mo_ta'] ?? '');

            if (empty($ten_tk)) {
                $msg = "Vui lòng nhập tên từ khóa!";
                $msg_type = 'danger';
            } else {
                $stmt_check = $conn->prepare("SELECT MaTK FROM tukhoa WHERE LOWER(TenTuKhoa) = LOWER(?) LIMIT 1");
                $stmt_check->bind_param("s", $ten_tk);
                $stmt_check->execute();
                $exists = $stmt_check->get_result()->num_rows > 0;
                $stmt_check->close();

                if ($exists) {
                    $msg = "Từ khóa <b>$ten_tk</b> đã tồn tại!";
                    $msg_type = 'warning';
                } else {
                    $ma_tk = generate_unique_id($conn, 'tukhoa', 'MaTK', 'TK');
                    $stmt = $conn->prepare("INSERT INTO tukhoa (MaTK, TenTuKhoa, MoTa) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $ma_tk, $ten_tk, $mo_ta);

                    if ($stmt->execute()) {
                        ghi_log($conn, 'CREATE', "Thêm từ khóa: $ten_tk ($ma_tk)", 'tukhoa', $ma_tk);
                        $_SESSION['flash_msg'] = "Đã thêm từ khóa <b>$ten_tk</b>!";
                        $_SESSION['flash_type'] = 'success';
                        header("Location: tu_khoa.php");
                        exit();
                    } else {
                        $msg = "Đã xảy ra lỗi!";
                        $msg_type = 'danger';
                    }
                    $stmt->close();
                }
            }
        }
        elseif ($action === 'delete') {
            $ma_tk = $_POST['ma_tk'] ?? '';

            $stmt = $conn->prepare("DELETE FROM tukhoa WHERE MaTK=?");
            $stmt->bind_param("s", $ma_tk);

            if ($stmt->execute()) {
                ghi_log($conn, 'DELETE', "Xóa từ khóa: $ma_tk", 'tukhoa', $ma_tk);
                $_SESSION['flash_msg'] = "Đã xóa từ khóa!";
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_msg'] = "Không thể xóa!";
                $_SESSION['flash_type'] = 'danger';
            }
            $stmt->close();
            header("Location: tu_khoa.php");
            exit();
        }
    }
}

$msg = $_SESSION['flash_msg'] ?? $msg;
$msg_type = $_SESSION['flash_type'] ?? $msg_type;
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);
$list = $conn->query("
    SELECT tk.MaTK, tk.TenTuKhoa, tk.MoTa,
           (
               SELECT COUNT(*)
               FROM tai_lieu tl
               WHERE tl.TrangThai = 'Đã duyệt'
                 AND (
                     tl.TuKhoa LIKE CONCAT('%', tk.TenTuKhoa, '%')
                 )
           ) AS SoLanDung
    FROM tukhoa tk
    ORDER BY SoLanDung DESC, tk.TenTuKhoa ASC
");

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Từ khóa</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Từ khóa</h1>
                <p>Quản lý các từ khóa dùng để tìm kiếm và phân loại tài liệu</p>
            </div>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="categories-layout">
            <div class="categories-list">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Từ khóa</th>
                            <th style="width:140px; text-align:center;">Số lần dùng</th>
                            <th style="width:100px;">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($list && $list->num_rows > 0): ?>
                            <?php while ($r = $list->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <span style="display:inline-block; background:#f1f5f9; color:#475569; padding:6px 14px; border-radius:6px; font-weight:700; font-size:12px; letter-spacing:0.5px; text-transform:uppercase;">
                                            <?= htmlspecialchars($r['TenTuKhoa']) ?>
                                        </span>
                                    </td>
                                    <td style="text-align:center; font-weight:700; color:#0c1e3e; font-size:15px;">
                                        <?= (int)($r['SoLanDung'] ?? 0) ?>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button type="button" class="btn-icon btn-del"
                                                onclick="confirmDelete('<?= htmlspecialchars($r['MaTK'], ENT_QUOTES) ?>', '<?= htmlspecialchars($r['TenTuKhoa'], ENT_QUOTES) ?>')">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr class="empty-row">
                                <td colspan="3" style="text-align:center; padding:40px; color:#94a3b8;">
                                    Chưa có từ khóa nào
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="categories-form">
                <div class="card" style="padding: 20px;">
                    <h3 style="margin:0 0 16px; font-size:15px; color:#0f172a;">
                        <i class="fa-solid fa-plus-circle" style="color:#16a34a;"></i> Thêm từ khóa mới
                    </h3>
                    <form method="POST">
                        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                        <input type="hidden" name="action" value="add">

                        <div class="form-group">
                            <label>Tên từ khóa <span style="color:red;">*</span></label>
                            <input type="text" name="ten_tk" required
                                   placeholder="VD: Tình Bình Thuận"
                                   maxlength="150"
                                   style="width:100%; padding:11px 14px; border:1.5px solid #cbd5e1; border-radius:9px; font-size:14px;">
                        </div>

                        <div class="form-group" style="margin-top:16px;">
                            <label>Mô tả (nếu có)</label>
                            <textarea name="mo_ta" rows="3" placeholder="Mô tả ngắn..."
                                      style="width:100%; padding:11px 14px; border:1.5px solid #cbd5e1; border-radius:9px; font-size:14px; resize:vertical;"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:16px;">
                            <i class="fa-solid fa-plus"></i> Thêm mới
                        </button>
                    </form>
                </div>
            </div>

        </div>

    </main>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="ma_tk" id="deleteMaTK">
</form>

<script>
function confirmDelete(ma, ten) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa từ khóa <b>${ten}</b>?`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteMaTK').value = ma;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php include "../../includes/footer.php"; ?>