<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$base_url = "../../";
$page_title = "Quản lý Năm học";

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {

        $action = $_POST['action'] ?? '';

        if ($action === 'add') {
            $ma   = taoMa($conn, 'namhoc', 'MaNam', 'NH');
            $ten  = trim($_POST['ten'] ?? '');
            $bd   = (int)($_POST['batdau'] ?? 0);
            $kt   = (int)($_POST['ketthuc'] ?? 0);

            if ($ten !== '' && $bd > 0 && $kt > 0) {
                if ($bd >= $kt) {
                    $msg = "Năm bắt đầu phải nhỏ hơn năm kết thúc!";
                    $msg_type = 'warning';
                } else {
                    $stmt = $conn->prepare("INSERT INTO namhoc (MaNam, TenNam, NamBatDau, NamKetThuc) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssii", $ma, $ten, $bd, $kt);
                    if ($stmt->execute()) {
                        $msg = "Đã thêm năm học <b>" . htmlspecialchars($ma) . "</b>!";
                        $msg_type = 'success';
                        ghi_log($conn, 'CREATE', "Thêm năm học $ten ($bd-$kt)", 'namhoc', $ma);
                    } else {
                        error_log("nam_hoc add SQL Error: " . $conn->error);
                        $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                        $msg_type = 'danger';
                    }
                    $stmt->close();
                }
            } else {
                $msg = "Vui lòng nhập đầy đủ thông tin!";
                $msg_type = 'warning';
            }
        }
        elseif ($action === 'edit') {
            $id   = $_POST['id'] ?? '';
            $ten  = trim($_POST['ten'] ?? '');
            $bd   = (int)($_POST['batdau'] ?? 0);
            $kt   = (int)($_POST['ketthuc'] ?? 0);

            if ($bd >= $kt) {
                $msg = "Năm bắt đầu phải nhỏ hơn năm kết thúc!";
                $msg_type = 'warning';
            } else {
                $stmt = $conn->prepare("UPDATE namhoc SET TenNam=?, NamBatDau=?, NamKetThuc=? WHERE MaNam=?");
                $stmt->bind_param("siis", $ten, $bd, $kt, $id);
                if ($stmt->execute()) {
                    $msg = "Đã cập nhật năm học <b>" . htmlspecialchars($id) . "</b>!";
                    $msg_type = 'success';
                    ghi_log($conn, 'UPDATE', "Cập nhật năm học $id ($ten - $bd-$kt)", 'namhoc', $id);
                } else {
                    error_log("nam_hoc edit SQL Error: " . $conn->error);
                    $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'delete') {
            $id = $_POST['id'] ?? '';

            $has_ref = false;
            $check = $conn->query("SHOW COLUMNS FROM tai_lieu LIKE 'MaNam'");
            if ($check && $check->num_rows > 0) {
                $stmt_check = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE MaNam = ?");
                $stmt_check->bind_param("s", $id);
                $stmt_check->execute();
                $has_ref = ($stmt_check->get_result()->fetch_assoc()['c'] ?? 0) > 0;
                $stmt_check->close();
            }

            if ($has_ref) {
                $msg = "Không thể xóa! Có tài liệu đang thuộc năm học này.";
                $msg_type = 'danger';
            } else {
                $stmt_info = $conn->prepare("SELECT TenNam FROM namhoc WHERE MaNam=? LIMIT 1");
                $stmt_info->bind_param("s", $id);
                $stmt_info->execute();
                $info = $stmt_info->get_result()->fetch_assoc();
                $stmt_info->close();

                $stmt = $conn->prepare("DELETE FROM namhoc WHERE MaNam=?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $msg = "Đã xóa năm học <b>" . htmlspecialchars($id) . "</b>!";
                    $msg_type = 'success';
                    $ten_nh = $info['TenNam'] ?? $id;
                    ghi_log($conn, 'DELETE', "Xóa năm học $id ($ten_nh)", 'namhoc', $id);
                } else {
                    error_log("nam_hoc delete SQL Error: " . $conn->error);
                    $msg = "Không thể xóa năm học!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'delete_multi') {
            $ids = $_POST['ids'] ?? [];
            $success = 0; $failed = 0;
            $deleted_ids = [];

            foreach ($ids as $id) {
                $stmt = $conn->prepare("DELETE FROM namhoc WHERE MaNam=?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $success++;
                    $deleted_ids[] = $id;
                } else {
                    $failed++;
                }
                $stmt->close();
            }

            $msg = "Đã xóa <b>$success</b> năm học" . ($failed ? ", <b>$failed</b> lỗi!" : "!");
            $msg_type = $failed ? 'warning' : 'success';

            if ($success > 0) {
                $ids_str = implode(', ', array_slice($deleted_ids, 0, 5));
                if (count($deleted_ids) > 5) {
                    $ids_str .= '... (và ' . (count($deleted_ids) - 5) . ' năm học khác)';
                }
                ghi_log($conn, 'DELETE', "Bulk xóa $success năm học: $ids_str", 'namhoc', '');
            }
        }
    }
}
$per_page = 15;
$page     = max(1, (int)($_GET['page'] ?? 1));
$offset   = ($page - 1) * $per_page;

$total_nh = $conn->query("SELECT COUNT(*) AS c FROM namhoc")->fetch_assoc()['c'] ?? 0;
$total_pages = max(1, ceil($total_nh / $per_page));

if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $per_page;
$has_manam_col = false;
$check_col = $conn->query("SHOW COLUMNS FROM tai_lieu LIKE 'MaNam'");
if ($check_col && $check_col->num_rows > 0) {
    $has_manam_col = true;
}

if ($has_manam_col) {
    $res = $conn->query("
        SELECT nh.*,
               (SELECT COUNT(*) FROM tai_lieu WHERE MaNam = nh.MaNam AND TrangThai = 'Đã duyệt') AS SoTaiLieu
        FROM namhoc nh
        ORDER BY nh.NamBatDau DESC
        LIMIT $per_page OFFSET $offset
    ");
} else {
    $res = $conn->query("
        SELECT nh.*, 0 AS SoTaiLieu
        FROM namhoc nh
        ORDER BY nh.NamBatDau DESC
        LIMIT $per_page OFFSET $offset
    ");
}
$count_q = $total_nh;

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    .main .card,
    .main .card *,
    .main input,
    .main select,
    .main textarea,
    .main button,
    .main .btn,
    .main .btn-icon,
    .main .badge,
    .main .code-badge,
    .main .data-table,
    .main .data-table th,
    .main .data-table td,
    .main .table-wrap,
    .main .modal-content,
    .main .modal-content *,
    .main .page-btn,
    .main .pagination,
    .main .alert {
        border-radius: 0 !important;
    }

    /* Pagination style */
    .pagination {
        display: flex;
        justify-content: center;
        gap: 6px;
        margin-top: 24px;
        flex-wrap: wrap;
    }
    .page-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 40px;
        height: 40px;
        padding: 0 12px;
        background: #fff;
        border: 1px solid #e2e8f0;
        color: #475569;
        font-weight: 600;
        font-size: 14px;
        text-decoration: none;
        transition: all 0.2s;
    }
    .page-btn:hover {
        background: #f0fdf4;
        border-color: #16a34a;
        color: #16a34a;
    }
    .page-btn.active {
        background: #16a34a;
        border-color: #16a34a;
        color: #fff;
    }
    .page-btn.disabled {
        opacity: 0.4;
        pointer-events: none;
    }
</style>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Năm học</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Năm học</h1>
                <p>Quản lý danh sách năm học và năm xuất bản tài liệu</p>
            </div>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#475569;">
                <i class="fa-solid fa-plus-circle" style="color:#2563eb;"></i> Thêm năm học mới
            </h3>
            <form method="POST" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="add">
                <input type="text" name="ten" placeholder="VD: Năm học 2026-2027..." required style="flex:1; min-width:250px; padding:10px 14px; border:1.5px solid #cbd5e1; font-size:14px;">
                <input type="number" name="batdau" placeholder="Năm bắt đầu" required min="2000" max="2100" style="width:150px; padding:10px 14px; border:1.5px solid #cbd5e1; font-size:14px;">
                <input type="number" name="ketthuc" placeholder="Năm kết thúc" required min="2000" max="2100" style="width:150px; padding:10px 14px; border:1.5px solid #cbd5e1; font-size:14px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm mới
                </button>
            </form>
        </div>

        <div class="toolbar">
            <input type="text" placeholder="Tìm năm học..." onkeyup="filterTable('tableNamHoc', this.value)">
            <button type="button" class="btn btn-danger btn-sm" onclick="deleteSelected('tableNamHoc', 'năm học')">
                <i class="fa-solid fa-trash"></i> Xóa đã chọn (<span id="countNamHoc">0</span>)
            </button>
        </div>

        <div class="table-wrap">
            <form method="POST" id="formNamHoc">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="delete_multi">
                <table class="data-table" id="tableNamHoc">
                    <thead>
                        <tr>
                            <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this, 'tableNamHoc')"></th>
                            <th style="width:100px;">Mã</th>
                            <th>Tên năm học</th>
                            <th style="width:130px;">Năm bắt đầu</th>
                            <th style="width:130px;">Năm kết thúc</th>
                            <th style="width:130px;">Số tài liệu</th>
                            <th style="width:140px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0):
                            while ($r = $res->fetch_assoc()):
                                $json = htmlspecialchars(json_encode([
                                    "MaNam" => $r["MaNam"],
                                    "TenNam" => $r["TenNam"],
                                    "NamBatDau" => $r["NamBatDau"],
                                    "NamKetThuc" => $r["NamKetThuc"]
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= htmlspecialchars($r['MaNam']) ?>" class="row-checkbox" data-table="tableNamHoc"></td>
                                <td><span class="code-badge"><?= htmlspecialchars($r['MaNam']) ?></span></td>
                                <td><b><?= htmlspecialchars($r['TenNam']) ?></b></td>
                                <td><span class="badge badge-info"><?= (int)$r['NamBatDau'] ?></span></td>
                                <td><span class="badge badge-info"><?= (int)$r['NamKetThuc'] ?></span></td>
                                <td>
                                    <?php if ($has_manam_col): ?>
                                        <span class="badge badge-success"><?= (int)$r['SoTaiLieu'] ?></span>
                                    <?php else: ?>
                                        <span style="color:#94a3b8;">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)'><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($r['MaNam'], ENT_QUOTES) ?>', 'năm học')"><i class="fa-solid fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr class="empty-row"><td colspan="7"><i class="fa-regular fa-calendar"></i> Chưa có năm học nào.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php
                $qs = $_GET;
                $qs['page'] = max(1, $page - 1);
                ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page <= 1 ? 'disabled' : '' ?>">‹</a>

                <?php
                $start = max(1, $page - 2);
                $end   = min($total_pages, $page + 2);
                if ($start > 1) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                for ($i = $start; $i <= $end; $i++):
                    $qs['page'] = $i;
                ?>
                    <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor;
                if ($end < $total_pages) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                ?>

                <?php $qs['page'] = min($total_pages, $page + 1); ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page >= $total_pages ? 'disabled' : '' ?>">›</a>
            </div>

            <div style="text-align: center; margin-top: 12px; color: #64748b; font-size: 13px;">
                Trang <b><?= $page ?></b> / <b><?= $total_pages ?></b> — Tổng <b><?= $total_nh ?></b> năm học
            </div>
        <?php endif; ?>

        <div class="table-footer" style="margin-top:14px;">
            <span>Hiển thị <b><?= $res ? $res->num_rows : 0 ?></b> / <b><?= $count_q ?></b> năm học</span>
        </div>

    </main>
</div>

<div class="modal-backdrop" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Sửa Năm học</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="modalId">
            <div class="modal-body">
                <div class="form-group">
                    <label>Tên năm học <span class="required">*</span></label>
                    <input type="text" name="ten" id="m_ten" required>
                </div>
                <div class="form-group">
                    <label>Năm bắt đầu <span class="required">*</span></label>
                    <input type="number" name="batdau" id="m_batdau" required min="2000" max="2100">
                </div>
                <div class="form-group">
                    <label>Năm kết thúc <span class="required">*</span></label>
                    <input type="number" name="ketthuc" id="m_ketthuc" required min="2000" max="2100">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function toggleAll(masterCb, tableId) {
    document.querySelectorAll('#' + tableId + ' .row-checkbox').forEach(cb => cb.checked = masterCb.checked);
    updateCount(tableId);
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', () => updateCount(cb.dataset.table));
    });
});
function updateCount(tableId) {
    const count = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked').length;
    const el = document.getElementById('count' + tableId.replace('table', ''));
    if (el) el.textContent = count;
}
function deleteSelected(tableId, typeName) {
    const checked = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked');
    if (checked.length === 0) {
        Swal.fire({ icon: 'info', title: 'Chưa chọn gì', text: 'Vui lòng chọn ít nhất 1 dòng!', confirmButtonColor: '#2563eb' });
        return;
    }
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Bạn sắp xóa <b>' + checked.length + '</b> ' + typeName,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) document.getElementById('form' + tableId.replace('table', '')).submit();
    });
}
function confirmDelete(id, typeName) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Xóa ' + typeName + ' <b>' + escapeHtml(id) + '</b>?',
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
function openEditModal(data) {
    document.getElementById('modalId').value = data.MaNam || '';
    document.getElementById('m_ten').value = data.TenNam || '';
    document.getElementById('m_batdau').value = data.NamBatDau || '';
    document.getElementById('m_ketthuc').value = data.NamKetThuc || '';
    document.getElementById('editModal').classList.add('show');
}
function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); });
});
function filterTable(tableId, keyword) {
    const kw = keyword.toLowerCase().trim();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
        if (row.classList.contains('empty-row')) return;
        row.style.display = (!kw || row.textContent.toLowerCase().includes(kw)) ? '' : 'none';
    });
}
</script>

<?php include "../../includes/footer.php"; ?>