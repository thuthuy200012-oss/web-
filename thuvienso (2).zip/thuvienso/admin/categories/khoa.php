<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";  
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$base_url = "../../";
$page_title = "Quản lý Khoa";
$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {

        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $ma      = taoMa($conn, 'phong_ban', 'MaPB', 'PB');
            $ten     = trim($_POST['ten'] ?? '');
            $viettat = trim($_POST['viettat'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');
            $stmt = $conn->prepare("INSERT INTO phong_ban (MaPB, TenPhongBan, TenVietTat, Email, SoDienThoai) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $ma, $ten, $viettat, $email, $sdt);
            if ($stmt->execute()) {
                $msg = "Đã thêm khoa <b>" . htmlspecialchars($ma) . "</b>!";
                $msg_type = 'success';
                ghi_log($conn, 'CREATE',
                    "Thêm khoa/phòng ban $ten ($ma)",
                    'phong_ban', $ma);
            }
            $stmt->close();

        }
        elseif ($action === 'edit') {
            $id      = $_POST['id'] ?? '';
            $ten     = trim($_POST['ten'] ?? '');
            $viettat = trim($_POST['viettat'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');
            $stmt = $conn->prepare("UPDATE phong_ban SET TenPhongBan=?, TenVietTat=?, Email=?, SoDienThoai=? WHERE MaPB=?");
            $stmt->bind_param("sssss", $ten, $viettat, $email, $sdt, $id);
            if ($stmt->execute()) {
                $msg = "Đã cập nhật khoa <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = 'success';
                ghi_log($conn, 'UPDATE',
                    "Cập nhật khoa/phòng ban $id ($ten)",
                    'phong_ban', $id);
            }
            $stmt->close();

        }
        elseif ($action === 'delete') {
            $id = $_POST['id'] ?? '';
            $stmt_info = $conn->prepare("SELECT TenPhongBan FROM phong_ban WHERE MaPB=? LIMIT 1");
            $stmt_info->bind_param("s", $id);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();
            $stmt = $conn->prepare("DELETE FROM phong_ban WHERE MaPB=?");
            $stmt->bind_param("s", $id);
            if ($stmt->execute()) {
                $msg = "Đã xóa khoa <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = 'success';
                $ten_pb = $info['TenPhongBan'] ?? $id;
                ghi_log($conn, 'DELETE',
                    "Xóa khoa/phòng ban $id ($ten_pb)",
                    'phong_ban', $id);

            } else {
                $msg = "Không thể xóa, khoa đang có dữ liệu liên kết!";
                $msg_type = 'danger';
            }
            $stmt->close();

        }
        elseif ($action === 'delete_multi') {
            $ids = $_POST['ids'] ?? [];
            $success = 0; $failed = 0;
            $deleted_ids = [];   
            foreach ($ids as $id) {
                $stmt = $conn->prepare("DELETE FROM phong_ban WHERE MaPB=?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $success++;
                    $deleted_ids[] = $id;   
                } else {
                    $failed++;
                }
                $stmt->close();
            }

            $msg = "Đã xóa <b>$success</b> khoa" . ($failed ? ", <b>$failed</b> lỗi!" : "!");
            $msg_type = $failed ? 'warning' : 'success';
            if ($success > 0) {
                $ids_str = implode(', ', array_slice($deleted_ids, 0, 5));
                if (count($deleted_ids) > 5) {
                    $ids_str .= '... (và ' . (count($deleted_ids) - 5) . ' khoa khác)';
                }
                ghi_log($conn, 'DELETE',
                    "Bulk xóa $success khoa/phòng ban: $ids_str",
                    'phong_ban', '');
            }
        }
    }
}

$res = $conn->query("
    SELECT pb.*,
           (SELECT COUNT(*) FROM tac_gia WHERE MaPB = pb.MaPB) AS SoTacGia
    FROM phong_ban pb
    ORDER BY pb.NgayTao DESC
");
$count_q = $res ? $res->num_rows : 0;

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Khoa</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Khoa / Phòng ban</h1>
                <p>Quản lý danh sách khoa và phòng ban</p>
            </div>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#475569;">
                <i class="fa-solid fa-plus-circle" style="color:#2563eb;"></i> Thêm Khoa mới
            </h3>
            <form method="POST" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="add">
                <input type="text"  name="ten"     placeholder="Tên Khoa..." required style="flex:1; min-width:220px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="text"  name="viettat" placeholder="Viết tắt..." style="width:120px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="email" name="email"   placeholder="Email..." style="flex:1; min-width:180px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <input type="text"  name="sdt"     placeholder="SĐT..." style="width:130px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm mới
                </button>
            </form>
        </div>

        <div class="toolbar">
            <input type="text" placeholder="Tìm khoa..." onkeyup="filterTable('tableKhoa', this.value)">
            <button type="button" class="btn btn-danger btn-sm" onclick="deleteSelected('tableKhoa', 'khoa')">
                <i class="fa-solid fa-trash"></i> Xóa đã chọn (<span id="countKhoa">0</span>)
            </button>
        </div>

        <div class="table-wrap">
            <form method="POST" id="formKhoa">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="delete_multi">
                <table class="data-table" id="tableKhoa">
                    <thead>
                        <tr>
                            <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this, 'tableKhoa')"></th>
                            <th style="width:100px;">Mã PB</th>
                            <th>Tên Khoa</th>
                            <th>Viết tắt</th>
                            <th>Email</th>
                            <th>SĐT</th>
                            <th style="width:100px;">Số GV</th>
                            <th style="width:140px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0):
                            while ($r = $res->fetch_assoc()):
                                $json = htmlspecialchars(json_encode([
                                    "MaPB" => $r["MaPB"],
                                    "TenPhongBan" => $r["TenPhongBan"],
                                    "TenVietTat" => $r["TenVietTat"],
                                    "Email" => $r["Email"],
                                    "SoDienThoai" => $r["SoDienThoai"]
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= htmlspecialchars($r['MaPB']) ?>" class="row-checkbox" data-table="tableKhoa"></td>
                                <td><span class="code-badge"><?= htmlspecialchars($r['MaPB']) ?></span></td>
                                <td><b><?= htmlspecialchars($r['TenPhongBan']) ?></b></td>
                                <td><?= htmlspecialchars($r['TenVietTat'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['Email'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['SoDienThoai'] ?? '—') ?></td>
                                <td><span class="badge badge-info"><?= (int)$r['SoTacGia'] ?></span></td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)'><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($r['MaPB'], ENT_QUOTES) ?>', 'khoa')"><i class="fa-solid fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr class="empty-row"><td colspan="8"><i class="fa-regular fa-building"></i> Chưa có khoa nào.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <div class="table-footer" style="margin-top:14px;">
            <span>Tổng: <b><?= (int)$count_q ?></b> khoa / phòng ban</span>
        </div>

    </main>
</div>

<div class="modal-backdrop" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Sửa Khoa</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="modalId">
            <div class="modal-body">
                <div class="form-group">
                    <label>Tên khoa <span class="required">*</span></label>
                    <input type="text" name="ten" id="m_ten" required>
                </div>
                <div class="form-group">
                    <label>Viết tắt</label>
                    <input type="text" name="viettat" id="m_viettat">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="m_email">
                </div>
                <div class="form-group">
                    <label>SĐT</label>
                    <input type="text" name="sdt" id="m_sdt">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function toggleAll(masterCb, tableId) {
    document.querySelectorAll('#' + tableId + ' .row-checkbox').forEach(cb => cb.checked = masterCb.checked);
    updateCount(tableId);
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', () => updateCount(cb.dataset.table));
    });
});
function updateCount(tableId) {
    const count = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked').length;
    const el = document.getElementById('count' + tableId.replace('table', ''));
    if (el) el.textContent = count;
}
function deleteSelected(tableId, typeName) {
    const checked = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked');
    if (checked.length === 0) {
        Swal.fire({ icon: 'info', title: 'Chưa chọn gì', text: 'Vui lòng chọn ít nhất 1 dòng!', confirmButtonColor: '#2563eb' });
        return;
    }
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Bạn sắp xóa <b>' + checked.length + '</b> ' + typeName,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) document.getElementById('form' + tableId.replace('table', '')).submit();
    });
}
function confirmDelete(id, typeName) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Xóa ' + typeName + ' <b>' + escapeHtml(id) + '</b>?',
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
function openEditModal(data) {
    document.getElementById('modalId').value = data.MaPB || '';
    document.getElementById('m_ten').value = data.TenPhongBan || '';
    document.getElementById('m_viettat').value = data.TenVietTat || '';
    document.getElementById('m_email').value = data.Email || '';
    document.getElementById('m_sdt').value = data.SoDienThoai || '';
    document.getElementById('editModal').classList.add('show');
}
function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); });
});
function filterTable(tableId, keyword) {
    const kw = keyword.toLowerCase().trim();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
        if (row.classList.contains('empty-row')) return;
        row.style.display = (!kw || row.textContent.toLowerCase().includes(kw)) ? '' : 'none';
    });
}
</script>

<?php include "../../includes/footer.php"; ?>