<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$base_url = "../../";
$page_title = "Quản lý Danh mục";
$msg = '';
$msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $ma      = taoMa($conn, 'danh_muc', 'MaDM', 'DM');
            $ten     = trim($_POST['ten'] ?? '');
            $madmcha = !empty($_POST['madmcha']) ? $_POST['madmcha'] : null;
            $mota    = trim($_POST['mota'] ?? '');

            if ($ten !== '') {
                $stmt = $conn->prepare("INSERT INTO danh_muc (MaDM, TenDanhMuc, MaDMCha, MoTa) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $ma, $ten, $madmcha, $mota);
                if ($stmt->execute()) {
                    $msg = "Đã thêm danh mục <b>" . htmlspecialchars($ma) . "</b>!";
                    $msg_type = 'success';
                    ghi_log($conn, 'CREATE', "Thêm danh mục $ten ($ma)", 'danh_muc', $ma);
                } else {
                    error_log("danh_muc add SQL Error: " . $conn->error);
                    $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            } else {
                $msg = "Vui lòng nhập tên danh mục!";
                $msg_type = 'danger';
            }
        }
        elseif ($action === 'edit') {
            $id      = $_POST['id'] ?? '';
            $ten     = trim($_POST['ten'] ?? '');
            $madmcha = !empty($_POST['madmcha']) ? $_POST['madmcha'] : null;
            $mota    = trim($_POST['mota'] ?? '');

            $stmt = $conn->prepare("UPDATE danh_muc SET TenDanhMuc=?, MaDMCha=?, MoTa=? WHERE MaDM=?");
            $stmt->bind_param("ssss", $ten, $madmcha, $mota, $id);
            if ($stmt->execute()) {
                $msg = "Đã cập nhật danh mục <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = 'success';
                ghi_log($conn, 'UPDATE', "Cập nhật danh mục $id ($ten)", 'danh_muc', $id);
            } else {
                error_log("danh_muc edit SQL Error: " . $conn->error);
                $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                $msg_type = 'danger';
            }
            $stmt->close();
        }
        elseif ($action === 'delete') {
            $id = $_POST['id'] ?? '';

            $stmt_info = $conn->prepare("SELECT TenDanhMuc FROM danh_muc WHERE MaDM=? LIMIT 1");
            $stmt_info->bind_param("s", $id);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            $ten_dm = $info['TenDanhMuc'] ?? $id;

            $stmt_check = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE MaDM = ?");
            $stmt_check->bind_param("s", $id);
            $stmt_check->execute();
            $so_tai_lieu = $stmt_check->get_result()->fetch_assoc()['c'] ?? 0;
            $stmt_check->close();
            if ($so_tai_lieu > 0) {
                $msg = "Không thể xóa danh mục <b>" . htmlspecialchars($ten_dm) . "</b>!<br>"
                     . "Danh mục này đang có <b>$so_tai_lieu</b> tài liệu.";
                $msg_type = 'danger';
            } else {
                $stmt_check_con = $conn->prepare("SELECT COUNT(*) AS c FROM danh_muc WHERE MaDMCha = ?");
                $stmt_check_con->bind_param("s", $id);
                $stmt_check_con->execute();
                $so_danh_muc_con = $stmt_check_con->get_result()->fetch_assoc()['c'] ?? 0;
                $stmt_check_con->close();

                if ($so_danh_muc_con > 0) {
                    $msg = "Không thể xóa danh mục <b>" . htmlspecialchars($ten_dm) . "</b>!<br>"
                         . "Danh mục này đang có <b>$so_danh_muc_con</b> danh mục con.";
                    $msg_type = 'danger';
                } else {
                    $stmt = $conn->prepare("DELETE FROM danh_muc WHERE MaDM=?");
                    $stmt->bind_param("s", $id);
                    if ($stmt->execute()) {
                        $msg = "Đã xóa danh mục <b>" . htmlspecialchars($ten_dm) . "</b>!";
                        $msg_type = 'success';
                        ghi_log($conn, 'DELETE', "Xóa danh mục $id ($ten_dm)", 'danh_muc', $id);
                    } else {
                        error_log("danh_muc delete SQL Error: " . $conn->error);
                        $msg = "Không thể xóa danh mục. Vui lòng thử lại!";
                        $msg_type = 'danger';
                    }
                    $stmt->close();
                }
            }
        }
        elseif ($action === 'delete_multi') {
            $ids = $_POST['ids'] ?? [];
            $success = 0;
            $failed = 0;
            $failed_details = [];

            foreach ($ids as $id) {
                $stmt_info = $conn->prepare("
                    SELECT dm.TenDanhMuc,
                           (SELECT COUNT(*) FROM tai_lieu WHERE MaDM = dm.MaDM) AS SoTaiLieu,
                           (SELECT COUNT(*) FROM danh_muc WHERE MaDMCha = dm.MaDM) AS SoDanhMucCon
                    FROM danh_muc dm
                    WHERE dm.MaDM = ?
                    LIMIT 1
                ");
                $stmt_info->bind_param("s", $id);
                $stmt_info->execute();
                $info = $stmt_info->get_result()->fetch_assoc();
                $stmt_info->close();

                if (!$info) {
                    $failed++;
                    continue;
                }
                $ten_dm = $info['TenDanhMuc'] ?? $id;

                if ($info['SoTaiLieu'] > 0) {
                    $failed++;
                    $failed_details[] = "$ten_dm ({$info['SoTaiLieu']} tài liệu)";
                    continue;
                }
                if ($info['SoDanhMucCon'] > 0) {
                    $failed++;
                    $failed_details[] = "$ten_dm ({$info['SoDanhMucCon']} danh mục con)";
                    continue;
                }
                $stmt = $conn->prepare("DELETE FROM danh_muc WHERE MaDM=?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $success++;
                    ghi_log($conn, 'DELETE', "Xóa danh mục $id ($ten_dm)", 'danh_muc', $id);
                } else {
                    error_log("danh_muc delete_multi SQL Error: " . $conn->error . " | MaDM: $id");
                    $failed++;
                    $failed_details[] = "$ten_dm (lỗi hệ thống)";
                }
                $stmt->close();
            }
            if ($success > 0 && $failed == 0) {
                $msg = "Đã xóa <b>$success</b> danh mục!";
                $msg_type = 'success';
            } elseif ($success > 0 && $failed > 0) {
                $msg = "Đã xóa <b>$success</b> danh mục, <b>$failed</b> danh mục không thể xóa:<br>"
                     . "• " . implode('<br>• ', array_slice($failed_details, 0, 5));
                if (count($failed_details) > 5) {
                    $msg .= '<br>• ... và ' . (count($failed_details) - 5) . ' danh mục khác';
                }
                $msg_type = 'warning';
            } else {
                $msg = "Không thể xóa danh mục nào!<br>"
                     . "Lý do:<br>• " . implode('<br>• ', array_slice($failed_details, 0, 5));
                if (count($failed_details) > 5) {
                    $msg .= '<br>• ... và ' . (count($failed_details) - 5) . ' danh mục khác';
                }
                $msg_type = 'danger';
            }
        }
    }
}
$per_page = 15;
$page     = max(1, (int)($_GET['page'] ?? 1));
$offset   = ($page - 1) * $per_page;
$stats = [];
$stats['tai_lieu'] = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu")->fetch_assoc()['c'] ?? 0;
$total_dm = $conn->query("SELECT COUNT(*) AS c FROM danh_muc")->fetch_assoc()['c'] ?? 0;
$total_pages = max(1, ceil($total_dm / $per_page));
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $per_page;

$res = $conn->query("
    SELECT dm.*, cha.TenDanhMuc AS TenDanhMucCha,
           (SELECT COUNT(*) FROM tai_lieu WHERE MaDM = dm.MaDM) AS SoTaiLieu
    FROM danh_muc dm
    LEFT JOIN danh_muc cha ON dm.MaDMCha = cha.MaDM
    ORDER BY dm.NgayTao DESC
    LIMIT $per_page OFFSET $offset
");
$count_q = $total_dm;

$dm_options = [['value' => '', 'label' => '-- Không có --']];
$res_dm_opt = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc ORDER BY TenDanhMuc");
while ($row = $res_dm_opt->fetch_assoc()) {
    $dm_options[] = ['value' => $row['MaDM'], 'label' => $row['TenDanhMuc']];
}
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý Danh mục</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Danh mục Tài liệu</h1>
                <p>Quản lý danh mục phân loại tài liệu</p>
            </div>
        </div>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="card" style="padding: 20px; margin-bottom: 20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#475569;">
                <i class="fa-solid fa-plus-circle" style="color:#2563eb;"></i> Thêm danh mục mới
            </h3>
            <form method="POST" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="add">
                <input type="text" name="ten" placeholder="Tên danh mục..." required style="flex:1; min-width:220px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <select name="madmcha" style="width:200px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                    <option value="">-- Không có cha --</option>
                    <?php
                    $res_cha = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");
                    while ($dmc = $res_cha->fetch_assoc()):
                    ?>
                        <option value="<?= htmlspecialchars($dmc['MaDM']) ?>"><?= htmlspecialchars($dmc['TenDanhMuc']) ?></option>
                    <?php endwhile; ?>
                </select>
                <input type="text" name="mota" placeholder="Mô tả..." style="flex:1; min-width:220px; padding:10px 14px; border:1.5px solid #cbd5e1; border-radius:8px; font-size:14px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Thêm mới
                </button>
            </form>
        </div>

        <div class="toolbar">
            <input type="text" placeholder="Tìm danh mục..." onkeyup="filterTable('tableDanhMuc', this.value)">
            <button type="button" class="btn btn-danger btn-sm" onclick="deleteSelected('tableDanhMuc', 'danh mục')">
                <i class="fa-solid fa-trash"></i> Xóa đã chọn (<span id="countDanhMuc">0</span>)
            </button>
        </div>

        <div class="table-wrap">
            <form method="POST" id="formDanhMuc">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="action" value="delete_multi">
                <table class="data-table" id="tableDanhMuc">
                    <thead>
                        <tr>
                            <th style="width:40px;"><input type="checkbox" onclick="toggleAll(this, 'tableDanhMuc')"></th>
                            <th style="width:100px;">Mã DM</th>
                            <th>Tên danh mục</th>
                            <th>Danh mục cha</th>
                            <th>Mô tả</th>
                            <th style="width:100px;">Số tài liệu</th>
                            <th style="width:140px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res && $res->num_rows > 0):
                            while ($r = $res->fetch_assoc()):
                                $json = htmlspecialchars(json_encode([
                                    "MaDM" => $r["MaDM"],
                                    "TenDanhMuc" => $r["TenDanhMuc"],
                                    "MaDMCha" => $r["MaDMCha"],
                                    "MoTa" => $r["MoTa"]
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                                $so_tl = (int)$r['SoTaiLieu'];
                        ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= htmlspecialchars($r['MaDM']) ?>" class="row-checkbox" data-table="tableDanhMuc"></td>
                                <td><span class="code-badge"><?= htmlspecialchars($r['MaDM']) ?></span></td>
                                <td><b><?= htmlspecialchars($r['TenDanhMuc']) ?></b></td>
                                <td><?= htmlspecialchars($r['TenDanhMucCha'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($r['MoTa'] ?? '—') ?></td>
                                <td>
                                    <?php if ($so_tl > 0): ?>
                                        <span class="badge badge-warning" title="Còn tài liệu - không thể xóa"><?= $so_tl ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-success" title="Có thể xóa"><?= $so_tl ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)'><i class="fa-solid fa-pen"></i></button>
                                        <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($r['MaDM'], ENT_QUOTES) ?>', '<?= htmlspecialchars($r['TenDanhMuc'], ENT_QUOTES) ?>', <?= $so_tl ?>)"><i class="fa-solid fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile;
                        else: ?>
                            <tr class="empty-row"><td colspan="7"><i class="fa-regular fa-folder-open"></i> Chưa có danh mục nào.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php
                $qs = $_GET;
                $qs['page'] = max(1, $page - 1);
                ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page <= 1 ? 'disabled' : '' ?>">‹</a>

                <?php
                $start = max(1, $page - 2);
                $end   = min($total_pages, $page + 2);
                if ($start > 1) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                for ($i = $start; $i <= $end; $i++):
                    $qs['page'] = $i;
                ?>
                    <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor;
                if ($end < $total_pages) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                ?>

                <?php $qs['page'] = min($total_pages, $page + 1); ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page >= $total_pages ? 'disabled' : '' ?>">›</a>
            </div>
        <?php endif; ?>

        <div class="table-footer" style="margin-top:14px;">
            <span>Hiển thị <b><?= $res ? $res->num_rows : 0 ?></b> / <b><?= $count_q ?></b> danh mục (Trang <?= $page ?>/<?= $total_pages ?>)</span>
        </div>

    </main>
</div>
<div class="modal-backdrop" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Sửa Danh mục</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="modalId">
            <div class="modal-body">
                <div class="form-group">
                    <label>Tên danh mục <span class="required">*</span></label>
                    <input type="text" name="ten" id="m_ten" required>
                </div>
                <div class="form-group">
                    <label>Danh mục cha</label>
                    <select name="madmcha" id="m_madmcha">
                        <?php foreach ($dm_options as $opt): ?>
                            <option value="<?= htmlspecialchars($opt['value']) ?>"><?= htmlspecialchars($opt['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mô tả</label>
                    <textarea name="mota" id="m_mota" rows="3"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function toggleAll(masterCb, tableId) {
    document.querySelectorAll('#' + tableId + ' .row-checkbox').forEach(cb => cb.checked = masterCb.checked);
    updateCount(tableId);
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', () => updateCount(cb.dataset.table));
    });
});
function updateCount(tableId) {
    const count = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked').length;
    const el = document.getElementById('count' + tableId.replace('table', ''));
    if (el) el.textContent = count;
}
function deleteSelected(tableId, typeName) {
    const checked = document.querySelectorAll('#' + tableId + ' .row-checkbox:checked');
    if (checked.length === 0) {
        Swal.fire({ icon: 'info', title: 'Chưa chọn gì', text: 'Vui lòng chọn ít nhất 1 dòng!', confirmButtonColor: '#2563eb' });
        return;
    }
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: 'Bạn sắp xóa <b>' + checked.length + '</b> ' + typeName + '.<br><small style="color:#64748b;">Danh mục còn tài liệu sẽ không được xóa.</small>',
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) document.getElementById('form' + tableId.replace('table', '')).submit();
    });
}
function confirmDelete(id, name, soTaiLieu) {
    if (soTaiLieu > 0) {
        Swal.fire({
            icon: 'error',
            title: 'Không thể xóa!',
            html: `Danh mục <b>${name}</b> đang có <b>${soTaiLieu}</b> tài liệu.<br><br>Vui lòng xóa hoặc chuyển các tài liệu sang danh mục khác trước.`,
            confirmButtonText: 'Đã hiểu',
            confirmButtonColor: '#dc2626'
        });
        return;
    }
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa danh mục <b>${name}</b>?<br><small style="color:#dc2626;">Hành động này không thể hoàn tác!</small>`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
function openEditModal(data) {
    document.getElementById('modalId').value = data.MaDM || '';
    document.getElementById('m_ten').value = data.TenDanhMuc || '';
    document.getElementById('m_madmcha').value = data.MaDMCha || '';
    document.getElementById('m_mota').value = data.MoTa || '';
    document.getElementById('editModal').classList.add('show');
}
function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}
document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); });
});
function filterTable(tableId, keyword) {
    const kw = keyword.toLowerCase().trim();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
        if (row.classList.contains('empty-row')) return;
        row.style.display = (!kw || row.textContent.toLowerCase().includes(kw)) ? '' : 'none';
    });
}
</script>

<?php include "../../includes/footer.php"; ?>