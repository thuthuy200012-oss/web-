<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/config_helper.php";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$base_url = "../../";
$page_title = "Cấu hình hệ thống";
$current_page = 'cau-hinh';

$msg = '';
$msg_type = '';

$tab = $_GET['tab'] ?? 'chung';
$tabs = [
    'chung'    => 'Chung',
    'lien_he'  => 'Liên hệ',
    'smtp'     => 'SMTP',
    'seo'      => 'SEO',
    'thu_vien' => 'Thư viện',
    'ai'       => 'AI',
];
if (!isset($tabs[$tab])) $tab = 'chung';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ!";
        $msg_type = 'danger';
    } else {
        $data = [];
        if ($tab === 'chung') {
            $data = [
                'site_name'   => trim($_POST['site_name'] ?? ''),
                'site_short'  => trim($_POST['site_short'] ?? ''),
                'site_slogan' => trim($_POST['site_slogan'] ?? ''),
                'site_desc'   => trim($_POST['site_desc'] ?? ''),
            ];

            if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp'])) {
                    $filename = 'logo_' . time() . '.' . $ext;
                    $target = "../../assets/images/" . $filename;
                    if (!is_dir("../../assets/images/")) mkdir("../../assets/images/", 0755, true);
                    if (move_uploaded_file($_FILES['site_logo']['tmp_name'], $target)) {
                        $data['site_logo'] = 'assets/images/' . $filename;
                    }
                }
            }

            if (isset($_FILES['site_favicon']) && $_FILES['site_favicon']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['site_favicon']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['png', 'jpg', 'jpeg', 'ico', 'svg', 'webp'])) {
                    $filename = 'favicon_' . time() . '.' . $ext;
                    $target = "../../assets/images/" . $filename;
                    if (!is_dir("../../assets/images/")) mkdir("../../assets/images/", 0755, true);
                    if (move_uploaded_file($_FILES['site_favicon']['tmp_name'], $target)) {
                        $data['site_favicon'] = 'assets/images/' . $filename;
                    }
                }
            }
        }
        elseif ($tab === 'lien_he') {
            $data = [
                'contact_email'     => trim($_POST['contact_email'] ?? ''),
                'contact_hotline'   => trim($_POST['contact_hotline'] ?? ''),
                'contact_address'   => trim($_POST['contact_address'] ?? ''),
                'contact_website'   => trim($_POST['contact_website'] ?? ''),
                'contact_facebook'  => trim($_POST['contact_facebook'] ?? ''),
                'contact_youtube'   => trim($_POST['contact_youtube'] ?? ''),
                'contact_copyright' => trim($_POST['contact_copyright'] ?? ''),
            ];
        }
        elseif ($tab === 'smtp') {
            $data = [
                'smtp_host'       => trim($_POST['smtp_host'] ?? ''),
                'smtp_port'       => trim($_POST['smtp_port'] ?? ''),
                'smtp_user'       => trim($_POST['smtp_user'] ?? ''),
                'smtp_encryption' => $_POST['smtp_encryption'] ?? 'TLS',
                'smtp_from_email' => trim($_POST['smtp_from_email'] ?? ''),
                'smtp_from_name'  => trim($_POST['smtp_from_name'] ?? ''),
            ];
            $pass_new = trim($_POST['smtp_pass'] ?? '');
            if ($pass_new !== '') {
                $data['smtp_pass'] = $pass_new;
            }
        }
        elseif ($tab === 'seo') {
            $data = [
                'seo_title'       => trim($_POST['seo_title'] ?? ''),
                'seo_description' => trim($_POST['seo_description'] ?? ''),
                'seo_keywords'    => trim($_POST['seo_keywords'] ?? ''),
                'seo_ga_id'       => trim($_POST['seo_ga_id'] ?? ''),
            ];
        }
        elseif ($tab === 'thu_vien') {
            $data = [
                'lib_per_page'       => (int)($_POST['lib_per_page'] ?? 12),
                'lib_allow_download' => isset($_POST['lib_allow_download']) ? '1' : '0',
                'lib_allow_register' => isset($_POST['lib_allow_register']) ? '1' : '0',
                'lib_approval_mode'  => $_POST['lib_approval_mode'] ?? 'auto',
                'lib_preview_pages'  => (int)($_POST['lib_preview_pages'] ?? 20),
            ];
        }
        elseif ($tab === 'ai') {
            $data = [
                'ai_enabled'       => isset($_POST['ai_enabled']) ? '1' : '0',
                'ai_voice_enabled' => isset($_POST['ai_voice_enabled']) ? '1' : '0',
                'ai_provider'      => trim($_POST['ai_provider'] ?? ''),
                'ai_model'         => trim($_POST['ai_model'] ?? ''),
            ];
            $api_new = trim($_POST['ai_api_key'] ?? '');
            if ($api_new !== '') {
                $data['ai_api_key'] = $api_new;
            }
        }

        if (save_configs($conn, $data)) {
            ghi_log($conn, 'UPDATE', "Cập nhật cấu hình tab '$tab'", 'cau_hinh', '');
            $msg = "Đã lưu cấu hình thành công!";
            $msg_type = 'success';
        } else {
            $msg = "Đã xảy ra lỗi!";
            $msg_type = 'danger';
        }
    }
}

$cfg = get_configs_by_group($conn, $tab);

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    .cfg-tabs {
        display: flex;
        gap: 4px;
        border-bottom: 2px solid #e2e8f0;
        margin-bottom: 24px;
        overflow-x: auto;
    }
    .cfg-tab {
        padding: 12px 22px;
        font-size: 14px;
        font-weight: 600;
        color: #64748b;
        text-decoration: none;
        border-bottom: 3px solid transparent;
        margin-bottom: -2px;
        white-space: nowrap;
        transition: all 0.2s;
    }
    .cfg-tab:hover { color: #16a34a; }
    .cfg-tab.active {
        color: #16a34a;
        border-bottom-color: #16a34a;
    }
    .cfg-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 28px;
        margin-bottom: 24px;
    }
    .cfg-card h2 {
        font-size: 18px;
        font-weight: 700;
        color: #0c1e3e;
        margin: 0 0 24px;
    }
    .cfg-grid-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .cfg-field { margin-bottom: 20px; }
    .cfg-field label {
        display: block;
        font-size: 12.5px;
        font-weight: 700;
        color: #475569;
        margin-bottom: 8px;
    }
    .cfg-field input[type=text],
    .cfg-field input[type=email],
    .cfg-field input[type=number],
    .cfg-field input[type=password],
    .cfg-field select,
    .cfg-field textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1.5px solid #cbd5e1;
        border-radius: 8px;
        font-size: 14px;
        background: #fff;
        font-family: inherit;
        box-sizing: border-box;
    }
    .cfg-field input:focus, .cfg-field select:focus, .cfg-field textarea:focus {
        outline: none;
        border-color: #16a34a;
        box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.1);
    }
    .cfg-field .hint {
        font-size: 11.5px;
        color: #94a3b8;
        margin-top: 5px;
        font-style: italic;
    }
    .cfg-file-box {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        background: #f8fafc;
    }
    .cfg-file-box img {
        width: 48px;
        height: 48px;
        object-fit: contain;
        border-radius: 6px;
        background: #fff;
        padding: 4px;
    }
    .cfg-file-box .file-name {
        flex: 1;
        font-size: 13px;
        color: #475569;
        font-family: monospace;
    }
    .cfg-checkbox-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 0;
        font-size: 14px;
        color: #334155;
        cursor: pointer;
    }
    .cfg-checkbox-row input[type=checkbox] {
        width: 18px;
        height: 18px;
        accent-color: #16a34a;
        cursor: pointer;
    }
    .btn-save-green {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 28px;
        background: linear-gradient(135deg, #16a34a, #22c55e);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s;
        box-shadow: 0 2px 6px rgba(22, 163, 74, 0.3);
    }
    .btn-save-green:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(22, 163, 74, 0.4);
    }
    .btn-outline {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background: #fff;
        color: #475569;
        border: 1.5px solid #cbd5e1;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
    }
    .btn-outline:hover { background: #f8fafc; }
    .btn-outline:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
</style>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <div class="page-header">
            <div class="title-block">
                <h1>Cấu hình hệ thống</h1>
            </div>
        </div>
        <div class="cfg-tabs">
            <?php foreach ($tabs as $key => $label): ?>
                <a href="?tab=<?= $key ?>" class="cfg-tab <?= $tab === $key ? 'active' : '' ?>">
                    <?= htmlspecialchars($label) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <?php if ($tab === 'chung'): ?>
                <div class="cfg-card">
                    <h2>Thông tin chung</h2>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>Tên website</label>
                            <input type="text" name="site_name" value="<?= htmlspecialchars($cfg['site_name'] ?? '') ?>">
                        </div>
                        <div class="cfg-field">
                            <label>Tên viết tắt</label>
                            <input type="text" name="site_short" value="<?= htmlspecialchars($cfg['site_short'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="cfg-field">
                        <label>Slogan</label>
                        <input type="text" name="site_slogan" value="<?= htmlspecialchars($cfg['site_slogan'] ?? '') ?>">
                    </div>

                    <div class="cfg-field">
                        <label>Mô tả website</label>
                        <textarea name="site_desc" rows="4"><?= htmlspecialchars($cfg['site_desc'] ?? '') ?></textarea>
                    </div>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>Logo</label>
                            <div class="cfg-file-box">
                                <img src="<?= $base_url . htmlspecialchars($cfg['site_logo'] ?? 'assets/images/logo.svg') ?>" alt="Logo">
                                <span class="file-name"><?= htmlspecialchars($cfg['site_logo'] ?? 'Chưa có') ?></span>
                            </div>
                            <input type="file" name="site_logo" accept="image/*" style="margin-top:8px;">
                        </div>
                        <div class="cfg-field">
                            <label>Favicon</label>
                            <div class="cfg-file-box">
                                <img src="<?= $base_url . htmlspecialchars($cfg['site_favicon'] ?? 'assets/images/logo.svg') ?>" alt="Favicon">
                                <span class="file-name"><?= htmlspecialchars($cfg['site_favicon'] ?? 'Chưa có') ?></span>
                            </div>
                            <input type="file" name="site_favicon" accept="image/*" style="margin-top:8px;">
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($tab === 'lien_he'): ?>
                <div class="cfg-card">
                    <h2>Thông tin liên hệ</h2>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>Email</label>
                            <input type="email" name="contact_email" value="<?= htmlspecialchars($cfg['contact_email'] ?? '') ?>">
                        </div>
                        <div class="cfg-field">
                            <label>Hotline</label>
                            <input type="text" name="contact_hotline" value="<?= htmlspecialchars($cfg['contact_hotline'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="cfg-field">
                        <label>Địa chỉ</label>
                        <input type="text" name="contact_address" value="<?= htmlspecialchars($cfg['contact_address'] ?? '') ?>">
                    </div>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>Website trường</label>
                            <input type="text" name="contact_website" value="<?= htmlspecialchars($cfg['contact_website'] ?? '') ?>">
                        </div>
                        <div class="cfg-field">
                            <label>Facebook</label>
                            <input type="text" name="contact_facebook" value="<?= htmlspecialchars($cfg['contact_facebook'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>YouTube</label>
                            <input type="text" name="contact_youtube" value="<?= htmlspecialchars($cfg['contact_youtube'] ?? '') ?>">
                        </div>
                        <div class="cfg-field">
                            <label>Copyright</label>
                            <input type="text" name="contact_copyright" value="<?= htmlspecialchars($cfg['contact_copyright'] ?? '') ?>">
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($tab === 'smtp'): ?>
                <div class="cfg-card">
                    <h2>Cấu hình SMTP</h2>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>SMTP Host</label>
                            <input type="text" name="smtp_host" value="<?= htmlspecialchars($cfg['smtp_host'] ?? '') ?>" placeholder="smtp.gmail.com">
                        </div>
                        <div class="cfg-field">
                            <label>SMTP Port</label>
                            <input type="text" name="smtp_port" value="<?= htmlspecialchars($cfg['smtp_port'] ?? '587') ?>">
                        </div>
                    </div>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>SMTP Username</label>
                            <input type="text" name="smtp_user" value="<?= htmlspecialchars($cfg['smtp_user'] ?? '') ?>">
                        </div>
                        <div class="cfg-field">
                            <label>SMTP Password</label>
                            <input type="password" name="smtp_pass" placeholder="Để trống nếu giữ nguyên">
                            <div class="hint">✓ Đã lưu mật khẩu (ẩn vì lý do bảo mật)</div>
                        </div>
                    </div>

                    <div class="cfg-grid-2">
                        <div class="cfg-field">
                            <label>Encryption</label>
                            <select name="smtp_encryption">
                                <option value="TLS" <?= ($cfg['smtp_encryption'] ?? '') === 'TLS' ? 'selected' : '' ?>>TLS</option>
                                <option value="SSL" <?= ($cfg['smtp_encryption'] ?? '') === 'SSL' ? 'selected' : '' ?>>SSL</option>
                                <option value="" <?= ($cfg['smtp_encryption'] ?? '') === '' ? 'selected' : '' ?>>Không</option>
                            </select>
                        </div>
                        <div class="cfg-field">
                            <label>From Email</label>
                            <input type="email" name="smtp_from_email" value="<?= htmlspecialchars($cfg['smtp_from_email'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="cfg-field">
                        <label>From Name</label>
                        <input type="text" name="smtp_from_name" value="<?= htmlspecialchars($cfg['smtp_from_name'] ?? '') ?>">
                    </div>

                    <button type="button" class="btn-outline" onclick="alert('Chức năng test email sẽ được phát triển sau!');">
                        <i class="fa-solid fa-paper-plane"></i> Gửi email kiểm tra
                    </button>
                </div>
            <?php endif; ?>
            <?php if ($tab === 'seo'): ?>
                <div class="cfg-card">
                    <h2>SEO</h2>

                    <div class="cfg-field">
                        <label>SEO Title</label>
                        <input type="text" name="seo_title" value="<?= htmlspecialchars($cfg['seo_title'] ?? '') ?>">
                    </div>

                    <div class="cfg-field">
                        <label>Meta Description</label>
                        <textarea name="seo_description" rows="4"><?= htmlspecialchars($cfg['seo_description'] ?? '') ?></textarea>
                    </div>

                    <div class="cfg-field">
                        <label>Meta Keywords</label>
                        <input type="text" name="seo_keywords" value="<?= htmlspecialchars($cfg['seo_keywords'] ?? '') ?>">
                    </div>

                    <div class="cfg-field">
                        <label>Google Analytics ID</label>
                        <input type="text" name="seo_ga_id" value="<?= htmlspecialchars($cfg['seo_ga_id'] ?? '') ?>" placeholder="G-XXXXXXXX">
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($tab === 'thu_vien'): ?>
                <div class="cfg-card">
                    <h2>Cấu hình thư viện</h2>

                    <div class="cfg-field">
                        <label>Số tài liệu/trang</label>
                        <input type="number" name="lib_per_page" value="<?= (int)($cfg['lib_per_page'] ?? 12) ?>" min="1" max="100">
                    </div>

                    <label class="cfg-checkbox-row">
                        <input type="checkbox" name="lib_allow_download" value="1" <?= !empty($cfg['lib_allow_download']) ? 'checked' : '' ?>>
                        Cho phép tải xuống tài liệu
                    </label>

                    <label class="cfg-checkbox-row">
                        <input type="checkbox" name="lib_allow_register" value="1" <?= !empty($cfg['lib_allow_register']) ? 'checked' : '' ?>>
                        Cho phép người dùng tự đăng ký tài khoản
                    </label>

                    <div class="cfg-field">
                        <label>Chế độ duyệt tài liệu</label>
                        <select name="lib_approval_mode">
                            <option value="auto" <?= ($cfg['lib_approval_mode'] ?? '') === 'auto' ? 'selected' : '' ?>>Tự động xuất bản</option>
                            <option value="manual" <?= ($cfg['lib_approval_mode'] ?? '') === 'manual' ? 'selected' : '' ?>>Chờ duyệt</option>
                        </select>
                    </div>

                    <div class="cfg-field">
                        <label>Số trang xem trước mặc định khi đọc online (PDF)</label>
                        <input type="number" name="lib_preview_pages" value="<?= (int)($cfg['lib_preview_pages'] ?? 20) ?>" min="0">
                        <div class="hint">Áp dụng cho mọi tài liệu chưa cấu hình riêng. Nhập 0 = cho đọc toàn bộ tài liệu.</div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($tab === 'ai'): ?>
                <div class="cfg-card">
                    <h2>Tìm kiếm AI</h2>

                    <p style="font-size:13.5px; color:#64748b; line-height:1.6; margin-bottom:20px;">
                        Cho phép người dùng tìm kiếm tài liệu bằng câu hỏi tự nhiên (kể cả tìm kiếm bằng giọng nói) — hệ thống gửi câu hỏi cho AI để trích xuất tiêu chí lọc, sau đó tự tra cứu trong CSDL bằng các bộ lọc sẵn có.
                    </p>

                    <label class="cfg-checkbox-row">
                        <input type="checkbox" name="ai_enabled" value="1" <?= !empty($cfg['ai_enabled']) ? 'checked' : '' ?>>
                        <b>Bật tính năng tìm kiếm AI</b>
                    </label>

                    <label class="cfg-checkbox-row">
                        <input type="checkbox" name="ai_voice_enabled" value="1" <?= !empty($cfg['ai_voice_enabled']) ? 'checked' : '' ?>>
                        Hiển nút tìm kiếm bằng giọng nói trên Frontend
                    </label>

                    <div class="cfg-grid-2" style="margin-top:16px;">
                        <div class="cfg-field">
                            <label>Nhà cung cấp AI</label>
                            <select name="ai_provider">
                                <option value="Google Gemini" <?= ($cfg['ai_provider'] ?? '') === 'Google Gemini' ? 'selected' : '' ?>>Google Gemini</option>
                                <option value="OpenAI" <?= ($cfg['ai_provider'] ?? '') === 'OpenAI' ? 'selected' : '' ?>>OpenAI</option>
                            </select>
                        </div>
                        <div class="cfg-field">
                            <label>Model</label>
                            <input type="text" name="ai_model" value="<?= htmlspecialchars($cfg['ai_model'] ?? 'gemini-1.5-flash') ?>">
                        </div>
                    </div>

                    <div class="cfg-field">
                        <label>API Key</label>
                        <input type="password" name="ai_api_key" placeholder="Để trống nếu giữ nguyên">
                        <div class="hint">✓ Đã lưu API key (ẩn vì lý do bảo mật) — chỉ nhập lại nếu muốn đổi.</div>
                        <div class="hint" style="margin-top:8px;">
                            Lấy API key Gemini miễn phí tại <a href="https://aistudio.google.com/" target="_blank" style="color:#16a34a;">Google AI Studio</a>.
                        </div>
                    </div>

                    <button type="button" class="btn-outline" id="btnTestAI" onclick="testAIConnection()">
                        <i class="fa-solid fa-plug"></i> Kiểm tra kết nối AI
                    </button>
                </div>
            <?php endif; ?>
            <button type="submit" class="btn-save-green">
                <i class="fa-solid fa-floppy-disk"></i> Lưu cấu hình
            </button>
        </form>

    </main>
</div>

<script>
function testAIConnection() {
    const btn = document.getElementById('btnTestAI');
    const originalHTML = btn.innerHTML;

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang kiểm tra...';

    fetch('test_ai_connection.php?t=' + Date.now(), {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store'
    })
    .then(res => res.text())
    .then(text => {
        console.log('Raw response:', text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Server trả về không phải JSON: ' + text.substring(0, 200));
        }

        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Kết nối thành công!',
                html: 'AI phản hồi: <b>' + escapeHtml(data.message) + '</b>',
                confirmButtonColor: '#16a34a',
                confirmButtonText: 'OK'
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Kết nối thất bại',
                html: '<b>Lỗi:</b> ' + escapeHtml(data.error || 'Không rõ lỗi') +
                      (data.hint ? '<br><br><small style="color:#64748b;">' + escapeHtml(data.hint) + '</small>' : ''),
                confirmButtonColor: '#dc2626',
                confirmButtonText: 'Đóng'
            });
        }
    })
    .catch(err => {
        console.error('Error:', err);
        Swal.fire({
            icon: 'error',
            title: 'Lỗi kết nối',
            html: '<b>Chi tiết:</b> ' + escapeHtml(err.message),
            confirmButtonColor: '#dc2626',
            confirmButtonText: 'Đóng'
        });
    })
    .finally(() => {
        btn.disabled = false;
        btn.innerHTML = originalHTML;
    });
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
</script>

<?php include "../../includes/footer.php"; ?>