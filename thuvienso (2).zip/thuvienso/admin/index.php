<?php
require_once "../connect.php";
require_once "../includes/audit.php";
require_once "../includes/auth.php";
check_session_timeout();
try_remember_login($conn);

if (isset($_GET['preview_public']) && $_GET['preview_public'] == '1') {
    $_SESSION['preview_public'] = true;
    if (empty($_SESSION['_backup_admin'])) {
        $_SESSION['_backup_admin'] = [
            'MaND'       => $_SESSION['MaND']      ?? null,
            'HoTen'      => $_SESSION['HoTen']     ?? null,
            'MaVaiTro'   => $_SESSION['MaVaiTro']  ?? null,
            'Email'      => $_SESSION['Email']     ?? null,
            'TenVaiTro'  => $_SESSION['TenVaiTro'] ?? null,
            'MaPB'       => $_SESSION['MaPB']      ?? null,
            'login_time' => $_SESSION['login_time'] ?? null,
        ];
    }
    header('Location: ../index.php');
    exit;
}

if (isset($_GET['exit_preview']) && $_GET['exit_preview'] == '1') {
    if (!empty($_SESSION['_backup_admin'])) {
        $b = $_SESSION['_backup_admin'];
        $_SESSION['MaND']       = $b['MaND'];
        $_SESSION['HoTen']      = $b['HoTen'];
        $_SESSION['MaVaiTro']   = $b['MaVaiTro'];
        $_SESSION['Email']      = $b['Email'];
        $_SESSION['TenVaiTro']  = $b['TenVaiTro'];
        $_SESSION['MaPB']       = $b['MaPB'];
        $_SESSION['login_time'] = $b['login_time'];
        unset($_SESSION['_backup_admin']);
    }
    unset($_SESSION['preview_public']);
    header('Location: index.php');
    exit;
}

$role = $_SESSION['MaVaiTro'] ?? '';
if ($role !== 'ADMIN' && $role !== 'THUTHU') {
    header('Location: ../pages/auth/login.php');
    exit;
}

$hour = (int)date('H');
if ($hour < 12)      $chao = "Chào buổi sáng";
elseif ($hour < 18)  $chao = "Chào buổi chiều";
else                 $chao = "Chào buổi tối";

$stats = [];
$r = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu");
$stats['tai_lieu'] = $r ? $r->fetch_assoc()['c'] : 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM nguoidung");
$stats['nguoidung'] = $r ? $r->fetch_assoc()['c'] : 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai = 'Chờ duyệt'");
$stats['cho_duyet'] = $r ? $r->fetch_assoc()['c'] : 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai = 'Đã duyệt'");
$stats['da_duyet'] = $r ? $r->fetch_assoc()['c'] : 0;
$r = $conn->query("SELECT SUM(SoLuotXem) AS total FROM tai_lieu");
$stats['luot_xem'] = $r ? (int)$r->fetch_assoc()['total'] : 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM danh_muc");
$stats['danh_muc'] = $r ? $r->fetch_assoc()['c'] : 0;
$r = $conn->query("SELECT COUNT(*) AS c FROM phong_ban");
$stats['phong_ban'] = $r ? $r->fetch_assoc()['c'] : 0;
$loai_stats = [];
$r = $conn->query("
    SELECT LoaiTaiLieu, COUNT(*) AS so_luong
    FROM tai_lieu
    WHERE LoaiTaiLieu IS NOT NULL AND LoaiTaiLieu <> ''
    GROUP BY LoaiTaiLieu
    ORDER BY so_luong DESC
");
if ($r) {
    while ($row = $r->fetch_assoc()) {
        $loai_stats[] = $row;
    }
}

$thang_labels = [];
$thang_tailieu = [];
$thang_luotxem = [];
$thang_luottai = [];

$six_months_ago = date('Y-m-d', strtotime('-5 months', strtotime(date('Y-m-01'))));

$sql_docs = "
    SELECT DATE_FORMAT(NgayDang, '%Y-%m') AS Thang, COUNT(*) AS SoLuong
    FROM tai_lieu
    WHERE NgayDang >= ?
    GROUP BY DATE_FORMAT(NgayDang, '%Y-%m')
";
$stmt_d = $conn->prepare($sql_docs);
$stmt_d->bind_param("s", $six_months_ago);
$stmt_d->execute();
$res_d = $stmt_d->get_result();
$docs_map = [];
while ($row = $res_d->fetch_assoc()) {
    $docs_map[$row['Thang']] = (int)$row['SoLuong'];
}
$stmt_d->close();

$sql_views = "
    SELECT 
        DATE_FORMAT(ThoiGian, '%Y-%m') AS Thang,
        SUM(CASE WHEN HanhDong = 'xem' THEN 1 ELSE 0 END) AS LuotXem,
        SUM(CASE WHEN HanhDong = 'tai' THEN 1 ELSE 0 END) AS LuotTai
    FROM lichsudoc
    WHERE ThoiGian >= ?
    GROUP BY DATE_FORMAT(ThoiGian, '%Y-%m')
";
$stmt_v = $conn->prepare($sql_views);
$stmt_v->bind_param("s", $six_months_ago);
$stmt_v->execute();
$res_v = $stmt_v->get_result();
$views_map = [];
while ($row = $res_v->fetch_assoc()) {
    $views_map[$row['Thang']] = [
        'views' => (int)$row['LuotXem'],
        'downloads' => (int)$row['LuotTai']
    ];
}
$stmt_v->close();
for ($i = 5; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i month"));
    $thang_labels[] = date('m/Y', strtotime("-$i month"));
    $thang_tailieu[] = $docs_map[$ym] ?? 0;
    $thang_luotxem[] = $views_map[$ym]['views'] ?? 0;
    $thang_luottai[] = $views_map[$ym]['downloads'] ?? 0;
}

$nam_labels = [];
$nam_data = [];
$r = $conn->query("
    SELECT NamXuatBan, COUNT(*) AS so_luong
    FROM tai_lieu
    WHERE NamXuatBan IS NOT NULL AND NamXuatBan > 0
    GROUP BY NamXuatBan
    ORDER BY NamXuatBan
");
if ($r) {
    while ($row = $r->fetch_assoc()) {
        $nam_labels[] = $row['NamXuatBan'];
        $nam_data[] = (int)$row['so_luong'];
    }
}

$pending_list = $conn->query("
    SELECT t.MaTL, t.TenTaiLieu, t.LoaiTaiLieu, t.NgayDang,
           dm.TenDanhMuc,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
    FROM tai_lieu t
    LEFT JOIN danh_muc dm ON t.MaDM = dm.MaDM
    LEFT JOIN tailieutacgia tltg ON t.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    WHERE t.TrangThai = 'Chờ duyệt'
    GROUP BY t.MaTL
    ORDER BY t.NgayDang DESC
    LIMIT 5
");

$new_users = $conn->query("
    SELECT nd.MaND, nd.HoTen, nd.Email, nd.NgayTao, vt.TenVaiTro
    FROM nguoidung nd
    LEFT JOIN vaitro vt ON nd.MaVaiTro = vt.MaVaiTro
    ORDER BY nd.NgayTao DESC LIMIT 5
");

$top_docs = $conn->query("
    SELECT MaTL, TenTaiLieu, SoLuotXem, SoLuotTai
    FROM tai_lieu WHERE TrangThai = 'Đã duyệt'
    ORDER BY SoLuotXem DESC LIMIT 5
");
$activities = $conn->query("
    SELECT MaLog, HoTen, HanhDong, MoTa, DoiTuong, MaDoiTuong,
           IPAddress, ThoiGian
    FROM nhatkyhoatdong
    ORDER BY ThoiGian DESC
    LIMIT 8
");

$page_title = "Trang quản trị hệ thống";
include "../includes/header.php";
?>
<link rel="stylesheet" href="../assets/css/admin.css">
<link rel="stylesheet" href="../assets/css/dashboard.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<div class="layout">
    <?php include "../includes/sidebar.php"; ?>
    <main class="main">
        <div class="stats">
            <div class="stat-box stat-blue">
                <div class="stat-icon"><i class="fa-solid fa-file-lines"></i></div>
                <div class="stat-info">
                    <h2><?= number_format($stats['tai_lieu']) ?></h2>
                    <p>Tổng tài liệu</p>
                </div>
            </div>
            <div class="stat-box stat-orange">
                <div class="stat-icon"><i class="fa-solid fa-clock"></i></div>
                <div class="stat-info">
                    <h2><?= number_format($stats['cho_duyet']) ?></h2>
                    <p>Tài Liệu Chờ duyệt</p>
                </div>
            </div>
            <div class="stat-box stat-purple">
                <div class="stat-icon"><i class="fa-solid fa-eye"></i></div>
                <div class="stat-info">
                    <h2><?= number_format($stats['luot_xem']) ?></h2>
                    <p>Lượt xem tài liệu</p>
                </div>
            </div>
            <div class="stat-box stat-pink">
                <div class="stat-icon"><i class="fa-solid fa-folder-tree"></i></div>
                <div class="stat-info">
                    <h2><?= number_format($stats['danh_muc']) ?></h2>
                    <p>Danh mục</p>
                </div>
            </div>
            <div class="stat-box stat-cyan">
                <div class="stat-icon"><i class="fa-solid fa-building-columns"></i></div>
                <div class="stat-info">
                    <h2><?= number_format($stats['phong_ban']) ?></h2>
                    <p>Khoa / Phòng ban</p>
                </div>
            </div>
        </div>
        <div class="admin-section">
            <h2><i class="fa-solid fa-bolt"></i> Truy cập nhanh</h2>
            <div class="grid-buttons">
                <a href="users/index.php" class="menu-card">
                    <i class="fa-solid fa-users" style="background:rgba(12,30,62,0.08); color:#0c1e3e;"></i>
                    <h3>Quản lý Tài khoản</h3>
                </a>
                <a href="categories/danh_muc.php" class="menu-card">
                    <i class="fa-solid fa-folder-tree" style="background:rgba(20,184,166,0.12); color:#0d9488;"></i>
                    <h3>Quản lý Danh mục</h3>
                </a>
                <a href="documents/index.php" class="menu-card">
                    <i class="fa-solid fa-file-lines" style="background:rgba(245,158,11,0.12); color:#d97706;"></i>
                    <h3>Quản lý Tài liệu</h3>
                </a>
                <a href="approvals/index.php" class="menu-card">
                    <i class="fa-solid fa-clipboard-check" style="background:rgba(30,58,95,0.1); color:#1e3a5f;"></i>
                    <h3>Kiểm duyệt</h3>
                </a>
                <a href="reports/index.php" class="menu-card">
                    <i class="fa-solid fa-chart-pie" style="background:rgba(12,30,62,0.06); color:#16294b;"></i>
                    <h3>Thống kê</h3>
                </a>
                <a href="?preview_public=1" class="menu-card" title="Xem giao diện dành cho khách chưa đăng nhập">
                    <i class="fa-solid fa-globe" style="background:rgba(20,184,166,0.08); color:#0d9488;"></i>
                    <h3>Xem trang công khai</h3>
                </a>
            </div>
        </div>

        <div class="dashboard-grid-2">

            <div class="card">
                <div class="card-header">
                    <h3>
                        <i class="fa-solid fa-chart-line" style="color: #2264d6;"></i>
                        Tài liệu / Lượt xem / Lượt tải theo tháng
                    </h3>
                </div>
                <div class="card-body">
                    <div class="chart-container-grid">
                        <canvas id="chartThang"></canvas>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>
                        <i class="fa-solid fa-chart-pie" style="color: #2264d6;"></i>
                        Tài liệu theo thể loại
                    </h3>
                </div>
                <div class="card-body">
                    <div class="chart-container-grid">
                        <canvas id="chartLoai"></canvas>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>
                        <i class="fa-solid fa-calendar-days" style="color: #2264d6;"></i>
                        Tài liệu theo năm
                    </h3>
                </div>
                <div class="card-body">
                    <div class="chart-container-grid">
                        <canvas id="chartNam"></canvas>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>
                        <i class="fa-solid fa-clock-rotate-left" style="color: #2264d6;"></i>
                        Hoạt động gần đây
                    </h3>
                </div>
                <div class="card-body" style="padding: 0;">
                    <?php if ($activities && $activities->num_rows > 0): ?>
                        <div style="max-height: 460px; overflow-y: auto;">
                            <?php while ($act = $activities->fetch_assoc()):

                                $action_map = [
                                    'LOGIN'    => ['Đăng nhập', '#10b981'],
                                    'LOGOUT'   => ['Đăng xuất', '#6b7280'],
                                    'REGISTER' => ['Đăng ký',   '#0891b2'],
                                    'CREATE'   => ['Tạo mới',   '#2563eb'],
                                    'UPDATE'   => ['Cập nhật',  '#f59e0b'],
                                    'DELETE'   => ['Xóa',       '#dc2626'],
                                ];
                                $hanh_dong = $act['HanhDong'] ?? 'OTHER';
                                [$label, $color] = $action_map[$hanh_dong] ?? ['Khác', '#64748b'];

                                if (!empty($act['ThoiGian'])) {
                                    $diff = time() - strtotime($act['ThoiGian']);
                                    if ($diff < 60)          $time_str = 'vừa xong';
                                    elseif ($diff < 3600)    $time_str = floor($diff / 60) . ' phút trước';
                                    elseif ($diff < 86400)   $time_str = floor($diff / 3600) . ' giờ trước';
                                    elseif ($diff < 604800)  $time_str = floor($diff / 86400) . ' ngày trước';
                                    else                     $time_str = date('d/m/Y', strtotime($act['ThoiGian']));
                                } else {
                                    $time_str = '—';
                                }
                            ?>
                                <div style="padding: 12px 20px; border-bottom: 1px dashed #e2e8f0;">
                                    <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                                        <span style="font-weight: 700; font-size: 13px; color: #0f172a;">
                                            <?= htmlspecialchars($act['HoTen'] ?? 'Khách') ?>
                                        </span>
                                        <span style="color: #cbd5e1;">·</span>
                                        <span style="font-weight: 800; font-size: 11px; letter-spacing: 0.5px; color: <?= $color ?>;">
                                            <?= htmlspecialchars(strtoupper($hanh_dong)) ?>
                                        </span>
                                    </div>

                                    <div style="font-size: 13px; color: #334155; margin-bottom: 4px; line-height: 1.4;">
                                        <?= htmlspecialchars($act['MoTa'] ?? '(không có mô tả)') ?>
                                    </div>

                                    <div style="font-size: 11.5px; color: #94a3b8; display: flex; align-items: center; gap: 6px;">
                                        <?php if (!empty($act['IPAddress'])): ?>
                                            <span style="font-family: monospace;"><?= htmlspecialchars($act['IPAddress']) ?></span>
                                            <span style="color: #cbd5e1;">·</span>
                                        <?php endif; ?>
                                        <span><?= htmlspecialchars($time_str) ?></span>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state" style="padding: 30px 20px;">
                            <i class="fa-solid fa-clock"></i>
                            Chưa có hoạt động nào
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    </main>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('chartLoai');
    if (canvas) {
        const labels = <?= json_encode(array_column($loai_stats, 'LoaiTaiLieu'), JSON_UNESCAPED_UNICODE) ?>;
        const data   = <?= json_encode(array_map('intval', array_column($loai_stats, 'so_luong'))) ?>;

        if (labels.length === 0) {
            canvas.parentElement.innerHTML = '<div class="empty-state"><i class="fa-solid fa-chart-pie"></i>Chưa có dữ liệu tài liệu</div>';
        } else {
            new Chart(canvas, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: ['#2563eb','#0ea5e9','#06b6d4','#7c3aed','#ec4899','#f59e0b','#16a34a','#6366f1'],
                        borderWidth: 3,
                        borderColor: '#fff',
                        hoverOffset: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '55%',
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: { padding: 12, font: { size: 12 }, color: '#334155', boxWidth: 30, boxHeight: 12 }
                        },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            padding: 10,
                            cornerRadius: 8,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = ((context.parsed / total) * 100).toFixed(1);
                                    return ' ' + context.parsed + ' tài liệu (' + pct + '%)';
                                }
                            }
                        }
                    }
                }
            });
        }
    }
    const canvas2 = document.getElementById('chartThang');
    if (canvas2) {
        new Chart(canvas2, {
            type: 'line',
            data: {
                labels: <?= json_encode($thang_labels) ?>,
                datasets: [
                    {
                        label: 'Tài liệu mới',
                        data: <?= json_encode($thang_tailieu) ?>,
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.15)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: true,
                        pointRadius: 4,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#2563eb',
                        pointBorderWidth: 2
                    },
                    {
                        label: 'Lượt xem',
                        data: <?= json_encode($thang_luotxem) ?>,
                        borderColor: '#06b6d4',
                        backgroundColor: 'rgba(6, 182, 212, 0.08)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: false,
                        pointRadius: 4,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#06b6d4',
                        pointBorderWidth: 2
                    },
                    {
                        label: 'Lượt tải',
                        data: <?= json_encode($thang_luottai) ?>,
                        borderColor: '#f97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.08)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: false,
                        pointRadius: 4,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#f97316',
                        pointBorderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { padding: 14, font: { size: 12 }, boxWidth: 30, boxHeight: 12 }
                    },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        padding: 10,
                        cornerRadius: 8
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f1f5f9' },
                        ticks: { color: '#64748b', font: { size: 11 } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b', font: { size: 11 } }
                    }
                }
            }
        });
    }
    const canvas3 = document.getElementById('chartNam');
    if (canvas3) {
        const namLabels = <?= json_encode($nam_labels) ?>;
        const namData = <?= json_encode($nam_data) ?>;

        if (namLabels.length === 0) {
            canvas3.parentElement.innerHTML = '<div class="empty-state"><i class="fa-solid fa-chart-bar"></i>Chưa có dữ liệu tài liệu</div>';
        } else {
            new Chart(canvas3, {
                type: 'bar',
                data: {
                    labels: namLabels,
                    datasets: [{
                        label: 'Số tài liệu',
                        data: namData,
                        backgroundColor: '#2264d6',
                        borderRadius: 6,
                        borderSkipped: false,
                        maxBarThickness: 50
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#0f172a',
                            padding: 10,
                            cornerRadius: 8,
                            callbacks: {
                                label: function(context) {
                                    return ' ' + context.parsed.y + ' tài liệu';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#f1f5f9' },
                            ticks: { color: '#64748b', stepSize: 5, font: { size: 11 } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { color: '#64748b', font: { size: 11 } }
                        }
                    }
                }
            });
        }
    }
});
</script>
<?php include "../includes/footer.php"; ?>