<?php
require_once "../includes/check_admin.php";
require_once "../connect.php";

$base_url = "../";
$page_title = "Nhật ký hệ thống";
$current_page = '/admin/logs.php';

$keyword = trim($_GET['keyword'] ?? '');
$action_filter = trim($_GET['action'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$where = ["1=1"];
$params = [];
$types = "";

if ($keyword !== '') {
    $where[] = "(HoTen LIKE ? OR MoTa LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw;
    $types .= "ss";
}

if ($action_filter !== '') {
    $where[] = "HanhDong = ?";
    $params[] = $action_filter;
    $types .= "s";
}

$where_sql = implode(' AND ', $where);

$sql = "
    SELECT * 
    FROM nhatkyhoatdong 
    WHERE $where_sql
    ORDER BY ThoiGian DESC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Lỗi SQL: " . $conn->error);
}
$stmt->bind_param($types . "ii", ...[...$params, $limit, $offset]);
$stmt->execute();
$logs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sql_count = "SELECT COUNT(*) as total FROM nhatkyhoatdong WHERE $where_sql";
$stmt_count = $conn->prepare($sql_count);
if (!empty($params)) {
    $stmt_count->bind_param($types, ...$params);
}
$stmt_count->execute();
$total_records = $stmt_count->get_result()->fetch_assoc()['total'];
$stmt_count->close();

$total_pages = ceil($total_records / $limit);

$actions_list = [];
$res_actions = $conn->query("SELECT DISTINCT HanhDong FROM nhatkyhoatdong ORDER BY HanhDong ASC");
while ($row = $res_actions->fetch_assoc()) {
    $actions_list[] = $row['HanhDong'];
}

include "../includes/header.php";
?>

<style>
    .filter-box {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        border: 1px solid #e2e8f0;
        margin-bottom: 20px;
    }
    .filter-row {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        align-items: center;
    }
    .filter-row input[type="text"], 
    .filter-row select {
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        font-size: 14px;
        min-width: 250px;
        outline: none;
    }
    .filter-row input:focus, 
    .filter-row select:focus {
        border-color: #16a34a;
    }
    .btn-filter {
        padding: 10px 20px;
        background: #f1f5f9;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
        font-size: 14px;
        color: #334155;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-filter:hover { background: #e2e8f0; }
    .btn-filter.primary { background: #16a34a; color: #fff; border-color: #16a34a; }
    .btn-filter.primary:hover { background: #15803d; }

    .log-table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #e2e8f0;
    }
    .log-table th {
        background: #f8fafc;
        text-align: left;
        padding: 14px 16px;
        font-size: 12px;
        text-transform: uppercase;
        color: #64748b;
        font-weight: 700;
        border-bottom: 2px solid #e2e8f0;
    }
    .log-table td {
        padding: 14px 16px;
        font-size: 14px;
        border-bottom: 1px solid #f1f5f9;
        color: #334155;
        vertical-align: middle;
    }
    .log-table tr:hover td { background: #f8fafc; }
    
    .badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
    }
    .badge-login { background: #e0f2fe; color: #0369a1; }
    .badge-logout { background: #f1f5f9; color: #475569; }
    .badge-download { background: #dcfce7; color: #166534; }
    .badge-update { background: #fef9c3; color: #854d0e; }
    .badge-delete { background: #fee2e2; color: #991b1b; }
    .badge-default { background: #e2e8f0; color: #334155; }

    .pagination {
        display: flex;
        gap: 6px;
        margin-top: 20px;
        justify-content: center;
    }
    .pagination a, .pagination span {
        padding: 8px 14px;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        text-decoration: none;
        color: #475569;
        font-size: 14px;
    }
    .pagination a:hover { background: #f1f5f9; }
    .pagination .active { background: #16a34a; color: #fff; border-color: #16a34a; }
</style>

<div class="layout">
    <?php include "../includes/sidebar.php"; ?>

    <main class="main">
        <div class="page-header">
            <div class="title-block">
                <h1>Nhật ký hệ thống</h1>
            </div>
        </div>

        <div class="filter-box">
            <form method="GET" action="">
                <div class="filter-row">
                    <input type="text" name="keyword" placeholder="Tìm theo người dùng / mô tả..." value="<?= htmlspecialchars($keyword) ?>">
                    
                    <select name="action">
                        <option value="">-- Hành động --</option>
                        <?php foreach ($actions_list as $act): ?>
                            <option value="<?= htmlspecialchars($act) ?>" <?= $action_filter === $act ? 'selected' : '' ?>>
                                <?= htmlspecialchars($act) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <button type="submit" class="btn-filter primary">
                        <i class="fa-solid fa-filter"></i> Lọc
                    </button>
                    <a href="logs.php" class="btn-filter" style="text-decoration:none;">
                        Đặt lại
                    </a>
                </div>
            </form>
        </div>

        <div style="overflow-x: auto;">
            <table class="log-table">
                <thead>
                    <tr>
                        <th>Thời gian</th>
                        <th>Người dùng</th>
                        <th>IP</th>
                        <th>Hành động</th>
                        <th>Đối tượng</th>
                        <th>Mô tả</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center; padding:40px; color:#94a3b8;">
                                <i class="fa-solid fa-clipboard-list" style="font-size:32px; margin-bottom:10px; display:block;"></i>
                                Không tìm thấy bản ghi nhật ký nào.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td style="white-space: nowrap;">
                                    <?= date('d/m/Y', strtotime($log['ThoiGian'])) ?><br>
                                    <small style="color:#64748b;"><?= date('H:i', strtotime($log['ThoiGian'])) ?></small>
                                </td>
                                <td style="font-weight: 600; color: #1e293b;">
                                    <?= htmlspecialchars($log['HoTen'] ?? 'Khách (Guest)') ?>
                                </td>
                                <td><?= htmlspecialchars($log['IPAddress'] ?? '-') ?></td>
                                <td>
                                    <?php 
                                        $act_name = strtoupper($log['HanhDong'] ?? '');
                                        $badge_class = 'badge-default';
                                        if ($act_name === 'LOGIN') $badge_class = 'badge-login';
                                        elseif ($act_name === 'LOGOUT') $badge_class = 'badge-logout';
                                        elseif ($act_name === 'DOWNLOAD') $badge_class = 'badge-download';
                                        elseif ($act_name === 'UPDATE') $badge_class = 'badge-update';
                                        elseif ($act_name === 'DELETE') $badge_class = 'badge-delete';
                                    ?>
                                    <span class="badge <?= $badge_class ?>"><?= htmlspecialchars($act_name) ?></span>
                                </td>
                                <td>
                                    <?= htmlspecialchars($log['DoiTuong'] ?? '') ?>
                                    <?= !empty($log['MaDoiTuong']) ? '#' . htmlspecialchars($log['MaDoiTuong']) : '' ?>
                                </td>
                                <td><?= htmlspecialchars($log['MoTa'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?keyword=<?= urlencode($keyword) ?>&action=<?= urlencode($action_filter) ?>&page=<?= $page - 1 ?>">« Trước</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="active"><?= $i ?></span>
                    <?php else: ?>
                        <a href="?keyword=<?= urlencode($keyword) ?>&action=<?= urlencode($action_filter) ?>&page=<?= $i ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?keyword=<?= urlencode($keyword) ?>&action=<?= urlencode($action_filter) ?>&page=<?= $page + 1 ?>">Sau »</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php include "../includes/footer.php"; ?>