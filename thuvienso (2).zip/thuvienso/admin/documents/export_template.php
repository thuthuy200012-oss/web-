<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once __DIR__ . '/../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Danh sách tài liệu');

$headers = [
    'A1' => 'Tên tài liệu',
    'B1' => 'Mã danh mục',
    'C1' => 'Loại tài liệu',
    'D1' => 'Năm XB',
    'E1' => 'Số trang',
    'F1' => 'Ngôn ngữ',
    'G1' => 'Tác giả',
    'H1' => 'GVHD',
];

foreach ($headers as $cell => $value) {
    $sheet->setCellValue($cell, $value);
}

$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '2563EB']],
    'alignment' => ['horizontal' => 'center', 'vertical' => 'center'],
];
$sheet->getStyle('A1:H1')->applyFromArray($headerStyle);

$danh_muc = [];
$res = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");
while ($dm = $res->fetch_assoc()) {
    $danh_muc[] = $dm;
}

$sheet->setCellValue('A2', 'Giáo trình Lập trình PHP');
$sheet->setCellValue('B2', $danh_muc[0]['MaDM'] ?? 'DM001');
$sheet->setCellValue('C2', 'Giáo trình');
$sheet->setCellValue('D2', date('Y'));
$sheet->setCellValue('E2', 200);
$sheet->setCellValue('F2', 'Tiếng Việt');
$sheet->setCellValue('G2', 'Nguyễn Văn A, Trần Thị B');
$sheet->setCellValue('H2', '');
$sheet2 = $spreadsheet->createSheet();
$sheet2->setTitle('Danh mục');
$sheet2->setCellValue('A1', 'Mã danh mục');
$sheet2->setCellValue('B1', 'Tên danh mục');
$sheet2->getStyle('A1:B1')->applyFromArray($headerStyle);
$row = 2;
foreach ($danh_muc as $dm) {
    $sheet2->setCellValue('A' . $row, $dm['MaDM']);
    $sheet2->setCellValue('B' . $row, $dm['TenDanhMuc']);
    $row++;
}

foreach (['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'] as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}
$sheet2->getColumnDimension('A')->setAutoSize(true);
$sheet2->getColumnDimension('B')->setAutoSize(true);
$filename = 'mau_import_tai_lieu_' . date('Ymd') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;