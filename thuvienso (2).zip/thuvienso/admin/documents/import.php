<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";

$autoload_path = __DIR__ . '/../../vendor/autoload.php';
if (!file_exists($autoload_path)) {
    die("Lỗi: Chưa cài đặt thư viện. Vui lòng chạy 'composer install' trong thư mục dự án.");
}
require_once $autoload_path;

use PhpOffice\PhpSpreadsheet\IOFactory;
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$base_url = "../../";
$page_title = "Import Tài liệu";

$msg = "";
$msg_type = "";
$import_result = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['fileExcel'])) {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = "danger";
    } else {

        $file = $_FILES['fileExcel'];

        if ($file['error'] !== 0) {
            $msg = "Lỗi upload file! (Mã lỗi: {$file['error']})";
            $msg_type = "danger";
            ghi_log($conn, 'OTHER', "Import thất bại: lỗi upload (mã {$file['error']})", 'tai_lieu', '');
        } else {
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, ['xlsx', 'xls', 'csv'])) {
                $msg = "Chỉ chấp nhận file Excel (.xlsx, .xls) hoặc CSV!";
                $msg_type = "danger";
                ghi_log($conn, 'OTHER', "Thử import file không hợp lệ: {$file['name']} (.$ext)", 'tai_lieu', '');
            } else {
                try {
                    $upload_dir = __DIR__ . '/../../uploads/imports/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }

                    $temp_file = $upload_dir . 'import_' . time() . '.' . $ext;
                    if (!move_uploaded_file($file['tmp_name'], $temp_file)) {
                        throw new Exception("Không thể lưu file tạm.");
                    }

                    $spreadsheet = IOFactory::load($temp_file);
                    $sheet = $spreadsheet->getActiveSheet();
                    $rows = $sheet->toArray();

                    if (count($rows) < 2) {
                        throw new Exception("File không có dữ liệu (cần ít nhất 1 dòng dữ liệu sau header).");
                    }

                    $danh_muc_map = [];
                    $res_dm = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai = 1");
                    while ($dm = $res_dm->fetch_assoc()) {
                        $danh_muc_map[$dm['MaDM']] = $dm['TenDanhMuc'];
                    }

                    $import_result = [
                        'success' => [],
                        'errors' => [],
                        'total' => 0
                    ];

                    $conn->begin_transaction();

                    try {
                        for ($i = 1; $i < count($rows); $i++) {
                            $row = $rows[$i];
                            $row_num = $i + 1;

                            if (empty(array_filter($row))) {
                                continue;
                            }

                            $import_result['total']++;
                            $ten_tl   = trim($row[0] ?? '');
                            $ma_dm    = trim($row[1] ?? '');
                            $loai_tl  = trim($row[2] ?? '');
                            $nam_xb   = (int)($row[3] ?? 0);
                            $so_trang = (int)($row[4] ?? 0);
                            $ngon_ngu = trim($row[5] ?? 'Tiếng Việt');
                            $tac_gia  = trim($row[6] ?? '');
                            $gvhd     = trim($row[7] ?? '');

                            $errors = [];

                            if (empty($ten_tl)) {
                                $errors[] = "Thiếu tên tài liệu";
                            }
                            if (empty($ma_dm)) {
                                $errors[] = "Thiếu mã danh mục";
                            } elseif (!isset($danh_muc_map[$ma_dm])) {
                                $errors[] = "Mã danh mục '$ma_dm' không tồn tại";
                            }
                            if (empty($tac_gia)) {
                                $errors[] = "Thiếu tác giả";
                            }
                            if (!empty($errors)) {
                                $import_result['errors'][] = [
                                    'row' => $row_num,
                                    'ten_tl' => $ten_tl ?: '(trống)',
                                    'message' => implode(', ', $errors)
                                ];
                                continue;
                            }
                            try {
                                $ma_tl = generate_unique_id($conn, 'tai_lieu', 'MaTL', 'TL');
                                $ma_nd = $_SESSION['MaND'];
                                $trang_thai = 'Đã duyệt';
                                $muc_truy_cap = 'Công khai';

                                $stmt = $conn->prepare("
                                    INSERT INTO tai_lieu
                                    (MaTL, TenTaiLieu, MaDM, MaND, LoaiTaiLieu, NamXuatBan, SoTrang,
                                     NgonNgu, TrangThai, MucTruyCap, NgayDuyet)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                                ");
                                $stmt->bind_param(
                                    "sssssiisss",
                                    $ma_tl, $ten_tl, $ma_dm, $ma_nd, $loai_tl, $nam_xb, $so_trang,
                                    $ngon_ngu, $trang_thai, $muc_truy_cap
                                );

                                if (!$stmt->execute()) {
                                    throw new Exception("Lỗi SQL: " . $stmt->error);
                                }
                                $stmt->close();

                                $arr_tg = array_map('trim', explode(',', $tac_gia));
                                foreach ($arr_tg as $tg_name) {
                                    if ($tg_name === '') continue;

                                    $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                                    $stmt_check->bind_param("s", $tg_name);
                                    $stmt_check->execute();
                                    $existing = $stmt_check->get_result()->fetch_assoc();
                                    $stmt_check->close();

                                    if ($existing) {
                                        $ma_tg = $existing['MaTG'];
                                    } else {
                                        $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                                        $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                                        $stmt_new->bind_param("ss", $ma_tg, $tg_name);
                                        $stmt_new->execute();
                                        $stmt_new->close();
                                    }

                                    $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'Tác giả')");
                                    $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                                    $stmt_link->execute();
                                    $stmt_link->close();
                                }

                                if (!empty($gvhd)) {
                                    $arr_gv = array_map('trim', explode(',', $gvhd));
                                    foreach ($arr_gv as $gv_name) {
                                        if ($gv_name === '') continue;

                                        $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                                        $stmt_check->bind_param("s", $gv_name);
                                        $stmt_check->execute();
                                        $existing = $stmt_check->get_result()->fetch_assoc();
                                        $stmt_check->close();

                                        if ($existing) {
                                            $ma_tg = $existing['MaTG'];
                                        } else {
                                            $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                                            $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                                            $stmt_new->bind_param("ss", $ma_tg, $gv_name);
                                            $stmt_new->execute();
                                            $stmt_new->close();
                                        }

                                        $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'GVHD')");
                                        $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                                        $stmt_link->execute();
                                        $stmt_link->close();
                                    }
                                }

                                $import_result['success'][] = [
                                    'row' => $row_num,
                                    'ma_tl' => $ma_tl,
                                    'ten_tl' => $ten_tl
                                ];

                            } catch (Exception $e) {
                                $import_result['errors'][] = [
                                    'row' => $row_num,
                                    'ten_tl' => $ten_tl ?: '(trống)',
                                    'message' => $e->getMessage()
                                ];
                            }
                        }

                        $conn->commit();

                        @unlink($temp_file);

                        $success_count = count($import_result['success']);
                        $error_count = count($import_result['errors']);

                        if ($success_count > 0) {
                            $msg = "Import thành công <b>$success_count</b> tài liệu!";
                            if ($error_count > 0) {
                                $msg .= " Có <b>$error_count</b> dòng bị lỗi (xem chi tiết bên dưới).";
                            }
                            $msg_type = ($error_count > 0) ? "warning" : "success";
                        } else {
                            $msg = "Không có dòng nào được import thành công!";
                            $msg_type = "danger";
                        }

                        ghi_log($conn, 'CREATE',
                            "Import tài liệu từ file: {$file['name']} - Thành công: $success_count, Lỗi: $error_count",
                            'tai_lieu', '');

                    } catch (Exception $e) {
                        $conn->rollback();
                        @unlink($temp_file);
                        throw $e;
                    }

                } catch (Exception $e) {
                    $msg = "Lỗi đọc file Excel: " . htmlspecialchars($e->getMessage());
                    $msg_type = "danger";
                    error_log("import.php error: " . $e->getMessage());
                }
            }
        }
    }
}

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<link rel="stylesheet" href="../../assets/css/dashboard.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <a href="index.php">Quản lý tài liệu</a>
            <span>›</span>
            <strong>Import tài liệu</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1><i class="fa-solid fa-file-import" style="color:#16a34a;"></i> Import Tài liệu</h1>
                <p>Nhập danh sách tài liệu hàng loạt từ file Excel</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Quay lại
                </a>
            </div>
        </div>

        <?php if ($msg != "") { ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php } ?>

        <?php if ($import_result): ?>
            <div class="card" style="padding: 20px; margin-bottom: 20px;">
                <h3 style="margin: 0 0 16px; font-size: 16px; color: #0f172a;">
                    <i class="fa-solid fa-chart-simple" style="color:#2563eb;"></i>
                    Kết quả Import
                </h3>

                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 20px;">
                    <div style="background: #dbeafe; padding: 16px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 800; color: #1e40af;"><?= $import_result['total'] ?></div>
                        <div style="font-size: 13px; color: #1e40af;">Tổng số dòng</div>
                    </div>
                    <div style="background: #dcfce7; padding: 16px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 800; color: #15803d;"><?= count($import_result['success']) ?></div>
                        <div style="font-size: 13px; color: #15803d;">Thành công</div>
                    </div>
                    <div style="background: #fee2e2; padding: 16px; border-radius: 8px; text-align: center;">
                        <div style="font-size: 28px; font-weight: 800; color: #b91c1c;"><?= count($import_result['errors']) ?></div>
                        <div style="font-size: 13px; color: #b91c1c;">Lỗi</div>
                    </div>
                </div>

                <?php if (!empty($import_result['errors'])): ?>
                    <h4 style="margin: 20px 0 12px; color: #b91c1c;">Chi tiết lỗi:</h4>
                    <table class="data-table" style="width: 100%;">
                        <thead>
                            <tr>
                                <th style="width: 80px;">Dòng</th>
                                <th>Tên tài liệu</th>
                                <th>Lỗi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($import_result['errors'] as $err): ?>
                                <tr>
                                    <td><b><?= (int)$err['row'] ?></b></td>
                                    <td><?= htmlspecialchars($err['ten_tl']) ?></td>
                                    <td style="color: #b91c1c;"><?= htmlspecialchars($err['message']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="card" style="padding: 24px; margin-bottom: 20px;">
            <h3 style="margin:0 0 20px; font-size:16px; color:#0f172a;">
                <i class="fa-solid fa-cloud-arrow-up" style="color:#2563eb;"></i> Chọn file Excel để import
            </h3>

            <form method="POST" enctype="multipart/form-data" id="importForm">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <div style="border: 2px dashed #cbd5e1; border-radius: 10px; padding: 40px; text-align: center; background: #f8fafc; transition: all 0.3s; cursor: pointer;" id="dropZone">
                    <input type="file" name="fileExcel" id="fileInput" accept=".xlsx,.xls,.csv" style="display:none;" required>
                    <div id="dropContent">
                        <i class="fa-solid fa-file-excel" style="font-size: 56px; color: #16a34a; margin-bottom: 16px; display: block;"></i>
                        <p style="margin: 0 0 8px; font-size: 16px; font-weight: 600; color: #1e293b;">
                            Kéo thả file Excel vào đây
                        </p>
                        <p style="margin: 0 0 20px; font-size: 14px; color: #64748b;">
                            hoặc click để chọn file (.xlsx, .xls, .csv)
                        </p>
                        <button type="button" class="btn btn-primary" onclick="document.getElementById('fileInput').click();">
                            <i class="fa-solid fa-folder-open"></i> Chọn file
                        </button>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <a href="index.php" class="btn btn-secondary">Hủy</a>
                    <button type="submit" class="btn btn-success" id="submitBtn">
                        <i class="fa-solid fa-file-import"></i> Bắt đầu Import
                    </button>
                </div>
            </form>
        </div>

        <div class="card" style="padding: 24px; background: linear-gradient(135deg, #eff6ff, #dbeafe); border-color: #bfdbfe;">
            <h3 style="margin: 0 0 16px; font-size: 15px; color: #1e40af;">
                <i class="fa-solid fa-circle-info"></i> Hướng dẫn
            </h3>
            <ol style="margin: 0 0 16px; padding-left: 20px; line-height: 2; color: #334155; font-size: 14px;">
                <li>Tải file mẫu: <a href="export_template.php" style="color: #2563eb; font-weight: 600;"><i class="fa-solid fa-download"></i> Tải file mẫu Excel</a></li>
                <li>Điền thông tin tài liệu vào file theo đúng cột</li>
                <li>Upload file lên trang này</li>
                <li>Hệ thống sẽ tự động import và báo cáo kết quả</li>
            </ol>

            <h4 style="margin: 16px 0 8px; font-size: 14px; color: #1e40af;">Cấu trúc file Excel:</h4>
            <table style="width: 100%; border-collapse: collapse; font-size: 13px; background: #fff; border-radius: 6px; overflow: hidden;">
                <thead>
                    <tr style="background: #1e40af; color: #fff;">
                        <th style="padding: 8px; text-align: left;">Cột A</th>
                        <th style="padding: 8px; text-align: left;">Cột B</th>
                        <th style="padding: 8px; text-align: left;">Cột C</th>
                        <th style="padding: 8px; text-align: left;">Cột D</th>
                        <th style="padding: 8px; text-align: left;">Cột E</th>
                        <th style="padding: 8px; text-align: left;">Cột F</th>
                        <th style="padding: 8px; text-align: left;">Cột G</th>
                        <th style="padding: 8px; text-align: left;">Cột H</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #e2e8f0;">
                        <td style="padding: 8px;">Tên tài liệu <span style="color:red;">*</span></td>
                        <td style="padding: 8px;">Mã danh mục <span style="color:red;">*</span></td>
                        <td style="padding: 8px;">Loại tài liệu</td>
                        <td style="padding: 8px;">Năm XB</td>
                        <td style="padding: 8px;">Số trang</td>
                        <td style="padding: 8px;">Ngôn ngữ</td>
                        <td style="padding: 8px;">Tác giả <span style="color:red;">*</span></td>
                        <td style="padding: 8px;">GVHD</td>
                    </tr>
                </tbody>
            </table>
            <p style="margin: 12px 0 0; font-size: 13px; color: #64748b;">
                <b>Lưu ý:</b> Dòng đầu tiên là header. Nhiều tác giả cách nhau dấu phẩy. Mã danh mục phải tồn tại trong hệ thống.
            </p>
        </div>

    </main>
</div>

<script>
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');

['dragenter', 'dragover'].forEach(evt => {
    dropZone.addEventListener(evt, e => {
        e.preventDefault();
        dropZone.style.borderColor = '#2563eb';
        dropZone.style.background = '#eff6ff';
    });
});

['dragleave', 'drop'].forEach(evt => {
    dropZone.addEventListener(evt, e => {
        e.preventDefault();
        dropZone.style.borderColor = '#cbd5e1';
        dropZone.style.background = '#f8fafc';
    });
});

dropZone.addEventListener('drop', e => {
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        fileInput.files = files;
        showFileName(files[0]);
    }
});

fileInput.addEventListener('change', function() {
    if (this.files.length > 0) showFileName(this.files[0]);
});

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showFileName(file) {
    document.getElementById('dropContent').innerHTML = `
        <i class="fa-solid fa-file-excel" style="font-size: 56px; color: #16a34a; margin-bottom: 16px; display: block;"></i>
        <p style="margin: 0 0 8px; font-size: 16px; font-weight: 700; color: #0f172a;">${escapeHtml(file.name)}</p>
        <p style="margin: 0 0 20px; font-size: 13px; color: #64748b;">${(file.size / 1024).toFixed(1)} KB</p>
        <button type="button" class="btn btn-secondary" onclick="event.stopPropagation(); resetFile();">
            <i class="fa-solid fa-rotate-left"></i> Chọn file khác
        </button>
    `;
}
function resetFile() {
    fileInput.value = '';
    document.getElementById('dropContent').innerHTML = `
        <i class="fa-solid fa-file-excel" style="font-size: 56px; color: #16a34a; margin-bottom: 16px; display: block;"></i>
        <p style="margin: 0 0 8px; font-size: 16px; font-weight: 600; color: #1e293b;">Kéo thả file Excel vào đây</p>
        <p style="margin: 0 0 20px; font-size: 14px; color: #64748b;">hoặc click để chọn file (.xlsx, .xls, .csv)</p>
        <button type="button" class="btn btn-primary" onclick="event.stopPropagation(); document.getElementById('fileInput').click();">
            <i class="fa-solid fa-folder-open"></i> Chọn file
        </button>
    `;
}

dropZone.addEventListener('click', e => {
    if (e.target.tagName === 'BUTTON' || e.target.closest('button')) return;
    fileInput.click();
});

document.getElementById('importForm').addEventListener('submit', function(e) {
    if (!fileInput.files.length) {
        e.preventDefault();
        Swal.fire({ icon: 'warning', title: 'Chưa chọn file', text: 'Vui lòng chọn file Excel!', confirmButtonColor: '#2563eb' });
        return;
    }
    const btn = document.getElementById('submitBtn');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang xử lý...';
    btn.disabled = true;
});
</script>

<?php include "../../includes/footer.php"; ?>