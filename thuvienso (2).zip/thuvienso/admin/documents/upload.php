<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/functions.php";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {

        $ten_tl       = trim($_POST['ten_tl'] ?? '');
        $ma_dm        = $_POST['ma_dm'] ?? '';
        $ma_nganh     = trim($_POST['ma_nganh'] ?? '');
        $loai_tl      = trim($_POST['loai_tl'] ?? '');
        $nam_xb       = (int)($_POST['nam_xb'] ?? 0);
        $so_trang     = (int)($_POST['so_trang'] ?? 0);
        $ngon_ngu     = trim($_POST['ngon_ngu'] ?? 'Tiếng Việt');
        $tom_tat      = trim($_POST['tom_tat'] ?? '');
        $tu_khoa      = trim($_POST['tu_khoa'] ?? '');
        $ma_nd        = $_SESSION['MaND'];
        if ($ma_nganh === '') $ma_nganh = null;

        $muc_truy_cap_raw = $_POST['muc_truy_cap'] ?? 'Công khai';
        $muc_truy_cap_hop_le = ['Công khai', 'Nội bộ'];
        $muc_truy_cap = in_array($muc_truy_cap_raw, $muc_truy_cap_hop_le, true)
            ? $muc_truy_cap_raw
            : 'Công khai';

        $trang_thai_raw = $_POST['trang_thai'] ?? 'Đã duyệt';
        $trang_thai_hop_le = ['Chờ duyệt', 'Đã duyệt', 'Từ chối'];
        $trang_thai = in_array($trang_thai_raw, $trang_thai_hop_le, true)
            ? $trang_thai_raw
            : 'Đã duyệt';

        $tac_gia_text  = trim($_POST['tac_gia_text'] ?? '');
        $gvhd_text     = trim($_POST['gvhd_text'] ?? '');

        if (empty($ten_tl) || empty($ma_dm)) {
            $msg = "Vui lòng nhập Tên tài liệu và chọn Danh mục!";
            $msg_type = 'danger';
        } else {
            try {
                $ma_tl = generate_unique_id($conn, 'tai_lieu', 'MaTL', 'TL');
            } catch (RuntimeException $e) {
                error_log("upload.php generate_id error: " . $e->getMessage());
                $ma_tl = null;
                $msg = "Hệ thống đang bận, vui lòng thử lại!";
                $msg_type = 'danger';
            }

            $duong_dan_file = null;
            $duong_dan_anh  = null;

            $MAX_FILE_SIZE = 20 * 1024 * 1024;

            if ($ma_tl !== null && isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['file_pdf'];

                if ($file['size'] > $MAX_FILE_SIZE) {
                    $msg = "File quá lớn! Tối đa " . ($MAX_FILE_SIZE / 1024 / 1024) . " MB.";
                    $msg_type = 'danger';
                }
                elseif (!in_array(strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)), ['pdf', 'doc', 'docx'])) {
                    $msg = "Định dạng không hợp lệ! Chỉ chấp nhận PDF, DOC, DOCX.";
                    $msg_type = 'danger';
                }
                else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $real_mime = finfo_file($finfo, $file['tmp_name']);
                    finfo_close($finfo);

                    $allowed_mimes = [
                        'application/pdf',
                        'application/msword',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/octet-stream',
                    ];

                    if (!in_array($real_mime, $allowed_mimes)) {
                        $msg = "Nội dung file không hợp lệ! (MIME: " . htmlspecialchars($real_mime) . ")";
                        $msg_type = 'danger';
                    } else {
                        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $filename = $ma_tl . '_' . time() . '.' . $ext;
                        $target = "../../uploads/documents/" . $filename;
                        if (!is_dir("../../uploads/documents/")) {
                            mkdir("../../uploads/documents/", 0755, true);
                        }
                        if (move_uploaded_file($file['tmp_name'], $target)) {
                            $duong_dan_file = 'uploads/documents/' . $filename;
                        }
                    }
                }
            }

            $MAX_IMAGE_SIZE = 5 * 1024 * 1024;

            if ($ma_tl !== null && isset($_FILES['anh_bia']) && $_FILES['anh_bia']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['anh_bia'];

                if ($file['size'] > $MAX_IMAGE_SIZE) {
                    $msg = "Ảnh bìa quá lớn! Tối đa " . ($MAX_IMAGE_SIZE / 1024 / 1024) . " MB.";
                    $msg_type = 'danger';
                }
                elseif (!in_array(strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp'])) {
                    $msg = "Ảnh bìa không hợp lệ! Chỉ chấp nhận JPG, PNG, WEBP.";
                    $msg_type = 'danger';
                }
                else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $real_mime = finfo_file($finfo, $file['tmp_name']);
                    finfo_close($finfo);

                    $allowed_img_mimes = ['image/jpeg', 'image/png', 'image/webp'];

                    if (!in_array($real_mime, $allowed_img_mimes)) {
                        $msg = "Ảnh bìa không hợp lệ! (MIME: " . htmlspecialchars($real_mime) . ")";
                        $msg_type = 'danger';
                    }
                    elseif (!@getimagesize($file['tmp_name'])) {
                        $msg = "File không phải là ảnh hợp lệ!";
                        $msg_type = 'danger';
                    }
                    else {
                        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $filename = 'cover_' . $ma_tl . '_' . time() . '.' . $ext;
                        $target = "../../uploads/covers/" . $filename;
                        if (!is_dir("../../uploads/covers/")) {
                            mkdir("../../uploads/covers/", 0755, true);
                        }
                        if (move_uploaded_file($file['tmp_name'], $target)) {
                            $duong_dan_anh = 'uploads/covers/' . $filename;
                        }
                    }
                }
            }

            if ($ma_tl !== null && $msg_type !== 'danger') {

                $conn->begin_transaction();

                try {
                    $stmt = $conn->prepare("
                        INSERT INTO tai_lieu
                        (MaTL, TenTaiLieu, MaDM, MaNganh, MaND, LoaiTaiLieu, NamXuatBan, SoTrang, NgonNgu,
                         TomTat, TuKhoa, FileTaiLieu, AnhBia, TrangThai, MucTruyCap, NgayDuyet)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->bind_param(
                        "ssssssiisssssss",
                        $ma_tl, $ten_tl, $ma_dm, $ma_nganh, $ma_nd, $loai_tl, $nam_xb, $so_trang, $ngon_ngu,
                        $tom_tat, $tu_khoa, $duong_dan_file, $duong_dan_anh, $trang_thai, $muc_truy_cap
                    );

                    if (!$stmt->execute()) {
                        error_log("upload.php: Insert tai_lieu failed - " . $conn->error . " | MaTL: $ma_tl");
                        throw new Exception("Không thể lưu tài liệu");
                    }
                    $stmt->close();

                    if ($tac_gia_text !== '') {
                        $arr_tg = array_map('trim', explode(',', $tac_gia_text));
                        foreach ($arr_tg as $tg_name) {
                            if ($tg_name === '') continue;

                            $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                            $stmt_check->bind_param("s", $tg_name);
                            $stmt_check->execute();
                            $existing = $stmt_check->get_result()->fetch_assoc();
                            $stmt_check->close();

                            if ($existing) {
                                $ma_tg = $existing['MaTG'];
                            } else {
                                $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                                $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                                $stmt_new->bind_param("ss", $ma_tg, $tg_name);
                                if (!$stmt_new->execute()) {
                                    throw new Exception("Không thể lưu tác giả");
                                }
                                $stmt_new->close();
                            }

                            $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'Tác giả')");
                            $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                            if (!$stmt_link->execute()) {
                                throw new Exception("Không thể liên kết tác giả");
                            }
                            $stmt_link->close();
                        }
                    }

                    if ($gvhd_text !== '') {
                        $arr_gv = array_map('trim', explode(',', $gvhd_text));
                        foreach ($arr_gv as $gv_name) {
                            if ($gv_name === '') continue;

                            $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                            $stmt_check->bind_param("s", $gv_name);
                            $stmt_check->execute();
                            $existing = $stmt_check->get_result()->fetch_assoc();
                            $stmt_check->close();

                            if ($existing) {
                                $ma_tg = $existing['MaTG'];
                            } else {
                                $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                                $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                                $stmt_new->bind_param("ss", $ma_tg, $gv_name);
                                if (!$stmt_new->execute()) {
                                    throw new Exception("Không thể lưu GVHD");
                                }
                                $stmt_new->close();
                            }

                            $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'GVHD')");
                            $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                            if (!$stmt_link->execute()) {
                                throw new Exception("Không thể liên kết GVHD");
                            }
                            $stmt_link->close();
                        }
                    }

                    $conn->commit();

                    $has_file = !empty($duong_dan_file) ? 'có file PDF' : 'chưa có file';
                    ghi_log($conn, 'CREATE',
                        "Upload tài liệu: $ten_tl (Mã: $ma_tl, $has_file)",
                        'tai_lieu', $ma_tl);

                    $_SESSION['flash_msg'] = "Đã thêm tài liệu <b>" . htmlspecialchars($ten_tl) . "</b>!";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: index.php");
                    exit();

                } catch (Exception $e) {
                    $conn->rollback();

                    if (!empty($duong_dan_file) && file_exists("../../" . $duong_dan_file)) {
                        @unlink("../../" . $duong_dan_file);
                    }
                    if (!empty($duong_dan_anh) && file_exists("../../" . $duong_dan_anh)) {
                        @unlink("../../" . $duong_dan_anh);
                    }

                    error_log("upload.php transaction error: " . $e->getMessage());
                    $msg = "Đã xảy ra lỗi khi lưu tài liệu. Vui lòng thử lại!";
                    $msg_type = 'danger';
                }
            }
        }
    }
}

$danh_muc_list = $conn->query("SELECT * FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");
$loai_list     = $conn->query("SELECT * FROM loaitailieu ORDER BY ThuTu");

$nganh_list = [];
$res_ng = $conn->query("SELECT MaNganh, TenNganh FROM nganh WHERE TrangThai = 1 ORDER BY ThuTu, TenNganh");
if ($res_ng) {
    while ($ng = $res_ng->fetch_assoc()) {
        $nganh_list[] = $ng;
    }
}

$existing_authors = [];
$res = $conn->query("SELECT HoTen FROM tac_gia WHERE TrangThai=1 ORDER BY HoTen");
while ($row = $res->fetch_assoc()) {
    $existing_authors[] = $row['HoTen'];
}

$page_title = "Thêm tài liệu";
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<link rel="stylesheet" href="../../assets/css/upload.css">

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <a href="index.php">Quản lý tài liệu</a>
            <span>›</span>
            <strong>Thêm tài liệu</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Thêm tài liệu mới</h1>
                <p>Upload file PDF, ảnh bìa và thông tin tác giả</p>
            </div>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <div class="card" style="padding: 28px;">

                <h3 style="margin:0 0 20px; font-size:15px; color:#475569;">Thông tin cơ bản</h3>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:20px;">
                    <div class="form-group" style="margin:0;">
                        <label>Tên tài liệu <span style="color:red;">*</span></label>
                        <input type="text" name="ten_tl" required placeholder="VD: Giáo trình Lập trình PHP">
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Danh mục <span style="color:red;">*</span></label>
                        <select name="ma_dm" required>
                            <option value="">-- Chọn danh mục --</option>
                            <?php while ($dm = $danh_muc_list->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($dm['MaDM']) ?>"><?= htmlspecialchars($dm['TenDanhMuc']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin:0;">
                        <label>Ngành</label>
                        <select name="ma_nganh">
                            <option value="">-- Chọn ngành --</option>
                            <?php foreach ($nganh_list as $ng): ?>
                                <option value="<?= htmlspecialchars($ng['MaNganh']) ?>">
                                    <?= htmlspecialchars($ng['TenNganh']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-hint">Chọn ngành mà tài liệu thuộc về (nếu có)</div>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Loại tài liệu</label>
                        <select name="loai_tl">
                            <option value="">-- Chọn loại --</option>
                            <?php while ($l = $loai_list->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($l['TenLoai']) ?>"><?= htmlspecialchars($l['TenLoai']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Năm xuất bản</label>
                        <input type="number" name="nam_xb" min="1900" max="<?= date('Y') + 1 ?>" value="<?= date('Y') ?>">
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Số trang</label>
                        <input type="number" name="so_trang" min="0">
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Ngôn ngữ</label>
                        <input type="text" name="ngon_ngu" value="Tiếng Việt">
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Mức truy cập</label>
                        <select name="muc_truy_cap">
                            <option value="Công khai">Công khai</option>
                            <option value="Nội bộ">Nội bộ</option>
                        </select>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Trạng thái</label>
                        <select name="trang_thai">
                            <option value="Đã duyệt" selected>Đã duyệt</option>
                            <option value="Chờ duyệt">Chờ duyệt</option>
                            <option value="Từ chối">Từ chối</option>
                        </select>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Từ khóa (cách nhau bằng dấu phẩy)</label>
                        <input type="text" name="tu_khoa" placeholder="PHP, Lập trình, Web">
                    </div>
                </div>

                <div class="form-group">
                    <label>Tóm tắt</label>
                    <textarea name="tom_tat" rows="4" placeholder="Mô tả ngắn về tài liệu..."></textarea>
                </div>

                <h3 style="margin:32px 0 20px; font-size:15px; color:#475569;">Tác giả & Người hướng dẫn</h3>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:20px;">
                    <div class="form-group" style="margin:0;">
                        <label>Nhóm tác giả <span style="color:red;">*</span></label>
                        <input type="text" name="tac_gia_text" id="tacGiaInput"
                               placeholder="Nhập tên tác giả, cách nhau dấu phẩy..."
                               autocomplete="off" list="tacGiaList">
                        <datalist id="tacGiaList">
                            <?php foreach ($existing_authors as $author): ?>
                                <option value="<?= htmlspecialchars($author) ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <div class="form-hint">VD: <code>Nguyễn Văn An, Trần Thị Bình</code></div>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label>Giảng viên hướng dẫn (nếu có)</label>
                        <input type="text" name="gvhd_text" id="gvhdInput"
                               placeholder="Nhập tên GVHD..."
                               autocomplete="off" list="gvhdList">
                        <datalist id="gvhdList">
                            <?php foreach ($existing_authors as $author): ?>
                                <option value="<?= htmlspecialchars($author) ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <div class="form-hint">Chỉ điền khi là Khóa luận / Luận văn / Đề tài NCKH.</div>
                    </div>
                </div>

                <h3 style="margin:32px 0 20px; font-size:15px; color:#475569;">File & ảnh bìa</h3>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                    <div class="form-group" style="margin:0;">
                        <label><i class="fa-solid fa-file-pdf"></i> File tài liệu (PDF/DOC/DOCX)</label>
                        <input type="file" name="file_pdf" accept=".pdf,.doc,.docx">
                        <div class="form-hint">Dung lượng tối đa 20MB. Nên dùng file PDF để user xem online.</div>
                    </div>

                    <div class="form-group" style="margin:0;">
                        <label><i class="fa-solid fa-image"></i> Ảnh bìa (JPG/PNG/WEBP)</label>
                        <input type="file" name="anh_bia" accept=".jpg,.jpeg,.png,.webp">
                        <div class="form-hint">Ảnh 600x800px (tỷ lệ 3:4) hiển thị đẹp nhất. Tối đa 5MB.</div>
                    </div>
                </div>

                <div style="display:flex; gap:12px; justify-content:flex-end; margin-top:32px; padding-top:24px; border-top:1px solid #f1f5f9;">
                    <a href="index.php" class="btn btn-secondary">Hủy</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu tài liệu
                    </button>
                </div>
            </div>
        </form>

    </main>
</div>

<?php include "../../includes/footer.php"; ?>