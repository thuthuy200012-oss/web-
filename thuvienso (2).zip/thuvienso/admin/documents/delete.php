<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";              
require_once "../../includes/delete_document.php";   

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$id = $_POST['id'] ?? '';
if (empty($id)) {
    header("Location: index.php");
    exit();
}

$result = delete_document($conn, $id);

if ($result['success']) {
    ghi_log($conn, 'DELETE',
        "Xóa tài liệu {$result['ma_tl']} ({$result['ten_tl']})",
        'tai_lieu', $result['ma_tl']);

    $_SESSION['flash_msg'] = "Đã xóa tài liệu <b>" . htmlspecialchars($result['ten_tl']) . "</b>!";
    $_SESSION['flash_type'] = 'success';
} else {
    $_SESSION['flash_msg'] = "Lỗi: " . htmlspecialchars($result['error']);
    $_SESSION['flash_type'] = 'danger';
}

header("Location: index.php");
exit();