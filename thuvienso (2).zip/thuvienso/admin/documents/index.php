<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/delete_document.php";

$msg = $_SESSION['flash_msg'] ?? '';
$msg_type = $_SESSION['flash_type'] ?? '';
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    $id = $_POST['id'] ?? '';
    $ten_tl = trim($_POST['ten_tl'] ?? '');
    $ma_dm = $_POST['ma_dm'] ?? '';
    $loai_tl = trim($_POST['loai_tl'] ?? '');
    $nam_xb = (int)($_POST['nam_xb'] ?? 0);
    $so_trang = (int)($_POST['so_trang'] ?? 0);
    $ngon_ngu = trim($_POST['ngon_ngu'] ?? '');
    $tom_tat = trim($_POST['tom_tat'] ?? '');
    $tu_khoa = trim($_POST['tu_khoa'] ?? '');
    
    $trang_thai_raw = $_POST['trang_thai'] ?? 'Đã duyệt';
    $trang_thai_hop_le = ['Chờ duyệt', 'Đã duyệt', 'Từ chối'];
    $trang_thai = in_array($trang_thai_raw, $trang_thai_hop_le, true)
        ? $trang_thai_raw
        : 'Đã duyệt';
    
    $muc_truy_cap_raw = $_POST['muc_truy_cap'] ?? null;
    $muc_truy_cap_hop_le = ['Công khai', 'Nội bộ'];
    $muc_truy_cap = ($muc_truy_cap_raw !== null && in_array($muc_truy_cap_raw, $muc_truy_cap_hop_le, true))
        ? $muc_truy_cap_raw
        : null;

    if (empty($ten_tl) || empty($ma_dm)) {
        $_SESSION['flash_msg'] = "Vui lòng nhập Tên và Danh mục!";
        $_SESSION['flash_type'] = 'danger';
    } else {
        $stmt_info = $conn->prepare("SELECT FileTaiLieu, AnhBia FROM tai_lieu WHERE MaTL = ? LIMIT 1");
        $stmt_info->bind_param("s", $id);
        $stmt_info->execute();
        $info_cu = $stmt_info->get_result()->fetch_assoc();
        $stmt_info->close();
        
        $file_cu = $info_cu['FileTaiLieu'] ?? null;
        $anh_cu  = $info_cu['AnhBia'] ?? null;
        
        $file_can_xoa = null;
        $anh_can_xoa  = null;
        
        $duong_dan_file_moi = null;
        $duong_dan_anh_moi = null;

        if (isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] === UPLOAD_ERR_OK && !empty($_FILES['file_pdf']['name'])) {
            $file = $_FILES['file_pdf'];
            $MAX_FILE_SIZE = 20 * 1024 * 1024;

            if ($file['size'] > $MAX_FILE_SIZE) {
                $_SESSION['flash_msg'] = "File PDF quá lớn! Tối đa 20MB.";
                $_SESSION['flash_type'] = 'danger';
                header("Location: index.php"); exit();
            }
            elseif (!in_array(strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)), ['pdf', 'doc', 'docx'])) {
                $_SESSION['flash_msg'] = "Định dạng không hợp lệ!";
                $_SESSION['flash_type'] = 'danger';
                header("Location: index.php"); exit();
            }
            else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $real_mime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);

                $allowed_mimes = [
                    'application/pdf',
                    'application/msword',
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'application/octet-stream',
                ];

                if (!in_array($real_mime, $allowed_mimes)) {
                    $_SESSION['flash_msg'] = "Nội dung file không hợp lệ!";
                    $_SESSION['flash_type'] = 'danger';
                    header("Location: index.php"); exit();
                } else {
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $filename = $id . '_' . time() . '.' . $ext;
                    if (!is_dir("../../uploads/documents/")) mkdir("../../uploads/documents/", 0755, true);
                    if (move_uploaded_file($file['tmp_name'], "../../uploads/documents/" . $filename)) {
                        $duong_dan_file_moi = 'uploads/documents/' . $filename;
                        if (!empty($file_cu) && $file_cu !== $duong_dan_file_moi) {
                            $file_can_xoa = $file_cu;
                        }
                    }
                }
            }
        }

        if (isset($_FILES['anh_bia']) && $_FILES['anh_bia']['error'] === UPLOAD_ERR_OK && !empty($_FILES['anh_bia']['name'])) {
            $file = $_FILES['anh_bia'];
            $MAX_IMAGE_SIZE = 5 * 1024 * 1024;

            if ($file['size'] > $MAX_IMAGE_SIZE) {
                $_SESSION['flash_msg'] = "Ảnh bìa quá lớn! Tối đa 5MB.";
                $_SESSION['flash_type'] = 'danger';
                header("Location: index.php"); exit();
            }
            else {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $real_mime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);

                if (!in_array($real_mime, ['image/jpeg', 'image/png', 'image/webp'])) {
                    $_SESSION['flash_msg'] = "Ảnh bìa không hợp lệ!";
                    $_SESSION['flash_type'] = 'danger';
                    header("Location: index.php"); exit();
                }
                elseif (!@getimagesize($file['tmp_name'])) {
                    $_SESSION['flash_msg'] = "File không phải là ảnh!";
                    $_SESSION['flash_type'] = 'danger';
                    header("Location: index.php"); exit();
                }
                else {
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $filename = 'cover_' . $id . '_' . time() . '.' . $ext;
                    if (!is_dir("../../uploads/covers/")) mkdir("../../uploads/covers/", 0755, true);
                    if (move_uploaded_file($file['tmp_name'], "../../uploads/covers/" . $filename)) {
                        $duong_dan_anh_moi = 'uploads/covers/' . $filename;
                        if (!empty($anh_cu) && $anh_cu !== $duong_dan_anh_moi) {
                            $anh_can_xoa = $anh_cu;
                        }
                    }
                }
            }
        }

        if ($duong_dan_file_moi && $duong_dan_anh_moi) {
            $stmt = $conn->prepare("UPDATE tai_lieu SET TenTaiLieu=?, MaDM=?, LoaiTaiLieu=?, NamXuatBan=?, SoTrang=?, NgonNgu=?, TomTat=?, TuKhoa=?, FileTaiLieu=?, AnhBia=?, TrangThai=? WHERE MaTL=?");
            $stmt->bind_param("sssiisssssss", $ten_tl, $ma_dm, $loai_tl, $nam_xb, $so_trang, $ngon_ngu, $tom_tat, $tu_khoa, $duong_dan_file_moi, $duong_dan_anh_moi, $trang_thai, $id);
        } elseif ($duong_dan_file_moi) {
            $stmt = $conn->prepare("UPDATE tai_lieu SET TenTaiLieu=?, MaDM=?, LoaiTaiLieu=?, NamXuatBan=?, SoTrang=?, NgonNgu=?, TomTat=?, TuKhoa=?, FileTaiLieu=?, TrangThai=? WHERE MaTL=?");
            $stmt->bind_param("sssiissssss", $ten_tl, $ma_dm, $loai_tl, $nam_xb, $so_trang, $ngon_ngu, $tom_tat, $tu_khoa, $duong_dan_file_moi, $trang_thai, $id);
        } elseif ($duong_dan_anh_moi) {
            $stmt = $conn->prepare("UPDATE tai_lieu SET TenTaiLieu=?, MaDM=?, LoaiTaiLieu=?, NamXuatBan=?, SoTrang=?, NgonNgu=?, TomTat=?, TuKhoa=?, AnhBia=?, TrangThai=? WHERE MaTL=?");
            $stmt->bind_param("sssiissssss", $ten_tl, $ma_dm, $loai_tl, $nam_xb, $so_trang, $ngon_ngu, $tom_tat, $tu_khoa, $duong_dan_anh_moi, $trang_thai, $id);
        } else {
            $stmt = $conn->prepare("UPDATE tai_lieu SET TenTaiLieu=?, MaDM=?, LoaiTaiLieu=?, NamXuatBan=?, SoTrang=?, NgonNgu=?, TomTat=?, TuKhoa=?, TrangThai=? WHERE MaTL=?");
            $stmt->bind_param("sssiisssss", $ten_tl, $ma_dm, $loai_tl, $nam_xb, $so_trang, $ngon_ngu, $tom_tat, $tu_khoa, $trang_thai, $id);
        }

        if ($stmt->execute()) {
            if (!empty($file_can_xoa)) {
                $path_cu = "../../" . $file_can_xoa;
                if (file_exists($path_cu) && is_file($path_cu)) {
                    @unlink($path_cu);
                }
            }
            if (!empty($anh_can_xoa)) {
                $path_cu = "../../" . $anh_can_xoa;
                if (file_exists($path_cu) && is_file($path_cu)) {
                    @unlink($path_cu);
                }
            }
            
            ghi_log($conn, 'UPDATE', "Cập nhật tài liệu $id ($ten_tl)", 'tai_lieu', $id);
            $_SESSION['flash_msg'] = "Đã cập nhật tài liệu <b>$ten_tl</b>!";
            $_SESSION['flash_type'] = 'success';
        } else {
            if (!empty($duong_dan_file_moi) && file_exists("../../" . $duong_dan_file_moi)) {
                @unlink("../../" . $duong_dan_file_moi);
            }
            if (!empty($duong_dan_anh_moi) && file_exists("../../" . $duong_dan_anh_moi)) {
                @unlink("../../" . $duong_dan_anh_moi);
            }
            
            error_log("admin/documents edit SQL Error: " . $conn->error . " | MaTL: $id");
            $_SESSION['flash_msg'] = "Đã xảy ra lỗi, vui lòng thử lại!";
            $_SESSION['flash_type'] = 'danger';
        }
        $stmt->close();
    }
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = $_POST['id'] ?? '';

    if (empty($id)) {
        $_SESSION['flash_msg'] = "Thiếu mã tài liệu!";
        $_SESSION['flash_type'] = 'danger';
    } else {
        $result = delete_document($conn, $id);

        if ($result['success']) {
            ghi_log($conn, 'DELETE',
                "Xóa tài liệu {$result['ma_tl']} ({$result['ten_tl']})",
                'tai_lieu', $result['ma_tl']);

            $_SESSION['flash_msg'] = "Đã xóa tài liệu <b>" . htmlspecialchars($result['ten_tl']) . "</b>!";
            $_SESSION['flash_type'] = 'success';
        } else {
            error_log("admin/documents delete Error: " . ($result['error'] ?? 'Unknown') . " | MaTL: $id");
            $_SESSION['flash_msg'] = "Không thể xóa tài liệu. Vui lòng thử lại!";
            $_SESSION['flash_type'] = 'danger';
        }
    }

    header("Location: index.php");
    exit();
}
$keyword = trim($_GET['q'] ?? '');
$trang_thai = $_GET['trang_thai'] ?? '';
$danh_muc_f = trim($_GET['danh_muc'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 15;
$offset = ($page - 1) * $per_page;

$where = "WHERE 1=1";
$params = []; $types = "";

if ($keyword !== '') {
    $where .= " AND (tl.TenTaiLieu LIKE ? OR tl.MaTL LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw; $types .= "ss";
}

if ($trang_thai !== '') {
    $where .= " AND tl.TrangThai = ?";
    $params[] = $trang_thai; $types .= "s";
}

if ($danh_muc_f !== '') {
    $where .= " AND tl.MaDM = ?";
    $params[] = $danh_muc_f; $types .= "s";
}

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu tl $where");
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];
$stmt->close();
$total_pages = max(1, ceil($total / $per_page));

$sql = "SELECT tl.*, dm.TenDanhMuc
        FROM tai_lieu tl
        LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
        $where
        ORDER BY tl.NgayDang DESC
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$docs = $stmt->get_result();
$stmt->close();

$danh_muc_list = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");

$page_title = "Quản lý tài liệu";
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Quản lý tài liệu</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Tài liệu</h1>
                <p>Thêm, sửa, xóa tài liệu và upload file PDF</p>
            </div>
            <a href="upload.php" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> Thêm tài liệu
            </a>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= htmlspecialchars(strip_tags($msg)) ?></div>
        <?php endif; ?>

        <div class="toolbar">
            <form method="GET" style="display:flex; gap:10px; flex:1; flex-wrap:wrap;">
                <input type="text" name="q" placeholder="Tìm tài liệu..." value="<?= htmlspecialchars($keyword) ?>">
                <select name="trang_thai">
                    <option value="">-- Trạng thái --</option>
                    <option value="Chờ duyệt" <?= $trang_thai === 'Chờ duyệt' ? 'selected' : '' ?>>Chờ duyệt</option>
                    <option value="Đã duyệt" <?= $trang_thai === 'Đã duyệt' ? 'selected' : '' ?>>Đã duyệt</option>
                    <option value="Từ chối" <?= $trang_thai === 'Từ chối' ? 'selected' : '' ?>>Từ chối</option>
                </select>
                <select name="danh_muc">
                    <option value="">-- Danh mục --</option>
                    <?php $danh_muc_list->data_seek(0); while ($dm = $danh_muc_list->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($dm['MaDM']) ?>" <?= $danh_muc_f === $dm['MaDM'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($dm['TenDanhMuc']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-filter"></i> Lọc
                </button>
                <?php if ($keyword || $trang_thai || $danh_muc_f): ?>
                    <a href="index.php" class="btn btn-secondary btn-sm">
                        <i class="fa-solid fa-rotate-left"></i> Đặt lại
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width:60px;">Ảnh bìa</th>
                        <th>Mã TL</th>
                        <th>Tên tài liệu</th>
                        <th>Danh mục</th>
                        <th>Loại</th>
                        <th>File PDF</th>
                        <th>Lượt xem</th>
                        <th>Lượt tải</th>
                        <th>Trạng thái</th>
                        <th style="width:180px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($docs && $docs->num_rows > 0): ?>
                        <?php while ($d = $docs->fetch_assoc()):
                            $json = htmlspecialchars(json_encode([
                                'MaTL' => $d['MaTL'],
                                'TenTaiLieu' => $d['TenTaiLieu'],
                                'MaDM' => $d['MaDM'],
                                'TenDanhMuc' => $d['TenDanhMuc'],
                                'LoaiTaiLieu' => $d['LoaiTaiLieu'],
                                'NamXuatBan' => $d['NamXuatBan'],
                                'SoTrang' => $d['SoTrang'],
                                'NgonNgu' => $d['NgonNgu'],
                                'TomTat' => $d['TomTat'],
                                'TuKhoa' => $d['TuKhoa'],
                                'FileTaiLieu' => $d['FileTaiLieu'],
                                'AnhBia' => $d['AnhBia'],
                                'SoLuotXem' => $d['SoLuotXem'],
                                'SoLuotTai' => $d['SoLuotTai'],
                                'TrangThai' => $d['TrangThai'],
                            ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                            <tr>
                                <td>
                                    <?php if (!empty($d['AnhBia']) && file_exists("../../" . $d['AnhBia'])): ?>
                                        <img src="../../pages/documents/stream.php?id=<?= urlencode($d['MaTL']) ?>&type=cover"
                                             style="width:40px; height:56px; object-fit:cover; border-radius:4px;"
                                             alt="">
                                    <?php else: ?>
                                        <div style="width:40px; height:56px; background:#e2e8f0; border-radius:4px; display:flex; align-items:center; justify-content:center; font-size:10px; color:#94a3b8;">No image</div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="code-badge"><?= htmlspecialchars($d['MaTL']) ?></span></td>
                                <td><b><?= htmlspecialchars($d['TenTaiLieu']) ?></b></td>
                                <td><?= htmlspecialchars($d['TenDanhMuc'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($d['LoaiTaiLieu'] ?? '—') ?></td>
                                <td>
                                    <?php if (!empty($d['FileTaiLieu']) && file_exists("../../" . $d['FileTaiLieu'])): ?>
                                        <span class="badge badge-success">Có file</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Chưa có</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= number_format($d['SoLuotXem']) ?></td>
                                <td><?= number_format($d['SoLuotTai']) ?></td>
                                <td>
                                    <?php if ($d['TrangThai'] === 'Đã duyệt'): ?>
                                        <span class="badge badge-success">Đã duyệt</span>
                                    <?php elseif ($d['TrangThai'] === 'Chờ duyệt'): ?>
                                        <span class="badge badge-warning">Chờ duyệt</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><?= htmlspecialchars($d['TrangThai']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon" onclick='openViewModal(<?= $json ?>)' title="Xem" style="background:#e0e7ff; color:#4338ca;">
                                            <i class="fa-solid fa-eye"></i>
                                        </button>
                                        <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)' title="Sửa">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>
                                        <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($d['MaTL'], ENT_QUOTES) ?>', '<?= htmlspecialchars($d['TenTaiLieu'], ENT_QUOTES) ?>')" title="Xóa">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr class="empty-row">
                            <td colspan="10">Chưa có tài liệu nào</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($keyword) ?>&trang_thai=<?= urlencode($trang_thai) ?>&danh_muc=<?= urlencode($danh_muc_f) ?>"
                       class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

    </main>
</div>

<div class="modal-backdrop" id="viewModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Chi tiết tài liệu</h3>
            <button class="modal-close" onclick="closeModal('viewModal')">&times;</button>
        </div>
        <div class="modal-body" id="viewBody"></div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('viewModal')">Đóng</button>
        </div>
    </div>
</div>

<div class="modal-backdrop" id="editModal">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3>Sửa tài liệu</h3>
            <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="editId">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Tên tài liệu <span class="required">*</span></label>
                        <input type="text" name="ten_tl" id="editTen" required>
                    </div>
                    <div class="form-group">
                        <label>Danh mục <span class="required">*</span></label>
                        <select name="ma_dm" id="editMaDM" required>
                            <option value="">-- Chọn --</option>
                            <?php
                            $danh_muc_list->data_seek(0);
                            while ($dm = $danh_muc_list->fetch_assoc()):
                            ?>
                                <option value="<?= $dm['MaDM'] ?>"><?= htmlspecialchars($dm['TenDanhMuc']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Loại tài liệu</label>
                        <input type="text" name="loai_tl" id="editLoai">
                    </div>
                    <div class="form-group">
                        <label>Năm xuất bản</label>
                        <input type="number" name="nam_xb" id="editNam">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Số trang</label>
                        <input type="number" name="so_trang" id="editSoTrang">
                    </div>
                    <div class="form-group">
                        <label>Ngôn ngữ</label>
                        <input type="text" name="ngon_ngu" id="editNgonNgu">
                    </div>
                </div>

                <div class="form-group">
                    <label>Từ khóa</label>
                    <input type="text" name="tu_khoa" id="editTuKhoa">
                </div>

                <div class="form-group">
                    <label>Tóm tắt</label>
                    <textarea name="tom_tat" id="editTomTat" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label>Trạng thái</label>
                    <select name="trang_thai" id="editTrangThai">
                        <option value="Đã duyệt">Đã duyệt</option>
                        <option value="Chờ duyệt">Chờ duyệt</option>
                        <option value="Từ chối">Từ chối</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Đổi file PDF (bỏ trống nếu không đổi)</label>
                    <input type="file" name="file_pdf" accept=".pdf,.doc,.docx">
                </div>

                <div class="form-group">
                    <label>Đổi ảnh bìa (bỏ trống nếu không đổi)</label>
                    <input type="file" name="anh_bia" accept=".jpg,.jpeg,.png,.webp">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Hủy</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Cập nhật
                </button>
            </div>
        </form>
    </div>
</div>

<form method="POST" id="deleteForm" style="display:none;">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
function openViewModal(d) {
    const cover = d.AnhBia
        ? `<img src="../../pages/documents/stream.php?id=${encodeURIComponent(d.MaTL)}&type=cover" alt="">`
        : `<i class="fa-solid fa-file-lines"></i>`;

    let html = `
        <div class="view-header">
            <div class="view-cover">${cover}</div>
            <div class="view-info">
                <h2>${escapeHtml(d.TenTaiLieu)}</h2>
                <div class="view-meta">
                    <div><b>Mã TL:</b> ${escapeHtml(d.MaTL)}</div>
                    <div><b>Danh mục:</b> ${escapeHtml(d.TenDanhMuc || '—')}</div>
                    <div><b>Loại:</b> ${escapeHtml(d.LoaiTaiLieu || '—')}</div>
                    <div><b>Năm XB:</b> ${escapeHtml(d.NamXuatBan || '—')}</div>
                    <div><b>Ngôn ngữ:</b> ${escapeHtml(d.NgonNgu || '—')}</div>
                    <div><b>Trạng thái:</b> ${escapeHtml(d.TrangThai)}</div>
                </div>
            </div>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px;">
            <div style="background:#f8fafc; padding:12px; border-radius:10px;">
                <div style="font-size:12px; color:#64748b;">Lượt xem</div>
                <div style="font-size:22px; font-weight:800; color:#2563eb;">${d.SoLuotXem}</div>
            </div>
            <div style="background:#f8fafc; padding:12px; border-radius:10px;">
                <div style="font-size:12px; color:#64748b;">Lượt tải</div>
                <div style="font-size:22px; font-weight:800; color:#16a34a;">${d.SoLuotTai}</div>
            </div>
        </div>
        ${d.TuKhoa ? `<div style="margin-bottom:14px;"><b style="color:#64748b; font-size:12px;">TỪ KHÓA:</b><br>${escapeHtml(d.TuKhoa)}</div>` : ''}
        ${d.TomTat ? `<div><b style="color:#64748b; font-size:12px;">TÓM TẮT:</b><p style="margin:6px 0; line-height:1.6;">${escapeHtml(d.TomTat)}</p></div>` : ''}
    `;

    document.getElementById('viewBody').innerHTML = html;
    document.getElementById('viewModal').classList.add('show');
}

function openEditModal(d) {
    document.getElementById('editId').value = d.MaTL || '';
    document.getElementById('editTen').value = d.TenTaiLieu || '';
    document.getElementById('editMaDM').value = d.MaDM || '';
    document.getElementById('editLoai').value = d.LoaiTaiLieu || '';
    document.getElementById('editNam').value = d.NamXuatBan || '';
    document.getElementById('editSoTrang').value = d.SoTrang || '';
    document.getElementById('editNgonNgu').value = d.NgonNgu || '';
    document.getElementById('editTuKhoa').value = d.TuKhoa || '';
    document.getElementById('editTomTat').value = d.TomTat || '';
    document.getElementById('editTrangThai').value = d.TrangThai || 'Đã duyệt';

    document.getElementById('editModal').classList.add('show');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}
document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => {
        if (e.target === m) m.classList.remove('show');
    });
});
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop.show').forEach(m => m.classList.remove('show'));
    }
});
function confirmDelete(id, name) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa tài liệu <b>${name}</b> (${id})?<br><small style="color:#dc2626;">File PDF và ảnh bìa cũng sẽ bị xóa!</small>`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

<?php include "../../includes/footer.php"; ?>