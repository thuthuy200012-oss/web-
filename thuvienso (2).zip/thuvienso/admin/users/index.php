<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/generate_id.php";   
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$current_role = $_SESSION['MaVaiTro'] ?? null;

if (empty($current_role)) {
    $stmt_r = $conn->prepare("SELECT MaVaiTro FROM nguoidung WHERE MaND = ? LIMIT 1");
    $stmt_r->bind_param("s", $_SESSION['MaND']);
    $stmt_r->execute();
    $row_r = $stmt_r->get_result()->fetch_assoc();
    $stmt_r->close();
    $current_role = $row_r['MaVaiTro'] ?? 'SV';
    $_SESSION['MaVaiTro'] = $current_role;
}

function can_manage_role(string $current_role, string $target_role): bool {
    if ($current_role === 'ADMIN') return true;
    if ($current_role === 'THUTHU') {
        return in_array($target_role, ['SV', 'GV'], true);
    }
    return false;
}

function get_user_role(mysqli $conn, string $ma_nd): ?string {
    $stmt = $conn->prepare("SELECT MaVaiTro FROM nguoidung WHERE MaND = ? LIMIT 1");
    $stmt->bind_param("s", $ma_nd);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row['MaVaiTro'] ?? null;
}

$per_page = 10;
$page     = max(1, (int)($_GET['page'] ?? 1));
$offset   = ($page - 1) * $per_page;

$keyword  = trim($_GET['keyword'] ?? '');
$vaitro_f = trim($_GET['vaitro'] ?? '');
$status_f = $_GET['status'] ?? '';
$sort     = $_GET['sort'] ?? 'NgayTao';
$order    = strtolower($_GET['order'] ?? 'desc') === 'asc' ? 'ASC' : 'DESC';

$sortable = ['MaND', 'HoTen', 'Email', 'NgayTao', 'LastLogin'];
$sort_col = in_array($sort, $sortable) ? $sort : 'NgayTao';

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $where_e = "WHERE 1=1";
    $params_e = []; $types_e = "";
    if (!empty($keyword)) {
        $where_e .= " AND (nd.HoTen LIKE ? OR nd.Email LIKE ? OR nd.MaND LIKE ? OR nd.MaSo LIKE ?)";
        $kw = "%$keyword%";
        $params_e[] = $kw; $params_e[] = $kw; $params_e[] = $kw; $params_e[] = $kw;
        $types_e .= "ssss";
    }
    if (!empty($vaitro_f)) {
        $where_e .= " AND nd.MaVaiTro = ?";
        $params_e[] = $vaitro_f; $types_e .= "s";
    }
    if ($status_f !== '') {
        $where_e .= " AND nd.TrangThai = ?";
        $params_e[] = (int)$status_f; $types_e .= "i";
    }

    $sql_e = "SELECT nd.MaND, nd.HoTen, nd.Email, nd.MaVaiTro, nd.MaSo, nd.SoDienThoai,
                     nd.TrangThai, nd.NgayTao, nd.LastLogin, pb.TenPhongBan
              FROM nguoidung nd
              LEFT JOIN phong_ban pb ON nd.MaPB = pb.MaPB
              $where_e
              ORDER BY nd.$sort_col $order";
    $stmt_e = $conn->prepare($sql_e);
    if (!empty($params_e)) $stmt_e->bind_param($types_e, ...$params_e);
    $stmt_e->execute();
    $data_e = $stmt_e->get_result();

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="danh-sach-tai-khoan-' . date('Y-m-d') . '.csv"');
    echo "\xEF\xBB\xBF";

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Mã ND', 'Họ tên', 'Email', 'Vai trò', 'Khoa/Phòng ban', 'Mã số', 'SĐT', 'Trạng thái', 'Ngày tạo', 'Đăng nhập cuối']);

    while ($row = $data_e->fetch_assoc()) {
        fputcsv($out, [
            $row['MaND'],
            $row['HoTen'],
            $row['Email'],
            $row['MaVaiTro'],
            $row['TenPhongBan'] ?? '',
            $row['MaSo'] ?? '',
            $row['SoDienThoai'] ?? '',
            $row['TrangThai'] == 1 ? 'Hoạt động' : 'Đã khóa',
            $row['NgayTao'],
            $row['LastLogin'] ?? 'Chưa đăng nhập',
        ]);
    }
    fclose($out);
    exit();
}

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {

        $action = $_POST['action'] ?? '';
        if ($action === 'add') {
            $hoTen   = trim($_POST['hoTen'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');
            $maSo    = trim($_POST['maSo'] ?? '');
            $vaitro  = $_POST['vaitro'] ?? 'SV';
            $matkhau = $_POST['matkhau'] ?? '';
            $maPB    = !empty($_POST['maPB']) ? $_POST['maPB'] : null;

            if (empty($hoTen) || empty($email) || empty($matkhau)) {
                $msg = "Vui lòng nhập đầy đủ Họ tên, Email và Mật khẩu!";
                $msg_type = 'danger';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $msg = "Email không hợp lệ!";
                $msg_type = 'danger';
            } elseif (!in_array($vaitro, ['ADMIN', 'THUTHU', 'GV', 'SV'])) {
                $msg = "Vai trò không hợp lệ!";
                $msg_type = 'danger';
            }
            elseif ($current_role !== 'ADMIN' && in_array($vaitro, ['ADMIN', 'THUTHU'])) {
                $msg = "Bạn không có quyền tạo tài khoản vai trò này!";
                $msg_type = 'danger';
            } else {
                $check = $conn->prepare("SELECT MaND FROM nguoidung WHERE Email = ?");
                $check->bind_param("s", $email);
                $check->execute();

                if ($check->get_result()->num_rows > 0) {
                    $msg = "Email <b>" . htmlspecialchars($email) . "</b> đã tồn tại!";
                    $msg_type = 'danger';
                } else {
                   
                    try {
                        $maND = generate_unique_id($conn, 'nguoidung', 'MaND', 'ND');
                    } catch (RuntimeException $e) {
                        error_log("admin/users add generate_id error: " . $e->getMessage());
                        $maND = null;
                        $msg = "Hệ thống đang bận, vui lòng thử lại!";
                        $msg_type = 'danger';
                    }

                    if ($maND !== null) {
                        $hash = password_hash($matkhau, PASSWORD_DEFAULT);

                        $stmt = $conn->prepare("
                            INSERT INTO nguoidung
                            (MaND, HoTen, Email, MatKhau, MaVaiTro, MaPB, MaSo, SoDienThoai, TrangThai)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                        ");
                        $stmt->bind_param("ssssssss", $maND, $hoTen, $email, $hash, $vaitro, $maPB, $maSo, $sdt);

                        if ($stmt->execute()) {
                            $msg = "Đã thêm tài khoản <b>" . htmlspecialchars($hoTen) . "</b> (Mã: " . htmlspecialchars($maND) . ")!";
                            $msg_type = 'success';

                            ghi_log($conn, 'CREATE',
                                "Tạo tài khoản $hoTen ($email) - vai trò $vaitro",
                                'nguoidung', $maND);
                        } else {
                            error_log("admin/users add SQL Error: " . $conn->error);
                            $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                            $msg_type = 'danger';
                        }
                        $stmt->close();
                    }
                }
                $check->close();
            }
        }
        elseif ($action === 'edit') {
            $id      = $_POST['id'] ?? '';
            $hoTen   = trim($_POST['hoTen'] ?? '');
            $email   = trim($_POST['email'] ?? '');
            $sdt     = trim($_POST['sdt'] ?? '');
            $maSo    = trim($_POST['maSo'] ?? '');
            $vaitro  = $_POST['vaitro'] ?? 'SV';
            $maPB    = !empty($_POST['maPB']) ? $_POST['maPB'] : null;
            $matkhau = trim($_POST['matkhau'] ?? '');

            $target_role = get_user_role($conn, $id);

            if ($target_role === null) {
                $msg = "Không tìm thấy tài khoản!";
                $msg_type = 'danger';
            }
            elseif ($id === $_SESSION['MaND'] && $vaitro !== $current_role) {
                $msg = "Không thể tự thay đổi vai trò của chính mình!";
                $msg_type = 'danger';
            }
            elseif (!can_manage_role($current_role, $target_role)) {
                $msg = "Bạn không có quyền sửa tài khoản này!";
                $msg_type = 'danger';
            }
            elseif ($current_role !== 'ADMIN' && in_array($vaitro, ['ADMIN', 'THUTHU'])) {
                $msg = "Bạn không có quyền gán vai trò này!";
                $msg_type = 'danger';
            }
            elseif (!in_array($vaitro, ['ADMIN', 'THUTHU', 'GV', 'SV'])) {
                $msg = "Vai trò không hợp lệ!";
                $msg_type = 'danger';
            } else {
                if (!empty($matkhau)) {
                    $hash = password_hash($matkhau, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE nguoidung SET HoTen=?, Email=?, MaVaiTro=?, MaPB=?, MaSo=?, SoDienThoai=?, MatKhau=? WHERE MaND=?");
                    $stmt->bind_param("ssssssss", $hoTen, $email, $vaitro, $maPB, $maSo, $sdt, $hash, $id);
                } else {
                    $stmt = $conn->prepare("UPDATE nguoidung SET HoTen=?, Email=?, MaVaiTro=?, MaPB=?, MaSo=?, SoDienThoai=? WHERE MaND=?");
                    $stmt->bind_param("sssssss", $hoTen, $email, $vaitro, $maPB, $maSo, $sdt, $id);
                }

                if ($stmt->execute()) {
                    $msg = "Đã cập nhật tài khoản <b>" . htmlspecialchars($hoTen) . "</b>!";
                    $msg_type = 'success';

                    $log_mota = "Cập nhật tài khoản $id ($hoTen)";
                    if ($target_role !== $vaitro) {
                        $log_mota .= " - đổi vai trò từ $target_role sang $vaitro";
                    }
                    if (!empty($matkhau)) {
                        $log_mota .= " - có đổi mật khẩu";
                    }
                    ghi_log($conn, 'UPDATE', $log_mota, 'nguoidung', $id);
                } else {
                    error_log("admin/users edit SQL Error: " . $conn->error . " | MaND: $id");
                    $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'reset_password') {
            $id = $_POST['id'] ?? '';

            $target_role = get_user_role($conn, $id);

            if ($id === $_SESSION['MaND']) {
                $msg = "Không thể reset mật khẩu của chính mình!";
                $msg_type = 'danger';
            } elseif ($target_role === null) {
                $msg = "Không tìm thấy tài khoản!";
                $msg_type = 'danger';
            } elseif (!can_manage_role($current_role, $target_role)) {
                $msg = "Bạn không có quyền reset mật khẩu tài khoản này!";
                $msg_type = 'danger';
            } else {
                $new_pass = '123456';
                $hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE nguoidung SET MatKhau = ? WHERE MaND = ?");
                $stmt->bind_param("ss", $hash, $id);
                if ($stmt->execute()) {
                    $msg = "Đã reset mật khẩu tài khoản <b>" . htmlspecialchars($id) . "</b> về <code>123456</code>!";
                    $msg_type = 'success';

                    ghi_log($conn, 'UPDATE',
                        "Reset mật khẩu tài khoản $id về mặc định 123456",
                        'nguoidung', $id);
                } else {
                    error_log("admin/users reset_password SQL Error: " . $conn->error . " | MaND: $id");
                    $msg = "Đã xảy ra lỗi, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'toggle_status') {
            $id = $_POST['id'] ?? '';

            $target_role = get_user_role($conn, $id);

            if ($id === $_SESSION['MaND']) {
                $msg = "Không thể khóa tài khoản đang đăng nhập!";
                $msg_type = 'danger';
            } elseif ($target_role === null) {
                $msg = "Không tìm thấy tài khoản!";
                $msg_type = 'danger';
            } elseif (!can_manage_role($current_role, $target_role)) {
                $msg = "Bạn không có quyền khóa/mở khóa tài khoản này!";
                $msg_type = 'danger';
            } else {
                $stmt = $conn->prepare("UPDATE nguoidung SET TrangThai = 1 - TrangThai WHERE MaND = ?");
                $stmt->bind_param("s", $id);
                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("SELECT TrangThai FROM nguoidung WHERE MaND = ? LIMIT 1");
                $stmt->bind_param("s", $id);
                $stmt->execute();
                $new = $stmt->get_result()->fetch_assoc()['TrangThai'] ?? 0;
                $stmt->close();

                $msg = $new == 1
                    ? "Đã mở khóa tài khoản <b>" . htmlspecialchars($id) . "</b>!"
                    : "Đã khóa tài khoản <b>" . htmlspecialchars($id) . "</b>!";
                $msg_type = $new == 1 ? 'success' : 'warning';

                $trang_thai_str = $new == 1 ? 'mở khóa' : 'khóa';
                ghi_log($conn, 'UPDATE',
                    "Đã $trang_thai_str tài khoản $id",
                    'nguoidung', $id);
            }
        }

    
        elseif ($action === 'delete') {
            $id = $_POST['id'] ?? '';

            $target_role = get_user_role($conn, $id);

            if ($id === $_SESSION['MaND']) {
                $msg = "Không thể xóa tài khoản đang đăng nhập!";
                $msg_type = 'danger';
            } elseif ($target_role === null) {
                $msg = "Không tìm thấy tài khoản!";
                $msg_type = 'danger';
            } elseif (!can_manage_role($current_role, $target_role)) {
                $msg = "Bạn không có quyền xóa tài khoản này!";
                $msg_type = 'danger';
            } else {
                $stmt_info = $conn->prepare("SELECT HoTen, Email FROM nguoidung WHERE MaND = ? LIMIT 1");
                $stmt_info->bind_param("s", $id);
                $stmt_info->execute();
                $info = $stmt_info->get_result()->fetch_assoc();
                $stmt_info->close();

                $stmt = $conn->prepare("DELETE FROM nguoidung WHERE MaND = ?");
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $msg = "Đã xóa tài khoản <b>" . htmlspecialchars($id) . "</b>!";
                    $msg_type = 'success';

                    $ho_ten_xoa = $info['HoTen'] ?? $id;
                    $email_xoa  = $info['Email'] ?? '';
                    ghi_log($conn, 'DELETE',
                        "Xóa tài khoản $id ($ho_ten_xoa - $email_xoa)",
                        'nguoidung', $id);
                } else {
                    error_log("admin/users delete SQL Error: " . $conn->error . " | MaND: $id");
                    $msg = "Không thể xóa tài khoản. Vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
        elseif ($action === 'bulk_action') {
            $ids = $_POST['ids'] ?? [];
            $bulk = $_POST['bulk'] ?? '';
            $success = 0; $failed = 0;
            $logged_ids = [];

            foreach ($ids as $id) {
                if ($id === $_SESSION['MaND']) { $failed++; continue; }

                $target_role = get_user_role($conn, $id);
                if ($target_role === null || !can_manage_role($current_role, $target_role)) {
                    $failed++;
                    continue;
                }

                if ($bulk === 'lock') {
                    $stmt = $conn->prepare("UPDATE nguoidung SET TrangThai = 0 WHERE MaND = ?");
                } elseif ($bulk === 'unlock') {
                    $stmt = $conn->prepare("UPDATE nguoidung SET TrangThai = 1 WHERE MaND = ?");
                } elseif ($bulk === 'delete') {
                    $stmt = $conn->prepare("DELETE FROM nguoidung WHERE MaND = ?");
                } else {
                    continue;
                }
                $stmt->bind_param("s", $id);
                if ($stmt->execute()) {
                    $success++;
                    $logged_ids[] = $id;
                } else {
                    error_log("admin/users bulk_action SQL Error: " . $conn->error . " | MaND: $id | bulk: $bulk");
                    $failed++;
                }
                $stmt->close();
            }

            $action_labels = ['lock' => 'khóa', 'unlock' => 'mở khóa', 'delete' => 'xóa'];
            $msg = "Đã " . ($action_labels[$bulk] ?? 'xử lý') . " <b>$success</b> tài khoản" . ($failed ? ", <b>$failed</b> lỗi!" : "!");
            $msg_type = $failed ? 'warning' : 'success';

            if ($success > 0) {
                $bulk_label = $action_labels[$bulk] ?? 'xử lý';
                $ids_str = implode(', ', array_slice($logged_ids, 0, 5));
                if (count($logged_ids) > 5) {
                    $ids_str .= '... (và ' . (count($logged_ids) - 5) . ' tài khoản khác)';
                }
                ghi_log($conn, 'UPDATE',
                    "Bulk $bulk_label $success tài khoản: $ids_str",
                    'nguoidung', '');
            }
        }
    }
}

$stats = ['ADMIN' => 0, 'THUTHU' => 0, 'GV' => 0, 'SV' => 0];
$r = $conn->query("SELECT MaVaiTro, COUNT(*) AS c FROM nguoidung GROUP BY MaVaiTro");
while ($row = $r->fetch_assoc()) {
    if (isset($stats[$row['MaVaiTro']])) $stats[$row['MaVaiTro']] = $row['c'];
}
$r = $conn->query("SELECT COUNT(*) AS c FROM nguoidung WHERE TrangThai = 0");
$stats['KHOA'] = $r->fetch_assoc()['c'];
$r = $conn->query("SELECT COUNT(*) AS c FROM nguoidung");
$tong_user = $r->fetch_assoc()['c'];

$where = "WHERE 1=1";
$params = []; $types = "";

if (!empty($keyword)) {
    $where .= " AND (nd.HoTen LIKE ? OR nd.Email LIKE ? OR nd.MaND LIKE ? OR nd.MaSo LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw; $params[] = $kw; $params[] = $kw;
    $types .= "ssss";
}
if (!empty($vaitro_f)) {
    $where .= " AND nd.MaVaiTro = ?";
    $params[] = $vaitro_f; $types .= "s";
}
if ($status_f !== '') {
    $where .= " AND nd.TrangThai = ?";
    $params[] = (int)$status_f; $types .= "i";
}

$stmt_count = $conn->prepare("SELECT COUNT(*) AS c FROM nguoidung nd $where");
if (!empty($params)) $stmt_count->bind_param($types, ...$params);
$stmt_count->execute();
$count_q = $stmt_count->get_result()->fetch_assoc()['c'];
$total_pages = max(1, ceil($count_q / $per_page));
$stmt_count->close();

$sql = "SELECT nd.*, vt.TenVaiTro, pb.TenPhongBan
        FROM nguoidung nd
        LEFT JOIN vaitro vt ON nd.MaVaiTro = vt.MaVaiTro
        LEFT JOIN phong_ban pb ON nd.MaPB = pb.MaPB
        $where
        ORDER BY nd.$sort_col $order
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$users = $stmt->get_result();

$vaitro_list = $conn->query("SELECT MaVaiTro, TenVaiTro FROM vaitro ORDER BY MaVaiTro");
$pb_list = $conn->query("SELECT MaPB, TenPhongBan FROM phong_ban WHERE TrangThai=1 ORDER BY TenPhongBan");

$page_title = "Quản lý Tài khoản";
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    .bulk-bar {
        display: none;
        background: linear-gradient(135deg, #1e40af, #2563eb);
        color: #fff;
        padding: 14px 20px;
        border-radius: 0px;
        margin-bottom: 14px;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
        animation: slideDown 0.3s ease;
        box-shadow: 0 8px 24px rgba(37, 99, 235, 0.3);
    }
    .bulk-bar.show { display: flex; }
    .bulk-bar-info {
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 600;
    }
    .bulk-bar-info b {
        background: rgba(255,255,255,0.2);
        padding: 3px 10px;
        border-radius: 999px;
        font-size: 14px;
    }
    .bulk-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    .bulk-actions .btn {
        background: rgba(255,255,255,0.15);
        color: #fff;
        border: 1px solid rgba(255,255,255,0.25);
        padding: 8px 16px;
        font-size: 13px;
    }
    .bulk-actions .btn:hover {
        background: rgba(255,255,255,0.25);
        transform: translateY(-1px);
    }
    .bulk-actions .btn-danger {
        background: rgba(220, 38, 38, 0.9);
        border-color: #dc2626;
    }

    .toast {
        position: fixed;
        top: 80px;
        right: 24px;
        padding: 16px 22px;
        border-radius: 12px;
        color: #fff;
        font-weight: 600;
        font-size: 14px;
        z-index: 99999;
        box-shadow: 0 12px 32px rgba(0,0,0,0.25);
        animation: slideIn 0.3s ease;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
    }
    .toast-success { background: linear-gradient(135deg, #16a34a, #15803d); }
    .toast-danger  { background: linear-gradient(135deg, #dc2626, #b91c1c); }
    .toast-warning { background: linear-gradient(135deg, #f59e0b, #d97706); }
    @keyframes slideIn {
        from { opacity: 0; transform: translateX(100%); }
        to   { opacity: 1; transform: translateX(0); }
    }

    .avatar-grad {
        width: 42px;
        height: 42px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 15px;
        color: #fff;
        flex-shrink: 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.12);
    }

    .toolbar input[type="text"] { min-width: 200px; }
    .data-table tr.selected { background: #eff6ff !important; }
</style>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <span>Quản lý tài khoản</span>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý Tài khoản</h1>
                <p>Quản lý người dùng, phân quyền và trạng thái hoạt động</p>
            </div>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-success">
                    Export CSV
                </a>

                <button onclick="openAddModal()" class="btn btn-primary">
                    Thêm tài khoản
                </button>
            </div>
        </div>

        <div class="stats-row">
            <a href="?" class="mini-stat">
                <div class="mini-icon" style="background:#dbeafe; color:#1d4ed8;">ND</div>
                <div class="mini-info">
                    <div class="num"><?= $tong_user ?></div>
                    <div class="lbl">Tổng cộng</div>
                </div>
            </a>
            <a href="?vaitro=ADMIN" class="mini-stat">
                <div class="mini-icon" style="background:#fee2e2; color:#b91c1c;">AD</div>
                <div class="mini-info">
                    <div class="num"><?= $stats['ADMIN'] ?></div>
                    <div class="lbl">Admin</div>
                </div>
            </a>
            <a href="?vaitro=THUTHU" class="mini-stat">
                <div class="mini-icon" style="background:#f3e8ff; color:#6d28d9;">TT</div>
                <div class="mini-info">
                    <div class="num"><?= $stats['THUTHU'] ?></div>
                    <div class="lbl">Thủ thư</div>
                </div>
            </a>
            <a href="?vaitro=GV" class="mini-stat">
                <div class="mini-icon" style="background:#cffafe; color:#0e7490;">GV</div>
                <div class="mini-info">
                    <div class="num"><?= $stats['GV'] ?></div>
                    <div class="lbl">Giảng viên</div>
                </div>
            </a>
            <a href="?vaitro=SV" class="mini-stat">
                <div class="mini-icon" style="background:#dcfce7; color:#15803d;">SV</div>
                <div class="mini-info">
                    <div class="num"><?= $stats['SV'] ?></div>
                    <div class="lbl">Sinh viên</div>
                </div>
            </a>
            <a href="?status=0" class="mini-stat">
                <div class="mini-icon" style="background:#f1f5f9; color:#64748b;">LK</div>
                <div class="mini-info">
                    <div class="num"><?= $stats['KHOA'] ?></div>
                    <div class="lbl">Bị khóa</div>
                </div>
            </a>
        </div>

        <div class="toolbar">
            <form method="GET" id="filterForm" style="display:flex; gap:10px; flex:1; flex-wrap:wrap; align-items:center;">
                <input type="text" id="searchInput" name="keyword" placeholder="Tìm tên, email, mã... (Ctrl+F)" value="<?= htmlspecialchars($keyword) ?>">
                <select name="vaitro" onchange="this.form.submit()">
                    <option value="">-- Tất cả vai trò --</option>
                    <option value="ADMIN"  <?= $vaitro_f=='ADMIN'  ?'selected':'' ?>>Quản trị viên</option>
                    <option value="THUTHU" <?= $vaitro_f=='THUTHU' ?'selected':'' ?>>Thủ thư</option>
                    <option value="GV"     <?= $vaitro_f=='GV'     ?'selected':'' ?>>Giảng viên</option>
                    <option value="SV"     <?= $vaitro_f=='SV'     ?'selected':'' ?>>Sinh viên</option>
                </select>
                <select name="status" onchange="this.form.submit()">
                    <option value="">-- Trạng thái --</option>
                    <option value="1" <?= $status_f==='1'?'selected':'' ?>>Hoạt động</option>
                    <option value="0" <?= $status_f==='0'?'selected':'' ?>>Đã khóa</option>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">Lọc</button>
                <?php if ($keyword || $vaitro_f || $status_f !== ''): ?>
                    <a href="?" class="btn btn-secondary btn-sm">Đặt lại</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="bulk-bar" id="bulkBar">
            <div class="bulk-bar-info">
                Đã chọn <b id="bulkCount">0</b> tài khoản
            </div>
            <div class="bulk-actions">
                <button type="button" class="btn" onclick="bulkAction('unlock')">
                    <i class="fa-solid fa-unlock"></i> Mở khóa
                </button>
                <button type="button" class="btn" onclick="bulkAction('lock')">
                    <i class="fa-solid fa-lock"></i> Khóa
                </button>
                <button type="button" class="btn btn-danger" onclick="bulkAction('delete')">
                    <i class="fa-solid fa-trash"></i> Xóa
                </button>
                <button type="button" class="btn" onclick="clearSelection()">
                    Bỏ chọn
                </button>
            </div>
        </div>

        <form method="POST" id="formBulk">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="bulk_action">
            <input type="hidden" name="bulk" id="bulkActionType">
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:40px;">
                                <input type="checkbox" id="masterCheck" onclick="toggleAll(this)">
                            </th>
                            <th class="sortable" onclick="sortBy('MaND')">
                                Mã ND <?= $sort_col=='MaND' ? ($order=='ASC'?'▲':'▼') : '⇅' ?>
                            </th>
                            <th class="sortable" onclick="sortBy('HoTen')">
                                Họ và Tên <?= $sort_col=='HoTen' ? ($order=='ASC'?'▲':'▼') : '⇅' ?>
                            </th>
                            <th>Vai trò</th>
                            <th>Khoa / Phòng ban</th>
                            <th>Mã số</th>
                            <th>SĐT</th>
                            <th class="sortable" onclick="sortBy('LastLogin')">
                                Đăng nhập cuối <?= $sort_col=='LastLogin' ? ($order=='ASC'?'▲':'▼') : '⇅' ?>
                            </th>
                            <th>Trạng thái</th>
                            <th style="width:180px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($users && $users->num_rows > 0): ?>
                            <?php while ($u = $users->fetch_assoc()):
                                $initial = mb_substr($u['HoTen'] ?? 'U', 0, 1);
                                $is_self = ($u['MaND'] === $_SESSION['MaND']);
                                $can_manage_this = can_manage_role($current_role, $u['MaVaiTro']);
                                $colors = [
                                    ['#2563eb', '#7c3aed'],
                                    ['#16a34a', '#15803d'],
                                    ['#ea580c', '#c2410c'],
                                    ['#dc2626', '#b91c1c'],
                                    ['#0891b2', '#0e7490'],
                                    ['#7c3aed', '#6d28d9'],
                                    ['#db2777', '#be185d'],
                                    ['#f59e0b', '#d97706'],
                                ];
                                $color = $colors[crc32($u['HoTen'] ?? '') % count($colors)];

                                $json = htmlspecialchars(json_encode([
                                    'MaND'        => $u['MaND'],
                                    'HoTen'       => $u['HoTen'],
                                    'Email'       => $u['Email'],
                                    'MaVaiTro'    => $u['MaVaiTro'],
                                    'TenVaiTro'   => $u['TenVaiTro'],
                                    'MaPB'        => $u['MaPB'],
                                    'TenPhongBan' => $u['TenPhongBan'],
                                    'MaSo'        => $u['MaSo'],
                                    'SoDienThoai' => $u['SoDienThoai'],
                                    'TrangThai'   => $u['TrangThai'],
                                    'NgayTao'     => $u['NgayTao'],
                                    'LastLogin'   => $u['LastLogin'] ?? null,
                                ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                            ?>
                                <tr>
                                    <td>
                                        <?php if (!$is_self && $can_manage_this): ?>
                                            <input type="checkbox" name="ids[]" value="<?= htmlspecialchars($u['MaND']) ?>" class="row-checkbox">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="code-badge"><?= htmlspecialchars($u['MaND']) ?></span>
                                    </td>
                                    <td>
                                        <div class="user-cell">
                                            <div class="avatar-grad" style="background: linear-gradient(135deg, <?= $color[0] ?>, <?= $color[1] ?>);">
                                                <?= htmlspecialchars($initial) ?>
                                            </div>
                                            <div>
                                                <div class="name">
                                                    <?= htmlspecialchars($u['HoTen']) ?>
                                                    <?php if ($is_self): ?>
                                                        <span style="color:#2563eb; font-size:11px;">(Bạn)</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="email"><?= htmlspecialchars($u['Email']) ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= htmlspecialchars($u['MaVaiTro'] ?? 'SV') ?>">
                                            <?= htmlspecialchars($u['TenVaiTro'] ?? $u['MaVaiTro']) ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($u['TenPhongBan'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($u['MaSo'] ?? '—') ?></td>
                                    <td><?= htmlspecialchars($u['SoDienThoai'] ?? '—') ?></td>
                                    <td>
                                        <?php if (!empty($u['LastLogin'])): ?>
                                            <small style="color:#475569;">
                                                <?= date('d/m/Y', strtotime($u['LastLogin'])) ?><br>
                                                <span style="color:#94a3b8;"><?= date('H:i', strtotime($u['LastLogin'])) ?></span>
                                            </small>
                                        <?php else: ?>
                                            <small style="color:#cbd5e1; font-style:italic;">Chưa ĐN</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ((int)$u['TrangThai'] === 1): ?>
                                            <span class="badge badge-active">Hoạt động</span>
                                        <?php else: ?>
                                            <span class="badge badge-locked">Đã khóa</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="actions">
                                            <button type="button" class="btn-icon" onclick='viewUser(<?= $json ?>)' title="Xem chi tiết" style="background:#e0e7ff; color:#4338ca;">
                                                <i class="fa-solid fa-eye"></i>
                                            </button>

                                            <?php if (!$is_self && $can_manage_this): ?>
                                                <button type="button" class="btn-icon btn-edit" onclick='openEditModal(<?= $json ?>)' title="Sửa">
                                                    <i class="fa-solid fa-pen"></i>
                                                </button>
                                                <button type="button" class="btn-icon" onclick="resetPassword('<?= htmlspecialchars($u['MaND'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['HoTen'], ENT_QUOTES) ?>')" title="Reset mật khẩu" style="background:#fef3c7; color:#d97706;">
                                                    <i class="fa-solid fa-key"></i>
                                                </button>
                                                <?php if ((int)$u['TrangThai'] === 1): ?>
                                                    <button type="button" class="btn-icon btn-lock" onclick="toggleStatus('<?= htmlspecialchars($u['MaND'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['HoTen'], ENT_QUOTES) ?>', 'khóa')" title="Khóa">
                                                        <i class="fa-solid fa-lock"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button type="button" class="btn-icon btn-unlock" onclick="toggleStatus('<?= htmlspecialchars($u['MaND'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['HoTen'], ENT_QUOTES) ?>', 'mở khóa')" title="Mở khóa">
                                                        <i class="fa-solid fa-unlock"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <button type="button" class="btn-icon btn-del" onclick="confirmDelete('<?= htmlspecialchars($u['MaND'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['HoTen'], ENT_QUOTES) ?>')" title="Xóa">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            <?php elseif ($is_self): ?>
                                                <button type="button" class="btn-icon" disabled title="Không thể tự thao tác">
                                                    <i class="fa-solid fa-ban"></i>
                                                </button>
                                            <?php else: ?>
                                                <span style="color:#94a3b8; font-size:11px; font-style:italic;">Không có quyền</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr class="empty-row">
                                <td colspan="10">
                                    Không tìm thấy tài khoản nào.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </form>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php
                $qs = $_GET;
                $qs['page'] = max(1, $page - 1);
                ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page<=1?'disabled':'' ?>">‹</a>

                <?php
                $start = max(1, $page - 2);
                $end = min($total_pages, $page + 2);
                if ($start > 1) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                for ($i = $start; $i <= $end; $i++):
                    $qs['page'] = $i;
                ?>
                    <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $i==$page?'active':'' ?>"><?= $i ?></a>
                <?php endfor;
                if ($end < $total_pages) echo '<span style="color:#94a3b8; padding:0 6px;">...</span>';
                ?>

                <?php $qs['page'] = min($total_pages, $page + 1); ?>
                <a href="?<?= http_build_query($qs) ?>" class="page-btn <?= $page>=$total_pages?'disabled':'' ?>">›</a>
            </div>
        <?php endif; ?>

        <div class="table-footer" style="margin-top:14px;">
            <span>Hiển thị <b><?= $users->num_rows ?></b> / <b><?= $count_q ?></b> tài khoản (Trang <?= $page ?>/<?= $total_pages ?>)</span>
        </div>

    </main>
</div>

<div class="modal-backdrop" id="addModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Thêm tài khoản mới</h3>
            <button class="modal-close" onclick="closeAddModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="add">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Họ và tên <span class="required">*</span></label>
                        <input type="text" name="hoTen" required placeholder="Nguyễn Văn A" autofocus>
                    </div>
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" required placeholder="email@thuvienso.edu.vn">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Mã số</label>
                        <input type="text" name="maSo" placeholder="SV001...">
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="sdt" placeholder="0912345678">
                    </div>
                </div>
                <div class="form-group">
                    <label>Vai trò <span class="required">*</span></label>
                    <div class="role-grid">
                        <div class="role-item">
                            <input type="radio" name="vaitro" id="v_sv" value="SV" checked>
                            <label for="v_sv">Sinh viên</label>
                        </div>
                        <div class="role-item">
                            <input type="radio" name="vaitro" id="v_gv" value="GV">
                            <label for="v_gv">Giảng viên</label>
                        </div>
                        <?php if ($current_role === 'ADMIN'): ?>
                            <div class="role-item">
                                <input type="radio" name="vaitro" id="v_tt" value="THUTHU">
                                <label for="v_tt">Thủ thư</label>
                            </div>
                            <div class="role-item">
                                <input type="radio" name="vaitro" id="v_ad" value="ADMIN">
                                <label for="v_ad">Admin</label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label>Khoa / Phòng ban</label>
                    <select name="maPB">
                        <option value="">-- Chưa chọn --</option>
                        <?php $pb_list->data_seek(0); while ($pb = $pb_list->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($pb['MaPB']) ?>"><?= htmlspecialchars($pb['TenPhongBan']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mật khẩu <span class="required">*</span></label>
                    <input type="text" name="matkhau" required value="123456">
                    <div class="form-hint">Mặc định <code>123456</code>, người dùng nên đổi sau.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeAddModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Thêm tài khoản</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Sửa tài khoản</h3>
            <button class="modal-close" onclick="closeEditModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal-body">
                <div class="form-row">
                    <div class="form-group">
                        <label>Họ và tên <span class="required">*</span></label>
                        <input type="text" name="hoTen" id="edit_hoTen" required>
                    </div>
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" id="edit_email" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Mã số</label>
                        <input type="text" name="maSo" id="edit_maSo">
                    </div>
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="sdt" id="edit_sdt">
                    </div>
                </div>
                <div class="form-group">
                    <label>Vai trò <span class="required">*</span></label>
                    <div class="role-grid">
                        <div class="role-item">
                            <input type="radio" name="vaitro" id="e_v_sv" value="SV">
                            <label for="e_v_sv">Sinh viên</label>
                        </div>
                        <div class="role-item">
                            <input type="radio" name="vaitro" id="e_v_gv" value="GV">
                            <label for="e_v_gv">Giảng viên</label>
                        </div>
                        <?php if ($current_role === 'ADMIN'): ?>
                            <div class="role-item">
                                <input type="radio" name="vaitro" id="e_v_tt" value="THUTHU">
                                <label for="e_v_tt">Thủ thư</label>
                            </div>
                            <div class="role-item">
                                <input type="radio" name="vaitro" id="e_v_ad" value="ADMIN">
                                <label for="e_v_ad">Admin</label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label>Khoa / Phòng ban</label>
                    <select name="maPB" id="edit_maPB">
                        <option value="">-- Chưa chọn --</option>
                        <?php $pb_list->data_seek(0); while ($pb = $pb_list->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($pb['MaPB']) ?>"><?= htmlspecialchars($pb['TenPhongBan']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Mật khẩu mới</label>
                    <input type="text" name="matkhau" id="edit_matkhau" placeholder="Để trống nếu không đổi">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-backdrop" id="viewModal">
    <div class="modal-content" style="max-width: 500px;">
        <div class="modal-header">
            <h3>Chi tiết tài khoản</h3>
            <button class="modal-close" onclick="closeViewModal()">&times;</button>
        </div>
        <div class="modal-body" id="viewBody"></div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeViewModal()">Đóng</button>
        </div>
    </div>
</div>

<form method="POST" id="formToggleStatus" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="toggle_status">
    <input type="hidden" name="id" id="toggle_id">
</form>

<form method="POST" id="formDeleteOne" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="delete_id">
</form>

<form method="POST" id="formResetPass" style="display:none;">
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" value="reset_password">
    <input type="hidden" name="id" id="reset_id">
</form>

<?php if (!empty($msg)): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    showToast(<?= json_encode($msg_type) ?>, <?= json_encode(strip_tags($msg)) ?>);
});
</script>
<?php endif; ?>

<script>
function showToast(type, message) {
    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.innerHTML = '<span>' + message + '</span>';
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function sortBy(col) {
    const url = new URL(window.location.href);
    const cur = url.searchParams.get('sort');
    const ord = url.searchParams.get('order') || 'asc';
    url.searchParams.set('sort', col);
    url.searchParams.set('order', (cur === col && ord === 'asc') ? 'desc' : 'asc');
    url.searchParams.set('page', 1);
    window.location.href = url.toString();
}

function toggleAll(master) {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.checked = master.checked;
        cb.closest('tr').classList.toggle('selected', master.checked);
    });
    updateBulk();
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.addEventListener('change', function() {
            this.closest('tr').classList.toggle('selected', this.checked);
            updateBulk();
        });
    });
});

function updateBulk() {
    const n = document.querySelectorAll('.row-checkbox:checked').length;
    document.getElementById('bulkCount').textContent = n;
    const bar = document.getElementById('bulkBar');
    bar.classList.toggle('show', n > 0);
    document.getElementById('masterCheck').checked =
        n > 0 && n === document.querySelectorAll('.row-checkbox').length;
}

function clearSelection() {
    document.querySelectorAll('.row-checkbox').forEach(cb => {
        cb.checked = false;
        cb.closest('tr').classList.remove('selected');
    });
    document.getElementById('masterCheck').checked = false;
    updateBulk();
}

function bulkAction(type) {
    const checked = document.querySelectorAll('.row-checkbox:checked');
    if (checked.length === 0) return;

    const labels = { lock: 'khóa', unlock: 'mở khóa', delete: 'xóa' };
    const colors = { lock: '#dc2626', unlock: '#16a34a', delete: '#dc2626' };

    Swal.fire({
        icon: type === 'delete' ? 'warning' : 'question',
        title: 'Xác nhận?',
        html: `Bạn sắp <b>${labels[type]}</b> <b>${checked.length}</b> tài khoản.<br>Hành động này không thể hoàn tác!`,
        showCancelButton: true,
        confirmButtonText: 'Xác nhận',
        cancelButtonText: 'Hủy',
        confirmButtonColor: colors[type]
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('bulkActionType').value = type;
            document.getElementById('formBulk').submit();
        }
    });
}

function confirmDelete(id, hoTen) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa tài khoản <b>${escapeHtml(hoTen)}</b> (${escapeHtml(id)})?<br>Hành động này không thể hoàn tác!`,
        showCancelButton: true,
        confirmButtonText: 'Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('delete_id').value = id;
            document.getElementById('formDeleteOne').submit();
        }
    });
}

function toggleStatus(id, hoTen, action) {
    const isLock = action === 'khóa';
    Swal.fire({
        icon: isLock ? 'warning' : 'question',
        title: isLock ? 'Khóa tài khoản?' : 'Mở khóa tài khoản?',
        html: `${isLock ? 'Khóa' : 'Mở khóa'} <b>${escapeHtml(hoTen)}</b> (${escapeHtml(id)})?`,
        showCancelButton: true,
        confirmButtonText: isLock ? 'Khóa' : 'Mở khóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: isLock ? '#dc2626' : '#16a34a'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('toggle_id').value = id;
            document.getElementById('formToggleStatus').submit();
        }
    });
}

function resetPassword(id, hoTen) {
    Swal.fire({
        icon: 'warning',
        title: 'Reset mật khẩu?',
        html: `Reset mật khẩu của <b>${escapeHtml(hoTen)}</b> (${escapeHtml(id)})<br>về mặc định <code>123456</code>?`,
        showCancelButton: true,
        confirmButtonText: 'Reset',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#d97706'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('reset_id').value = id;
            document.getElementById('formResetPass').submit();
        }
    });
}

function openAddModal() {
    document.getElementById('addModal').classList.add('show');
    setTimeout(() => document.querySelector('#addModal input[name="hoTen"]')?.focus(), 100);
}
function closeAddModal() {
    document.getElementById('addModal').classList.remove('show');
}

function openEditModal(data) {
    document.getElementById('edit_id').value = data.MaND || '';
    document.getElementById('edit_hoTen').value = data.HoTen || '';
    document.getElementById('edit_email').value = data.Email || '';
    document.getElementById('edit_maSo').value = data.MaSo || '';
    document.getElementById('edit_sdt').value = data.SoDienThoai || '';
    document.getElementById('edit_maPB').value = data.MaPB || '';
    document.getElementById('edit_matkhau').value = '';

    const roleMap = { 'SV': 'e_v_sv', 'GV': 'e_v_gv', 'THUTHU': 'e_v_tt', 'ADMIN': 'e_v_ad' };
    const radio = document.getElementById(roleMap[data.MaVaiTro] || 'e_v_sv');
    if (radio) radio.checked = true;

    document.getElementById('editModal').classList.add('show');
}
function closeEditModal() {
    document.getElementById('editModal').classList.remove('show');
}

function viewUser(data) {
    const initial = (data.HoTen || 'U').charAt(0).toUpperCase();
    const roleLabels = { ADMIN: 'Quản trị viên', THUTHU: 'Thủ thư', GV: 'Giảng viên', SV: 'Sinh viên' };

    let html = `
        <div style="text-align:center; margin-bottom:20px;">
            <div style="width:80px; height:80px; border-radius:50%; background: linear-gradient(135deg, #2563eb, #7c3aed); color:#fff; font-size:32px; font-weight:800; display:flex; align-items:center; justify-content:center; margin:0 auto 12px;">
                ${initial}
            </div>
            <h2 style="margin:0 0 4px; font-size:20px; color:#0f172a;">${escapeHtml(data.HoTen)}</h2>
            <span class="badge badge-${data.MaVaiTro}">${roleLabels[data.MaVaiTro] || data.MaVaiTro}</span>
        </div>
        <div style="display:grid; gap:12px;">
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Mã ND:</b> <span style="font-family:monospace; color:#1d4ed8;">${escapeHtml(data.MaND)}</span></div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Email:</b> ${escapeHtml(data.Email)}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Khoa/Phòng ban:</b> ${escapeHtml(data.TenPhongBan || '—')}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Mã số:</b> ${escapeHtml(data.MaSo || '—')}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">SĐT:</b> ${escapeHtml(data.SoDienThoai || '—')}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Trạng thái:</b> ${data.TrangThai == 1 ? '<span style="color:#16a34a;">Hoạt động</span>' : '<span style="color:#dc2626;">Đã khóa</span>'}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Ngày tạo:</b> ${escapeHtml(data.NgayTao || '—')}</div>
            <div><b style="color:#64748b; font-size:12px; text-transform:uppercase;">Đăng nhập cuối:</b> ${data.LastLogin ? escapeHtml(data.LastLogin) : '<i style="color:#94a3b8;">Chưa đăng nhập</i>'}</div>
        </div>
    `;
    document.getElementById('viewBody').innerHTML = html;
    document.getElementById('viewModal').classList.add('show');
}
function closeViewModal() {
    document.getElementById('viewModal').classList.remove('show');
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
        e.preventDefault();
        document.getElementById('searchInput')?.focus();
    }
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop.show').forEach(m => m.classList.remove('show'));
    }
});

document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => {
        if (e.target === m) m.classList.remove('show');
    });
});

const urlParams = new URLSearchParams(window.location.search);
if (urlParams.has('msg_success')) showToast('success', urlParams.get('msg_success'));
if (urlParams.has('msg_error')) showToast('danger', urlParams.get('msg_error'));
</script>

<?php include "../../includes/footer.php"; ?>