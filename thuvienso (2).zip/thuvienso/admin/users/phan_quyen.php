<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$base_url = "../../";
$page_title = "Phân quyền";
$current_page = 'phan-quyen';

$msg = '';
$msg_type = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ!";
        $msg_type = 'danger';
    } else {
        $phan_quyen = $_POST['quyen'] ?? [];

        $conn->begin_transaction();
        try {
            $conn->query("DELETE FROM vai_tro_quyen WHERE MaVaiTro != 'ADMIN'");

            if (!empty($phan_quyen)) {
                $stmt = $conn->prepare("INSERT INTO vai_tro_quyen (MaVaiTro, MaQuyen, ChoPhep) VALUES (?, ?, 1)");
                foreach ($phan_quyen as $ma_vt => $quyens) {
                    if ($ma_vt === 'ADMIN') continue;
                    foreach ($quyens as $ma_q => $val) {
                        if ($val == 1) {
                            $stmt->bind_param("ss", $ma_vt, $ma_q);
                            $stmt->execute();
                        }
                    }
                }
                $stmt->close();
            }

            $conn->commit();
            ghi_log($conn, 'UPDATE', "Cập nhật phân quyền", 'vai_tro_quyen', '');
            $msg = "Đã lưu phân quyền thành công!";
            $msg_type = 'success';
        } catch (Exception $e) {
            $conn->rollback();
            error_log("phan_quyen save error: " . $e->getMessage());
            $msg = "Đã xảy ra lỗi!";
            $msg_type = 'danger';
        }
    }
}
$vai_tro_list = [];
$res_vt = $conn->query("SELECT * FROM vaitro ORDER BY MaVaiTro ASC");
if ($res_vt) {
    while ($vt = $res_vt->fetch_assoc()) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM nguoidung WHERE MaVaiTro = ?");
        $stmt->bind_param("s", $vt['MaVaiTro']);
        $stmt->execute();
        $vt['SoNguoiDung'] = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
        $stmt->close();
        $vai_tro_list[] = $vt;
    }
}

$quyen_list = [];
$res_q = $conn->query("SELECT * FROM quyen ORDER BY ThuTu ASC");
if ($res_q) {
    while ($q = $res_q->fetch_assoc()) {
        $quyen_list[] = $q;
    }
}

$matrix = [];
$res_m = $conn->query("SELECT MaVaiTro, MaQuyen, ChoPhep FROM vai_tro_quyen WHERE ChoPhep = 1");
if ($res_m) {
    while ($m = $res_m->fetch_assoc()) {
        $matrix[$m['MaVaiTro']][$m['MaQuyen']] = true;
    }
}

include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    .perm-page {
        max-width: 1200px;
    }

    .perm-desc {
        color: #64748b;
        font-size: 14px;
        margin-bottom: 24px;
        line-height: 1.6;
    }

    .perm-desc b {
        color: #0c1e3e;
    }

    .perm-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        overflow-x: auto;
    }

    .perm-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 900px;
    }

    .perm-table thead {
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
    }

    .perm-table th {
        padding: 16px 12px;
        text-align: left;
        font-size: 11.5px;
        font-weight: 800;
        color: #475569;
        letter-spacing: 0.6px;
        text-transform: uppercase;
        white-space: nowrap;
    }

    .perm-table th.text-center {
        text-align: center;
    }

    .perm-table td {
        padding: 18px 12px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }

    .perm-table tbody tr:last-child td {
        border-bottom: none;
    }

    .perm-table tbody tr:hover {
        background: #fafbfc;
    }

    .role-cell {
        padding-left: 20px !important;
    }

    .role-name {
        font-weight: 700;
        color: #0c1e3e;
        font-size: 14px;
        margin-bottom: 3px;
    }

    .role-code {
        font-size: 12px;
        color: #94a3b8;
        font-family: monospace;
    }

    .count-cell {
        text-align: center;
        font-weight: 700;
        color: #0c1e3e;
        font-size: 15px;
    }

    .check-cell {
        text-align: center;
    }

    .perm-checkbox {
        width: 18px;
        height: 18px;
        cursor: pointer;
        accent-color: #2563eb;
        vertical-align: middle;
    }

    .perm-checkbox:disabled {
        cursor: not-allowed;
        opacity: 0.7;
    }

    .perm-actions {
        margin-top: 24px;
    }

    .btn-save-perm {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 28px;
        background: linear-gradient(135deg, #16a34a, #22c55e);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.2s;
        box-shadow: 0 2px 6px rgba(22, 163, 74, 0.3);
    }

    .btn-save-perm:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(22, 163, 74, 0.4);
    }
</style>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <nav class="breadcrumb">
            <a href="../index.php">Trang chủ Admin</a>
            <span>›</span>
            <strong>Phân quyền</strong>
        </nav>

        <div class="page-header">
            <div class="title-block">
                <h1>Phân quyền</h1>
            </div>
        </div>

        <div class="perm-page">
            <p class="perm-desc">
                Tick chọn quyền cho từng vai trò rồi bấm <b>Lưu thay đổi</b>.
                <b>Super Admin</b> mặc định có toàn quyền hệ thống.
            </p>

            <?php if ($msg): ?>
                <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
                <input type="hidden" name="save" value="1">

                <div class="perm-card">
                    <table class="perm-table">
                        <thead>
                            <tr>
                                <th style="width: 220px;">Vai trò</th>
                                <th class="text-center" style="width: 120px;">Số người<br>dùng</th>
                                <?php foreach ($quyen_list as $q): ?>
                                    <th class="text-center" style="min-width: 130px;">
                                        <?= htmlspecialchars(mb_strtoupper($q['TenQuyen'], 'UTF-8')) ?>
                                    </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vai_tro_list as $vt):
                                $ma_vt = $vt['MaVaiTro'];
                                $is_admin = ($ma_vt === 'ADMIN');
                            ?>
                                <tr>
                                    <td class="role-cell">
                                        <div class="role-name"><?= htmlspecialchars($vt['TenVaiTro']) ?></div>
                                        <div class="role-code"><?= htmlspecialchars(strtolower($ma_vt)) ?></div>
                                    </td>
                                    <td class="count-cell"><?= (int)$vt['SoNguoiDung'] ?></td>
                                    <?php foreach ($quyen_list as $q):
                                        $ma_q = $q['MaQuyen'];
                                        $checked = $is_admin || !empty($matrix[$ma_vt][$ma_q]);
                                    ?>
                                        <td class="check-cell">
                                            <input type="checkbox"
                                                   class="perm-checkbox"
                                                   name="quyen[<?= htmlspecialchars($ma_vt) ?>][<?= htmlspecialchars($ma_q) ?>]"
                                                   value="1"
                                                   <?= $checked ? 'checked' : '' ?>
                                                   <?= $is_admin ? 'disabled' : '' ?>>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="perm-actions">
                    <button type="submit" class="btn-save-perm">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu thay đổi
                    </button>
                </div>
            </form>
        </div>

    </main>
</div>

<?php include "../../includes/footer.php"; ?>