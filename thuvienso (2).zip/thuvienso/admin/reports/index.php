<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";

$today = date('Y-m-d');
$total_today = $conn->query("SELECT COUNT(*) AS c FROM luot_truy_cap WHERE DATE(ThoiGian) = '$today'")->fetch_assoc()['c'] ?? 0;
$total_7d    = $conn->query("SELECT COUNT(*) AS c FROM luot_truy_cap WHERE ThoiGian >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['c'] ?? 0;
$total_30d   = $conn->query("SELECT COUNT(*) AS c FROM luot_truy_cap WHERE ThoiGian >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc()['c'] ?? 0;
$total_all   = $conn->query("SELECT COUNT(*) AS c FROM luot_truy_cap")->fetch_assoc()['c'] ?? 0;

$tuan_labels = [];
$tuan_data = [];
for ($i = 11; $i >= 0; $i--) {
    $start = date('Y-m-d', strtotime("monday this week -$i week"));
    $end   = date('Y-m-d', strtotime("sunday this week -$i week"));
    $tuan_labels[] = 'Tuần ' . date('d/m', strtotime($start));

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM luot_truy_cap WHERE DATE(ThoiGian) BETWEEN ? AND ?");
    $stmt->bind_param("ss", $start, $end);
    $stmt->execute();
    $tuan_data[] = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
}

$thang_labels = [];
$thang_data = [];
for ($i = 11; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i months"));
    $thang_labels[] = date('m/Y', strtotime("-$i months"));

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM luot_truy_cap WHERE DATE_FORMAT(ThoiGian, '%Y-%m') = ?");
    $stmt->bind_param("s", $ym);
    $stmt->execute();
    $thang_data[] = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
}

$nam_labels = [];
$nam_data = [];
$r = $conn->query("
    SELECT YEAR(ThoiGian) AS Nam, COUNT(*) AS c
    FROM luot_truy_cap
    GROUP BY YEAR(ThoiGian)
    ORDER BY Nam ASC
");
while ($row = $r->fetch_assoc()) {
    $nam_labels[] = $row['Nam'];
    $nam_data[] = (int)$row['c'];
}

$trend_labels = [];
$trend_docs = [];
$trend_views = [];
$trend_downloads = [];

for ($i = 11; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i months"));
    $trend_labels[] = date('m/Y', strtotime("-$i months"));

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE DATE_FORMAT(NgayDang, '%Y-%m') = ?");
    $stmt->bind_param("s", $ym);
    $stmt->execute();
    $trend_docs[] = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lichsudoc WHERE DATE_FORMAT(ThoiGian, '%Y-%m') = ? AND HanhDong = 'xem'");
    $stmt->bind_param("s", $ym);
    $stmt->execute();
    $trend_views[] = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();

    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lichsudoc WHERE DATE_FORMAT(ThoiGian, '%Y-%m') = ? AND HanhDong = 'tai'");
    $stmt->bind_param("s", $ym);
    $stmt->execute();
    $trend_downloads[] = (int)$stmt->get_result()->fetch_assoc()['c'];
    $stmt->close();
}
$theloai_labels = [];
$theloai_data = [];
$r = $conn->query("
    SELECT LoaiTaiLieu, COUNT(*) AS c
    FROM tai_lieu
    WHERE TrangThai = 'Đã duyệt' AND LoaiTaiLieu IS NOT NULL AND LoaiTaiLieu <> ''
    GROUP BY LoaiTaiLieu
    ORDER BY c DESC
");
while ($row = $r->fetch_assoc()) {
    $theloai_labels[] = $row['LoaiTaiLieu'];
    $theloai_data[] = (int)$row['c'];
}

$tailieu_nam_labels = [];
$tailieu_nam_data = [];
$r = $conn->query("
    SELECT NamXuatBan, COUNT(*) AS c
    FROM tai_lieu
    WHERE TrangThai = 'Đã duyệt' AND NamXuatBan > 0
    GROUP BY NamXuatBan
    ORDER BY NamXuatBan ASC
");
while ($row = $r->fetch_assoc()) {
    $tailieu_nam_labels[] = $row['NamXuatBan'];
    $tailieu_nam_data[] = (int)$row['c'];
}
$top_pho_bien = $conn->query("
    SELECT MaTL, TenTaiLieu, SoLuotXem, SoLuotTai
    FROM tai_lieu
    WHERE TrangThai = 'Đã duyệt'
    ORDER BY SoLuotXem DESC
    LIMIT 10
");

$top_moi = $conn->query("
    SELECT MaTL, TenTaiLieu, NgayDang
    FROM tai_lieu
    WHERE TrangThai = 'Đã duyệt'
    ORDER BY NgayDang DESC
    LIMIT 10
");

$page_title = "Thống kê & Báo cáo";
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<link rel="stylesheet" href="../../assets/css/reports.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">

        <div class="page-header">
            <div class="title-block">
                <h1><i class="fa-solid fa-chart-pie" style="color:#16a34a;"></i> Thống kê & Báo cáo</h1>
            </div>
        </div>
        <div class="stats" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:16px; margin-bottom:24px;">
            <div class="stat-box" style="background:#fff; border:1px solid #e2e8f0; border-left:4px solid #16a34a; padding:18px; display:flex; align-items:center; gap:14px;">
                <div style="width:48px; height:48px; background:linear-gradient(135deg,#16a34a,#22c55e); border-radius:8px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:20px;">
                    <i class="fa-solid fa-person-walking-arrow-right"></i>
                </div>
                <div>
                    <div style="font-size:24px; font-weight:800; color:#0c1e3e; line-height:1;"><?= number_format($total_today) ?></div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">Lượt truy cập hôm nay</div>
                </div>
            </div>

            <div class="stat-box" style="background:#fff; border:1px solid #e2e8f0; border-left:4px solid #16a34a; padding:18px; display:flex; align-items:center; gap:14px;">
                <div style="width:48px; height:48px; background:linear-gradient(135deg,#16a34a,#22c55e); border-radius:8px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:20px;">
                    <i class="fa-solid fa-calendar-week"></i>
                </div>
                <div>
                    <div style="font-size:24px; font-weight:800; color:#0c1e3e; line-height:1;"><?= number_format($total_7d) ?></div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">7 ngày gần đây</div>
                </div>
            </div>

            <div class="stat-box" style="background:#fff; border:1px solid #e2e8f0; border-left:4px solid #16a34a; padding:18px; display:flex; align-items:center; gap:14px;">
                <div style="width:48px; height:48px; background:linear-gradient(135deg,#16a34a,#22c55e); border-radius:8px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:20px;">
                    <i class="fa-solid fa-calendar-days"></i>
                </div>
                <div>
                    <div style="font-size:24px; font-weight:800; color:#0c1e3e; line-height:1;"><?= number_format($total_30d) ?></div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">30 ngày gần đây</div>
                </div>
            </div>

            <div class="stat-box" style="background:#fff; border:1px solid #e2e8f0; border-left:4px solid #16a34a; padding:18px; display:flex; align-items:center; gap:14px;">
                <div style="width:48px; height:48px; background:linear-gradient(135deg,#16a34a,#22c55e); border-radius:8px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:20px;">
                    <i class="fa-solid fa-chart-simple"></i>
                </div>
                <div>
                    <div style="font-size:24px; font-weight:800; color:#0c1e3e; line-height:1;"><?= number_format($total_all) ?></div>
                    <div style="font-size:12px; color:#64748b; margin-top:4px;">Tổng lượt truy cập</div>
                </div>
            </div>
        </div>
        <div class="card" style="margin-bottom:24px; padding:20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                <i class="fa-solid fa-chart-column" style="color:#16a34a;"></i> Lượt truy cập theo tuần (12 tuần gần nhất)
            </h3>
            <div style="height:320px;"><canvas id="chartTuan"></canvas></div>
        </div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:24px;">
            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-chart-line" style="color:#16a34a;"></i> Lượt truy cập theo tháng (12 tháng gần nhất)
                </h3>
                <div style="height:300px;"><canvas id="chartThang"></canvas></div>
            </div>

            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-chart-column" style="color:#16a34a;"></i> Lượt truy cập theo năm
                </h3>
                <div style="height:300px;"><canvas id="chartNam"></canvas></div>
            </div>
        </div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-bottom:24px;">
            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-arrow-trend-up" style="color:#16a34a;"></i> Xu hướng 12 tháng gần nhất
                </h3>
                <div style="height:300px;"><canvas id="chartTrend"></canvas></div>
            </div>

            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-chart-pie" style="color:#16a34a;"></i> Tài liệu theo thể loại
                </h3>
                <div style="height:300px;"><canvas id="chartTheLoai"></canvas></div>
            </div>
        </div>
        <div class="card" style="margin-bottom:24px; padding:20px;">
            <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                <i class="fa-solid fa-chart-column" style="color:#16a34a;"></i> Tài liệu theo năm
            </h3>
            <div style="height:300px;"><canvas id="chartTailieuNam"></canvas></div>
        </div>
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-check-circle" style="color:#16a34a;"></i> Tài liệu phổ biến nhất
                </h3>
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr style="border-bottom:2px solid #e2e8f0;">
                            <th style="text-align:left; padding:10px 0; font-size:11.5px; color:#64748b; font-weight:800; text-transform:uppercase;">Tài liệu</th>
                            <th style="text-align:right; padding:10px 0; font-size:11.5px; color:#64748b; font-weight:800; width:70px;">Lượt xem</th>
                            <th style="text-align:right; padding:10px 0; font-size:11.5px; color:#64748b; font-weight:800; width:70px;">Lượt tải</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($top_pho_bien && $top_pho_bien->num_rows > 0): ?>
                            <?php while ($t = $top_pho_bien->fetch_assoc()): ?>
                                <tr style="border-bottom:1px solid #f1f5f9;">
                                    <td style="padding:12px 0; font-size:13px; color:#0c1e3e; font-weight:600;">
                                        <a href="../documents/detail.php?id=<?= urlencode($t['MaTL']) ?>" style="color:#0c1e3e; text-decoration:none;">
                                            <?= htmlspecialchars($t['TenTaiLieu']) ?>
                                        </a>
                                    </td>
                                    <td style="padding:12px 0; text-align:right; font-weight:700; color:#0c1e3e;"><?= number_format($t['SoLuotXem']) ?></td>
                                    <td style="padding:12px 0; text-align:right; font-weight:700; color:#64748b;"><?= number_format($t['SoLuotTai']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="3" style="text-align:center; padding:20px; color:#94a3b8;">Chưa có dữ liệu</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card" style="padding:20px;">
                <h3 style="margin:0 0 16px; font-size:15px; color:#0c1e3e; display:flex; align-items:center; gap:8px;">
                    <i class="fa-solid fa-check-circle" style="color:#16a34a;"></i> Tài liệu mới nhất
                </h3>
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr style="border-bottom:2px solid #e2e8f0;">
                            <th style="text-align:left; padding:10px 0; font-size:11.5px; color:#64748b; font-weight:800; text-transform:uppercase;">Tài liệu</th>
                            <th style="text-align:right; padding:10px 0; font-size:11.5px; color:#64748b; font-weight:800; width:100px;">Ngày tạo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($top_moi && $top_moi->num_rows > 0): ?>
                            <?php while ($t = $top_moi->fetch_assoc()): ?>
                                <tr style="border-bottom:1px solid #f1f5f9;">
                                    <td style="padding:12px 0; font-size:13px; color:#0c1e3e; font-weight:600;">
                                        <a href="../documents/detail.php?id=<?= urlencode($t['MaTL']) ?>" style="color:#0c1e3e; text-decoration:none;">
                                            <?= htmlspecialchars($t['TenTaiLieu']) ?>
                                        </a>
                                    </td>
                                    <td style="padding:12px 0; text-align:right; font-size:12px; color:#64748b;">
                                        <?= date('d/m/Y', strtotime($t['NgayDang'])) ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="2" style="text-align:center; padding:20px; color:#94a3b8;">Chưa có dữ liệu</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>

<script>
new Chart(document.getElementById('chartTuan'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($tuan_labels) ?>,
        datasets: [{
            label: 'Lượt truy cập',
            data: <?= json_encode($tuan_data) ?>,
            backgroundColor: '#8b5cf6',
            borderRadius: 4,
            barThickness: 20
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 }, maxRotation: 45 } }
        }
    }
});

new Chart(document.getElementById('chartThang'), {
    type: 'line',
    data: {
        labels: <?= json_encode($thang_labels) ?>,
        datasets: [{
            label: 'Lượt truy cập',
            data: <?= json_encode($thang_data) ?>,
            borderColor: '#0ea5e9',
            backgroundColor: 'rgba(14, 165, 233, 0.15)',
            borderWidth: 2.5,
            tension: 0.3,
            fill: true,
            pointRadius: 4,
            pointBackgroundColor: '#fff',
            pointBorderColor: '#0ea5e9',
            pointBorderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 }, maxRotation: 45 } }
        }
    }
});
new Chart(document.getElementById('chartNam'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($nam_labels) ?>,
        datasets: [{
            label: 'Lượt truy cập',
            data: <?= json_encode($nam_data) ?>,
            backgroundColor: '#22c55e',
            borderRadius: 6,
            barThickness: 60
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b' } }
        }
    }
});
new Chart(document.getElementById('chartTrend'), {
    type: 'line',
    data: {
        labels: <?= json_encode($trend_labels) ?>,
        datasets: [
            {
                label: 'Tài liệu mới',
                data: <?= json_encode($trend_docs) ?>,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                tension: 0.3,
                pointRadius: 3
            },
            {
                label: 'Lượt xem',
                data: <?= json_encode($trend_views) ?>,
                borderColor: '#14b8a6',
                backgroundColor: 'rgba(20, 184, 166, 0.1)',
                borderWidth: 2,
                tension: 0.3,
                pointRadius: 3
            },
            {
                label: 'Lượt tải',
                data: <?= json_encode($trend_downloads) ?>,
                borderColor: '#f97316',
                backgroundColor: 'rgba(249, 115, 22, 0.1)',
                borderWidth: 2,
                tension: 0.3,
                pointRadius: 3
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom', labels: { padding: 12, font: { size: 12 }, usePointStyle: true } }
        },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 }, maxRotation: 45 } }
        }
    }
});

new Chart(document.getElementById('chartTheLoai'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode($theloai_labels, JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{
            data: <?= json_encode($theloai_data) ?>,
            backgroundColor: ['#3b82f6', '#06b6d4', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899'],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '55%',
        plugins: {
            legend: { position: 'right', labels: { padding: 10, font: { size: 11 }, usePointStyle: true } }
        }
    }
});
new Chart(document.getElementById('chartTailieuNam'), {
    type: 'bar',
    data: {
        labels: <?= json_encode($tailieu_nam_labels) ?>,
        datasets: [{
            label: 'Số tài liệu',
            data: <?= json_encode($tailieu_nam_data) ?>,
            backgroundColor: '#3b82f6',
            borderRadius: 4,
            barThickness: 30
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, grid: { color: '#f1f5f9' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b' } }
        }
    }
});
</script>

<?php include "../../includes/footer.php"; ?>