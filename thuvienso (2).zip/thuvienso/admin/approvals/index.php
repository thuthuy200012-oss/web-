<?php
require_once "../../includes/check_admin.php";
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/delete_document.php";  
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
$msg = $_SESSION['flash_msg'] ?? '';
$msg_type = $_SESSION['flash_type'] ?? '';
unset($_SESSION['flash_msg'], $_SESSION['flash_type']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $_SESSION['flash_msg'] = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $_SESSION['flash_type'] = 'danger';
        header("Location: index.php");
        exit();
    }
    $action = $_POST['action'] ?? '';
    $id     = $_POST['id'] ?? '';
    if (!empty($id)) {
        if ($action === 'approve') {
            $stmt_info = $conn->prepare("SELECT TenTaiLieu FROM tai_lieu WHERE MaTL = ? LIMIT 1");
            $stmt_info->bind_param("s", $id);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            $stmt = $conn->prepare("UPDATE tai_lieu SET TrangThai='Đã duyệt', NgayDuyet=NOW(), LyDoTuChoi=NULL WHERE MaTL=?");
            $stmt->bind_param("s", $id);
            if ($stmt->execute()) {
                $_SESSION['flash_msg'] = "Đã duyệt tài liệu <b>" . htmlspecialchars($id) . "</b>!";
                $_SESSION['flash_type'] = 'success';

                $ten_tl = $info['TenTaiLieu'] ?? $id;
                ghi_log($conn, 'UPDATE',
                    "Duyệt tài liệu $id ($ten_tl)",
                    'tai_lieu', $id);
            }
            $stmt->close();
        }
        elseif ($action === 'reject') {
            $lydo = trim($_POST['lydo'] ?? '');
            $stmt_info = $conn->prepare("SELECT TenTaiLieu FROM tai_lieu WHERE MaTL = ? LIMIT 1");
            $stmt_info->bind_param("s", $id);
            $stmt_info->execute();
            $info = $stmt_info->get_result()->fetch_assoc();
            $stmt_info->close();

            $stmt = $conn->prepare("UPDATE tai_lieu SET TrangThai='Từ chối', LyDoTuChoi=? WHERE MaTL=?");
            $stmt->bind_param("ss", $lydo, $id);
            if ($stmt->execute()) {
                $_SESSION['flash_msg'] = "Đã từ chối tài liệu <b>" . htmlspecialchars($id) . "</b>!";
                $_SESSION['flash_type'] = 'warning';

                $ten_tl = $info['TenTaiLieu'] ?? $id;
                ghi_log($conn, 'UPDATE',
                    "Từ chối tài liệu $id ($ten_tl) - Lý do: $lydo",
                    'tai_lieu', $id);
            }
            $stmt->close();
        }
        elseif ($action === 'delete') {
            $result = delete_document($conn, $id);

            if ($result['success']) {
                $_SESSION['flash_msg'] = "Đã xóa tài liệu <b>" . htmlspecialchars($result['ten_tl']) . "</b>!";
                $_SESSION['flash_type'] = 'danger';

                ghi_log($conn, 'DELETE',
                    "Xóa tài liệu {$result['ma_tl']} ({$result['ten_tl']})",
                    'tai_lieu', $result['ma_tl']);
            } else {
                $_SESSION['flash_msg'] = "Lỗi: " . htmlspecialchars($result['error']);
                $_SESSION['flash_type'] = 'danger';
            }
        }
    }
    header("Location: index.php");
    exit();
}
$keyword  = trim($_GET['q'] ?? '');
$trang_thai = $_GET['trang_thai'] ?? 'Chờ duyệt';
$loai     = trim($_GET['loai'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 15;
$offset   = ($page - 1) * $per_page;
$where = "WHERE 1=1";
$params = []; $types = "";

if ($keyword !== '') {
    $where .= " AND (tl.TenTaiLieu LIKE ? OR tl.MaTL LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw; $types .= "ss";
}
if ($trang_thai !== '') {
    $where .= " AND tl.TrangThai = ?";
    $params[] = $trang_thai; $types .= "s";
}
if ($loai !== '') {
    $where .= " AND tl.LoaiTaiLieu = ?";
    $params[] = $loai; $types .= "s";
}

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu tl $where");
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];
$stmt->close();
$total_pages = max(1, ceil($total / $per_page));

$sql = "SELECT tl.*, dm.TenDanhMuc,
            GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia,
            nd.HoTen AS NguoiNop, nd.Email AS EmailNguoiNop
        FROM tai_lieu tl
        LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
        LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
        LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
        LEFT JOIN nguoidung nd ON tl.MaND = nd.MaND
        $where
        GROUP BY tl.MaTL
        ORDER BY tl.NgayDang DESC
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$docs = $stmt->get_result();
$stmt->close();
$stat_cho_duyet = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai='Chờ duyệt'")->fetch_assoc()['c'] ?? 0;
$stat_da_duyet  = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai='Đã duyệt'")->fetch_assoc()['c'] ?? 0;
$stat_tu_choi   = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai='Từ chối'")->fetch_assoc()['c'] ?? 0;
$loai_list = $conn->query("SELECT TenLoai FROM loaitailieu ORDER BY ThuTu");
$page_title = "Kiểm duyệt tài liệu";
include "../../includes/header.php";
?>

<link rel="stylesheet" href="../../assets/css/admin.css">
<link rel="stylesheet" href="../../assets/css/dashboard.css">
<link rel="stylesheet" href="../../assets/css/approvals.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="layout">
    <?php include "../../includes/sidebar.php"; ?>

    <main class="main">
        <div class="page-header">
            <div class="title-block">
                <h1><i class="fa-solid fa-clipboard-check"></i> Kiểm duyệt tài liệu</h1>
                <p>Duyệt hoặc từ chối tài liệu do sinh viên và giảng viên nộp lên hệ thống</p>
            </div>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="app-stats">
            <a href="?trang_thai=Chờ duyệt" class="app-stat-card <?= $trang_thai === 'Chờ duyệt' ? 'active' : '' ?>">
                <div class="app-stat-icon app-stat-amber"><i class="fa-solid fa-clock"></i></div>
                <div class="app-stat-info">
                    <div class="app-stat-num"><?= number_format($stat_cho_duyet) ?></div>
                    <div class="app-stat-lbl">Chờ duyệt</div>
                </div>
            </a>
            <a href="?trang_thai=Đã duyệt" class="app-stat-card <?= $trang_thai === 'Đã duyệt' ? 'active' : '' ?>">
                <div class="app-stat-icon app-stat-teal"><i class="fa-solid fa-circle-check"></i></div>
                <div class="app-stat-info">
                    <div class="app-stat-num"><?= number_format($stat_da_duyet) ?></div>
                    <div class="app-stat-lbl">Đã duyệt</div>
                </div>
            </a>
            <a href="?trang_thai=Từ chối" class="app-stat-card <?= $trang_thai === 'Từ chối' ? 'active' : '' ?>">
                <div class="app-stat-icon app-stat-red"><i class="fa-solid fa-circle-xmark"></i></div>
                <div class="app-stat-info">
                    <div class="app-stat-num"><?= number_format($stat_tu_choi) ?></div>
                    <div class="app-stat-lbl">Từ chối</div>
                </div>
            </a>
            <a href="?trang_thai=" class="app-stat-card <?= $trang_thai === '' ? 'active' : '' ?>">
                <div class="app-stat-icon app-stat-navy"><i class="fa-solid fa-list"></i></div>
                <div class="app-stat-info">
                    <div class="app-stat-num"><?= number_format($stat_cho_duyet + $stat_da_duyet + $stat_tu_choi) ?></div>
                    <div class="app-stat-lbl">Tất cả</div>
                </div>
            </a>
        </div>

        <div class="toolbar">
            <form method="GET" style="display:flex; gap:10px; flex:1; flex-wrap:wrap; align-items:center;">
                <input type="text" name="q" placeholder="Tìm theo mã hoặc tên tài liệu..." value="<?= htmlspecialchars($keyword) ?>">
                <select name="trang_thai">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="Chờ duyệt" <?= $trang_thai === 'Chờ duyệt' ? 'selected' : '' ?>>Chờ duyệt</option>
                    <option value="Đã duyệt" <?= $trang_thai === 'Đã duyệt' ? 'selected' : '' ?>>Đã duyệt</option>
                    <option value="Từ chối" <?= $trang_thai === 'Từ chối' ? 'selected' : '' ?>>Từ chối</option>
                </select>
                <select name="loai">
                    <option value="">-- Loại tài liệu --</option>
                    <?php while ($l = $loai_list->fetch_assoc()): ?>
                        <option value="<?= htmlspecialchars($l['TenLoai']) ?>" <?= $loai === $l['TenLoai'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($l['TenLoai']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Lọc</button>
                <?php if ($keyword || $loai): ?>
                    <a href="index.php" class="btn btn-secondary btn-sm"><i class="fa-solid fa-rotate-left"></i> Đặt lại</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th style="width:70px;">Mã TL</th>
                        <th>Tài liệu</th>
                        <th>Người nộp</th>
                        <th>Loại</th>
                        <th>Ngày nộp</th>
                        <th>Trạng thái</th>
                        <th style="width:280px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($docs && $docs->num_rows > 0): ?>
                        <?php while ($d = $docs->fetch_assoc()):
                            $json = htmlspecialchars(json_encode([
                                'MaTL' => $d['MaTL'],
                                'TenTaiLieu' => $d['TenTaiLieu'],
                                'TenTacGia' => $d['TenTacGia'],
                                'TenDanhMuc' => $d['TenDanhMuc'],
                                'LoaiTaiLieu' => $d['LoaiTaiLieu'],
                                'NamXuatBan' => $d['NamXuatBan'],
                                'NgonNgu' => $d['NgonNgu'],
                                'SoTrang' => $d['SoTrang'],
                                'TomTat' => $d['TomTat'],
                                'TuKhoa' => $d['TuKhoa'],
                                'FileTaiLieu' => $d['FileTaiLieu'],
                                'AnhBia' => $d['AnhBia'],
                                'NguoiNop' => $d['NguoiNop'],
                                'EmailNguoiNop' => $d['EmailNguoiNop'],
                                'TrangThai' => $d['TrangThai'],
                                'LyDoTuChoi' => $d['LyDoTuChoi'],
                                'NgayDang' => $d['NgayDang'],
                            ], JSON_UNESCAPED_UNICODE), ENT_QUOTES);
                        ?>
                            <tr>
                                <td><span class="code-badge"><?= htmlspecialchars($d['MaTL']) ?></span></td>
                                <td>
                                    <strong><?= htmlspecialchars($d['TenTaiLieu']) ?></strong><br>
                                    <small style="color:#64748b;">
                                        <i class="fa-solid fa-user-pen"></i>
                                        <?= htmlspecialchars($d['TenTacGia'] ?? 'Chưa rõ tác giả') ?>
                                    </small>
                                </td>
                                <td>
                                    <small><?= htmlspecialchars($d['NguoiNop'] ?? 'N/A') ?></small><br>
                                    <small style="color:#94a3b8; font-size:11px;"><?= htmlspecialchars($d['EmailNguoiNop'] ?? '') ?></small>
                                </td>
                                <td><span class="badge badge-info"><?= htmlspecialchars($d['LoaiTaiLieu'] ?? 'N/A') ?></span></td>
                                <td>
                                    <small><?= date('d/m/Y', strtotime($d['NgayDang'])) ?></small><br>
                                    <small style="color:#94a3b8; font-size:11px;"><?= date('H:i', strtotime($d['NgayDang'])) ?></small>
                                </td>
                                <td>
                                    <?php if ($d['TrangThai'] === 'Đã duyệt'): ?>
                                        <span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Đã duyệt</span>
                                    <?php elseif ($d['TrangThai'] === 'Chờ duyệt'): ?>
                                        <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Chờ duyệt</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><i class="fa-solid fa-circle-xmark"></i> Từ chối</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button type="button" class="btn-icon" onclick='openViewModal(<?= $json ?>)' title="Xem chi tiết" style="background:rgba(12,30,62,0.08); color:#0c1e3e;">
                                            <i class="fa-solid fa-eye"></i>
                                        </button>

                                        <?php if ($d['TrangThai'] !== 'Đã duyệt'): ?>
                                            <button type="button" class="btn-icon" onclick="approveDoc('<?= htmlspecialchars($d['MaTL'], ENT_QUOTES) ?>', '<?= htmlspecialchars($d['TenTaiLieu'], ENT_QUOTES) ?>')" title="Duyệt" style="background:rgba(20,184,166,0.12); color:#0d9488;">
                                                <i class="fa-solid fa-check"></i>
                                            </button>
                                        <?php endif; ?>

                                        <?php if ($d['TrangThai'] !== 'Từ chối'): ?>
                                            <button type="button" class="btn-icon" onclick="rejectDoc('<?= htmlspecialchars($d['MaTL'], ENT_QUOTES) ?>', '<?= htmlspecialchars($d['TenTaiLieu'], ENT_QUOTES) ?>')" title="Từ chối" style="background:#fee2e2; color:#dc2626;">
                                                <i class="fa-solid fa-xmark"></i>
                                            </button>
                                        <?php endif; ?>

                                        <button type="button" class="btn-icon btn-del" onclick="deleteDoc('<?= htmlspecialchars($d['MaTL'], ENT_QUOTES) ?>', '<?= htmlspecialchars($d['TenTaiLieu'], ENT_QUOTES) ?>')" title="Xóa">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr class="empty-row">
                            <td colspan="7">
                                <i class="fa-regular fa-circle-check"></i>
                                Không có tài liệu nào
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?= $i ?>&q=<?= urlencode($keyword) ?>&trang_thai=<?= urlencode($trang_thai) ?>&loai=<?= urlencode($loai) ?>"
                       class="page-btn <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>

        <div class="table-footer" style="margin-top:14px;">
            <span>Hiển thị <b><?= (int)$docs->num_rows ?></b> / <b><?= (int)$total ?></b> tài liệu</span>
        </div>
    </main>
</div>

<div class="modal-backdrop" id="viewModal">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3><i class="fa-solid fa-file-lines"></i> Chi tiết tài liệu</h3>
            <button class="modal-close" onclick="closeModal('viewModal')">&times;</button>
        </div>
        <div class="modal-body" id="viewBody"></div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('viewModal')">Đóng</button>
        </div>
    </div>
</div>

<form method="POST" id="actionForm" style="display:none;">
    <?php ?>
    <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
    <input type="hidden" name="action" id="actType">
    <input type="hidden" name="id" id="actId">
    <input type="hidden" name="lydo" id="actLydo">
</form>

<script>
function openViewModal(d) {
    const cover = d.AnhBia
        ? `<img src="../../pages/documents/stream.php?id=${encodeURIComponent(d.MaTL)}&type=cover" alt="">`
        : `<i class="fa-solid fa-file-lines"></i>`;
    const fileLink = d.FileTaiLieu
        ? `<a href="../../pages/documents/stream.php?id=${encodeURIComponent(d.MaTL)}" target="_blank" class="btn btn-primary btn-sm"><i class="fa-solid fa-file-pdf"></i> Mở file PDF</a>`
        : `<span class="badge badge-danger">Chưa có file</span>`;
    let statusBadge = '';
    if (d.TrangThai === 'Đã duyệt') statusBadge = '<span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Đã duyệt</span>';
    else if (d.TrangThai === 'Chờ duyệt') statusBadge = '<span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Chờ duyệt</span>';
    else statusBadge = '<span class="badge badge-danger"><i class="fa-solid fa-circle-xmark"></i> Từ chối</span>';

    let html = `
        <div class="view-header">
            <div class="view-cover">${cover}</div>
            <div class="view-info">
                <div style="margin-bottom:10px;">${statusBadge}</div>
                <h2>${escapeHtml(d.TenTaiLieu)}</h2>
                <div class="view-meta">
                    <div><b>Mã TL:</b> <span class="code-badge">${escapeHtml(d.MaTL)}</span></div>
                    <div><b>Tác giả:</b> ${escapeHtml(d.TenTacGia || 'Chưa rõ')}</div>
                    <div><b>Danh mục:</b> ${escapeHtml(d.TenDanhMuc || '—')}</div>
                    <div><b>Loại:</b> ${escapeHtml(d.LoaiTaiLieu || '—')}</div>
                    <div><b>Năm XB:</b> ${escapeHtml(d.NamXuatBan || '—')}</div>
                    <div><b>Số trang:</b> ${escapeHtml(d.SoTrang || '—')}</div>
                    <div><b>Ngôn ngữ:</b> ${escapeHtml(d.NgonNgu || '—')}</div>
                    <div><b>Người nộp:</b> ${escapeHtml(d.NguoiNop || '—')}</div>
                    <div><b>Ngày nộp:</b> ${escapeHtml(d.NgayDang || '—')}</div>
                </div>
            </div>
        </div>
        ${d.TuKhoa ? `<div style="margin-bottom:14px;"><b style="color:#64748b; font-size:12px; text-transform:uppercase;">TỪ KHÓA:</b><br>${escapeHtml(d.TuKhoa)}</div>` : ''}
        ${d.TomTat ? `<div style="margin-bottom:14px;"><b style="color:#64748b; font-size:12px; text-transform:uppercase;">TÓM TẮT:</b><p style="margin:6px 0; line-height:1.7; color:#334155;">${escapeHtml(d.TomTat)}</p></div>` : ''}
        ${d.LyDoTuChoi ? `<div style="margin-bottom:14px; padding:12px 16px; background:#fef2f2; border-left:3px solid #dc2626; border-radius:6px;"><b style="color:#b91c1c; font-size:12px;">LÝ DO TỪ CHỐI:</b><p style="margin:6px 0 0; color:#b91c1c;">${escapeHtml(d.LyDoTuChoi)}</p></div>` : ''}
        <div style="margin-top:20px; padding-top:16px; border-top:1px solid #f1f5f9;">
            ${fileLink}
        </div>
    `;
    document.getElementById('viewBody').innerHTML = html;
    document.getElementById('viewModal').classList.add('show');
}

function approveDoc(id, name) {
    Swal.fire({
        icon: 'question',
        title: 'Duyệt tài liệu?',
        html: `Xác nhận duyệt tài liệu <b>${escapeHtml(name)}</b>?<br><small style="color:#64748b;">Tài liệu sẽ được công khai cho tất cả người dùng.</small>`,
        showCancelButton: true,
        confirmButtonText: '<i class="fa-solid fa-check"></i> Duyệt',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#0d9488'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('actType').value = 'approve';
            document.getElementById('actId').value = id;
            document.getElementById('actionForm').submit();
        }
    });
}

function rejectDoc(id, name) {
    Swal.fire({
        icon: 'warning',
        title: 'Từ chối tài liệu',
        html: `
            <p style="text-align:left; font-size:14px; margin-bottom:12px;">Tài liệu: <b>${escapeHtml(name)}</b></p>
            <textarea id="lydoInput" class="swal2-textarea" placeholder="Nhập lý do từ chối..." style="width:100%; min-height:90px; margin:0; font-family:inherit; font-size:14px;"></textarea>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="fa-solid fa-xmark"></i> Từ chối',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626',
        preConfirm: () => {
            const lydo = document.getElementById('lydoInput').value.trim();
            if (!lydo) {
                Swal.showValidationMessage('Vui lòng nhập lý do từ chối!');
                return false;
            }
            return lydo;
        }
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('actType').value = 'reject';
            document.getElementById('actId').value = id;
            document.getElementById('actLydo').value = r.value;
            document.getElementById('actionForm').submit();
        }
    });
}

function deleteDoc(id, name) {
    Swal.fire({
        icon: 'warning',
        title: 'Xác nhận xóa?',
        html: `Xóa vĩnh viễn tài liệu <b>${escapeHtml(name)}</b>?<br><small style="color:#dc2626;">File PDF và ảnh bìa cũng sẽ bị xóa!</small>`,
        showCancelButton: true,
        confirmButtonText: '<i class="fa-solid fa-trash"></i> Xóa',
        cancelButtonText: 'Hủy',
        confirmButtonColor: '#dc2626'
    }).then(r => {
        if (r.isConfirmed) {
            document.getElementById('actType').value = 'delete';
            document.getElementById('actId').value = id;
            document.getElementById('actionForm').submit();
        }
    });
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

document.querySelectorAll('.modal-backdrop').forEach(m => {
    m.addEventListener('click', e => {
        if (e.target === m) m.classList.remove('show');
    });
});

document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop.show').forEach(m => m.classList.remove('show'));
    }
});
</script>
<?php include "../../includes/footer.php"; ?>