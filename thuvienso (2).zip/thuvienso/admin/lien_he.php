<?php
require_once "../includes/check_admin.php";
require_once "../connect.php";

$base_url = "../";
$page_title = "Quản lý liên hệ";
$current_page = '/admin/lien_he.php';

$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($id > 0) {
    if ($action === 'read') {
        $conn->query("UPDATE lien_he SET TrangThai = 1 WHERE MaLH = $id");
        header("Location: lien_he.php");
        exit;
    } elseif ($action === 'delete') {
        $conn->query("DELETE FROM lien_he WHERE MaLH = $id");
        header("Location: lien_he.php");
        exit;
    }
}

$contacts = $conn->query("SELECT * FROM lien_he ORDER BY ThoiGian DESC");

include "../includes/header.php";
?>

<div class="layout">
    <?php include "../includes/sidebar.php"; ?>

    <main class="main">
        <div class="page-header">
            <div class="title-block">
                <h1>Quản lý liên hệ</h1>
            </div>
        </div>

        <div class="cfg-card" style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="border-bottom: 2px solid #e2e8f0; text-align: left;">
                        <th style="padding: 12px;">Ngày gửi</th>
                        <th style="padding: 12px;">Họ tên</th>
                        <th style="padding: 12px;">Email</th>
                        <th style="padding: 12px;">Chủ đề</th>
                        <th style="padding: 12px;">Trạng thái</th>
                        <th style="padding: 12px;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($contacts->num_rows == 0): ?>
                        <tr><td colspan="6" style="text-align: center; padding: 20px;">Chưa có tin nhắn nào.</td></tr>
                    <?php else: ?>
                        <?php while ($row = $contacts->fetch_assoc()): ?>
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 12px;"><?= date('d/m/Y H:i', strtotime($row['ThoiGian'])) ?></td>
                                <td style="padding: 12px; font-weight: 600;"><?= htmlspecialchars($row['HoTen']) ?></td>
                                <td style="padding: 12px;"><?= htmlspecialchars($row['Email']) ?></td>
                                <td style="padding: 12px;"><?= htmlspecialchars($row['ChuDe']) ?></td>
                                <td style="padding: 12px;">
                                    <?php if ($row['TrangThai'] == 0): ?>
                                        <span style="background: #fee2e2; color: #dc2626; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">Chưa đọc</span>
                                    <?php else: ?>
                                        <span style="background: #dcfce7; color: #16a34a; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">Đã đọc</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px;">
                                    <button onclick="viewMessage(<?= htmlspecialchars(json_encode($row)) ?>)" style="background: #3b82f6; color: #fff; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; margin-right: 5px;">Xem</button>
                                    <a href="?action=delete&id=<?= $row['MaLH'] ?>" onclick="return confirm('Bạn có chắc muốn xóa?');" style="background: #ef4444; color: #fff; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 14px;">Xóa</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<div id="messageModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.6); z-index: 9999; justify-content: center; align-items: center; backdrop-filter: blur(2px);">
    <div style="background: #fff; border-radius: 12px; width: 550px; max-width: 90%; box-shadow: 0 10px 25px rgba(0,0,0,0.1); overflow: hidden; animation: modalFadeIn 0.2s ease-out;">
        <div style="padding: 20px 24px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
            <h3 style="margin: 0; font-size: 18px; color: #0f172a; font-weight: 700;">Chi tiết tin nhắn</h3>
            <button onclick="document.getElementById('messageModal').style.display='none'" style="background: none; border: none; font-size: 20px; color: #64748b; cursor: pointer; padding: 0; line-height: 1;">&times;</button>
        </div>

        <div style="padding: 24px; color: #1e293b; font-size: 14.5px;">
            <div style="display: grid; grid-template-columns: 100px 1fr; gap: 10px; margin-bottom: 16px;">
                <div style="color: #64748b; font-weight: 500;">Người gửi:</div>
                <div style="font-weight: 600;" id="m-name"></div>

                <div style="color: #64748b; font-weight: 500;">Email:</div>
                <div style="font-weight: 600; color: #2563eb;" id="m-email"></div>

                <div style="color: #64748b; font-weight: 500;">Chủ đề:</div>
                <div style="font-weight: 600;" id="m-subject"></div>
            </div>

            <div style="margin-top: 20px;">
                <div style="color: #64748b; font-weight: 500; margin-bottom: 8px;">Nội dung:</div>
                <div style="background: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid #e2e8f0;">
                    <p id="m-content" style="white-space: pre-wrap; margin: 0; line-height: 1.6; color: #0f172a;"></p>
                </div>
            </div>
        </div>

        <div style="padding: 16px 24px; border-top: 1px solid #e2e8f0; text-align: right; background: #f8fafc;">
            <button onclick="document.getElementById('messageModal').style.display='none'" style="padding: 10px 20px; border: none; background: #64748b; color: #fff; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.2s;" onmouseover="this.style.background='#475569'" onmouseout="this.style.background='#64748b'">
                Đóng
            </button>
        </div>
    </div>
</div>

<style>
@keyframes modalFadeIn {
    from { opacity: 0; transform: translateY(10px) scale(0.98); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}
</style>

<script>
function viewMessage(data) {
    document.getElementById('m-name').innerText = data.HoTen;
    document.getElementById('m-email').innerText = data.Email;
    document.getElementById('m-subject').innerText = data.ChuDe || '(Không có)';
    document.getElementById('m-content').innerText = data.NoiDung;
    
    if (data.TrangThai == 0) {
        fetch('?action=read&id=' + data.MaLH, {method: 'GET'});
        setTimeout(() => window.location.reload(), 500);
    }

    document.getElementById('messageModal').style.display = 'flex';
}
</script>

<?php include "../includes/footer.php"; ?>