<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('display_startup_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php_errors.log');
error_reporting(E_ALL);

if (!is_dir(__DIR__ . '/logs')) {
    @mkdir(__DIR__ . '/logs', 0755, true);
}
$host = "localhost";
$user = "root";
$password = "";
$database = "thuvienso";
$port = 3307;

$conn = new mysqli($host, $user, $password, $database, $port);

if ($conn->connect_error) {
    error_log("DB Connection Failed: " . $conn->connect_error);
    http_response_code(500);
    die("Đã xảy ra lỗi kết nối. Vui lòng thử lại sau hoặc liên hệ quản trị viên!");
}

$conn->set_charset("utf8mb4");
$conn->query("SET time_zone = '+07:00'");
?>