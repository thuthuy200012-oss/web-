<?php
    $current_page = $_SERVER['PHP_SELF'];
    $root = '/thuvienso';
    ?>
    <style>
        .sidebar {
            width: 260px;
            background: #0f172a;
            color: #94a3b8;
            padding: 24px 16px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            gap: 8px;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.05);
            overflow-y: auto;
            overflow-x: hidden;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }

        .sidebar::-webkit-scrollbar {
            width: 6px;
        }
        .sidebar::-webkit-scrollbar-track {
            background: transparent;
        }
        .sidebar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 3px;
        }
        .sidebar::-webkit-scrollbar-thumb:hover {
            background: #475569;
        }

        .sidebar-section-title {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            color: #64748b;
            font-weight: 700;
            margin: 16px 0 8px 12px;
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .sidebar-menu li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #94a3b8;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            transition: all 0.2s ease;
        }

        .sidebar-menu li a i {
            font-size: 16px;
            width: 20px;
            text-align: center;
            color: #64748b;
            transition: color 0.2s ease;
        }

        .sidebar-menu li a:hover {
            background: rgba(255, 255, 255, 0.06);
            color: #f8fafc;
        }

        .sidebar-menu li a:hover i {
            color: #60a5fa;
        }

        .sidebar-menu li.active a {
            background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
            color: #ffffff;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.35);
        }

        .sidebar-menu li.active a i {
            color: #ffffff;
        }
    </style>

    <aside class="sidebar">
        <div class="sidebar-section-title">Bảng điều khiển</div>
        <ul class="sidebar-menu">
            <li class="<?= (strpos($current_page, '/admin/index.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/index.php">
                    <i class="fa-solid fa-chart-line"></i>
                    <span>Tổng quan</span>
                </a>
            </li>
        </ul>
        <div class="sidebar-section-title">Quản lý hệ thống</div>
        <ul class="sidebar-menu">
            <li class="<?= (strpos($current_page, '/admin/users/') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/users/index.php">
                    <i class="fa-solid fa-users"></i>
                    <span>Tài khoản</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/categories/danh_muc.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/categories/danh_muc.php">
                    <i class="fa-solid fa-folder-tree"></i>
                    <span>Danh mục</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/categories/the_loai.php') !== false) ? 'active' : '' ?>">
                 <a href="<?= $root ?>/admin/categories/the_loai.php">
                    <i class="fa-solid fa-tags"></i>
                    <span>Thể loại</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/categories/khoa.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/categories/khoa.php">
                    <i class="fa-solid fa-building-columns"></i>
                    <span>Khoa / Phòng ban</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/categories/tac_gia.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/categories/tac_gia.php">
                    <i class="fa-solid fa-user-tie"></i>
                    <span>Tác giả</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/documents/index.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/documents/index.php">
                    <i class="fa-solid fa-file-lines"></i>
                    <span>Tài liệu</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/approvals/') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/approvals/index.php">
                <i class="fa-solid fa-clipboard-check"></i>
                <span>Kiểm duyệt</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/documents/upload.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/documents/upload.php">
                    <i class="fa-solid fa-circle-plus"></i>
                    <span>Thêm tài liệu</span>
                </a>
            </li>

            <li class="<?= (strpos($current_page, '/admin/categories/nam_hoc.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/categories/nam_hoc.php">
                    <i class="fa-solid fa-calendar-days"></i>
                    <span>Năm học</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/categories/nganh.php') !== false) ? 'active' : '' ?>">
                 <a href="<?= $root ?>/admin/categories/nganh.php">
                     <i class="fa-solid fa-graduation-cap"></i>
                     <span>Ngành</span>
                    </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/categories/tu_khoa.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/categories/tu_khoa.php">
                  <i class="fa-solid fa-tag"></i>
                 <span>Từ khóa</span>
                 </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/documents/import.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/documents/import.php">
                    <i class="fa-solid fa-file-import"></i>
                    <span>Import tài liệu</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/users/phan_quyen.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/users/phan_quyen.php">
                     <i class="fa-solid fa-shield-halved"></i>
                     <span>Phân quyền</span>
                 </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/system/cau_hinh.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/system/cau_hinh.php">
                     <i class="fa-solid fa-gear"></i>
                     <span>Cấu hình website</span>
                 </a>
            </li>
             <li class="<?= (strpos($current_page, '/backups/backup.php') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/backups/backup.php">
                    <i class="fa-solid fa-database"></i>
                    <span>Backup Database</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/logs.php') !== false) ? 'active' : '' ?>">
                 <a href="<?= $root ?>/admin/logs.php">
                     <i class="fa-solid fa-clipboard-list"></i>
                     <span>Nhật ký hệ thống</span>
                </a>
            </li>
            <li class="<?= (strpos($current_page, '/admin/lien_he.php') !== false) ? 'active' : '' ?>">
              <a href="<?= $root ?>/admin/lien_he.php">
                  <i class="fa-solid fa-envelope"></i>
                 <span>Quản lý liên hệ</span>
              </a>
            </li>
        </ul>
        <div class="sidebar-section-title">Báo cáo</div>
        <ul class="sidebar-menu">
            <li class="<?= (strpos($current_page, '/admin/reports/') !== false) ? 'active' : '' ?>">
                <a href="<?= $root ?>/admin/reports/index.php">
                    <i class="fa-solid fa-chart-pie"></i>
                    <span>Thống kê</span>
                </a>
            </li>
        </ul>
    </aside>
    <script>

    (function() {
        function fixSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const layout = document.querySelector('.layout');
            const main = document.querySelector('.main');

            if (!sidebar) {
                console.warn('❌ Không tìm thấy .sidebar');
                return;
            }
            let totalHeaderHeight = 0;
            const bodyChildren = document.body.children;
            const layoutTop = layout ? layout.getBoundingClientRect().top + window.scrollY : 0;

            if (layout) {
                totalHeaderHeight = layout.getBoundingClientRect().top + window.scrollY;
            }

            if (totalHeaderHeight <= 0) {
                document.querySelectorAll('header, .header, .topbar, .navbar, .admin-bar, .top-bar, .toolbar-top').forEach(h => {
                    if (h.offsetHeight > 0 && h.getBoundingClientRect().top < 200) {
                        totalHeaderHeight += h.offsetHeight;
                    }
                });
            }

            if (totalHeaderHeight <= 0) totalHeaderHeight = 94;

            console.log('✅ Tổng chiều cao header:', totalHeaderHeight);

            sidebar.style.position = 'fixed';
            sidebar.style.top = totalHeaderHeight + 'px';
            sidebar.style.left = '0';
            sidebar.style.width = '260px';
            sidebar.style.height = 'calc(100vh - ' + totalHeaderHeight + 'px)';
            sidebar.style.overflowY = 'auto';
            sidebar.style.overflowX = 'hidden';
            sidebar.style.zIndex = '100';

            if (main) {
                main.style.marginLeft = '260px';
            }

        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fixSidebar);
        } else {
            fixSidebar();
        }

        window.addEventListener('resize', fixSidebar);

        setTimeout(fixSidebar, 500);
    })();
    </script>