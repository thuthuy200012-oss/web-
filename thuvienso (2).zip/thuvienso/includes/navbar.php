<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../connect.php';
require_once __DIR__ . '/track_visit.php';
track_visit($conn);
check_session_timeout();
try_remember_login($conn);

$is_logged_in = isset($_SESSION['MaND']);
$vai_tro      = $_SESSION['MaVaiTro'] ?? null;
$ho_ten       = $_SESSION['HoTen'] ?? '';
$initial      = mb_substr($ho_ten, 0, 1);
$base         = $base_url ?? '/thuvienso/';
$ma_nd_nav    = $_SESSION['MaND'] ?? '';

$is_admin_or_staff = ($vai_tro === 'ADMIN' || $vai_tro === 'THUTHU');

if (isset($_GET['mark_notif_read']) && $is_logged_in && !$is_admin_or_staff && !empty($ma_nd_nav)) {
    $now = date('Y-m-d H:i:s');
    $stmt_mark = $conn->prepare("UPDATE nguoidung SET ThoiGianDocThongBao = ? WHERE MaND = ?");
    if ($stmt_mark) {
        $stmt_mark->bind_param("ss", $now, $ma_nd_nav);
        $stmt_mark->execute();
        $stmt_mark->close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'time' => $now]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}
if (!function_exists('nav_icon')) {
    function nav_icon(string $name, string $size = '16'): string {
        $icons = [
            'search'      => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
            'graduation'  => '<path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',
            'shield'      => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
            'user-circle' => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="10" r="3"/><path d="M6 21v-1a6 6 0 0 1 12 0v1"/>',
            'chevron-down'=> '<polyline points="6 9 12 15 18 9"/>',
            'heart'       => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
            'clock'       => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>',
            'id-card'     => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M15 8h4M15 12h4M5 18h14"/>',
            'gear'        => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
            'logout'      => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
            'user'        => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
            'bell'        => '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
            'check'       => '<polyline points="20 6 9 17 4 12"/>',
            'x'           => '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
            'inbox'       => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        ];
        $path = $icons[$name] ?? '<circle cx="12" cy="12" r="10"/>';
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="'.$size.'" height="'.$size.'" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">'.$path.'</svg>';
    }
}
$nav_notifications = [];
$nav_notif_count = 0;

if ($is_logged_in && !$is_admin_or_staff && !empty($ma_nd_nav)) {

    $stmt_n = $conn->prepare("
        SELECT MaTL, TenTaiLieu, TrangThai, NgayDang
        FROM tai_lieu
        WHERE MaND = ? AND TrangThai IN ('Đã duyệt', 'Từ chối')
        ORDER BY NgayDang DESC
        LIMIT 8
    ");
    $stmt_n->bind_param("s", $ma_nd_nav);
    $stmt_n->execute();
    $res_n = $stmt_n->get_result();
    while ($row_n = $res_n->fetch_assoc()) {
        $nav_notifications[] = $row_n;
    }
    $stmt_n->close();
    $last_read = '1970-01-01 00:00:00';
    $stmt_lr = $conn->prepare("SELECT ThoiGianDocThongBao FROM nguoidung WHERE MaND = ? LIMIT 1");
    if ($stmt_lr) {
        $stmt_lr->bind_param("s", $ma_nd_nav);
        $stmt_lr->execute();
        $row_lr = $stmt_lr->get_result()->fetch_assoc();
        $stmt_lr->close();
        if (!empty($row_lr['ThoiGianDocThongBao'])) {
            $last_read = $row_lr['ThoiGianDocThongBao'];
        }
    }

    $stmt_c = $conn->prepare("
        SELECT COUNT(*) AS c FROM tai_lieu
        WHERE MaND = ? AND TrangThai IN ('Đã duyệt', 'Từ chối')
        AND NgayDang > ?
    ");
    $stmt_c->bind_param("ss", $ma_nd_nav, $last_read);
    $stmt_c->execute();
    $nav_notif_count = $stmt_c->get_result()->fetch_assoc()['c'] ?? 0;
    $stmt_c->close();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Thư viện số - Đại học Phan Thiết' ?></title>
    <link rel="stylesheet" href="<?= $base ?>assets/css/public.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

<header class="header-public">
    <div class="header-container">

        <a href="<?= $base ?>pages/home/index.php" class="logo">
            <div class="logo-icon">
                <?= nav_icon('graduation', '22') ?>
            </div>
            <div class="logo-text">
                <strong>THƯ VIỆN SỐ</strong>
            </div>
        </a>

        <nav class="nav-menu">
            <a href="<?= $base ?>pages/home/index.php" class="<?= ($current_page ?? '') === 'home' ? 'active' : '' ?>">Trang chủ</a>
            <a href="<?= $base ?>pages/documents/index.php" class="<?= ($current_page ?? '') === 'tai-lieu' ? 'active' : '' ?>">Tài liệu</a>
            <a href="<?= $base ?>pages/documents/authors.php" class="<?= ($current_page ?? '') === 'tac-gia' ? 'active' : '' ?>">Tác giả</a>
            <a href="<?= $base ?>pages/documents/departments.php" class="<?= ($current_page ?? '') === 'khoa' ? 'active' : '' ?>">Khoa / Ngành</a>
            <a href="<?= $base_url ?>pages/documents/lien_he.php">Liên hệ</a>
        </nav>

        <form method="GET" action="<?= $base ?>pages/documents/index.php" class="header-search">
            <input type="text" name="q" placeholder="Tìm kiếm tài liệu...">
            <button type="submit"><?= nav_icon('search', '16') ?></button>
        </form>

        <?php if ($is_logged_in): ?>

            <?php if ($is_admin_or_staff): ?>
                <a href="<?= $base ?>admin/index.php" class="btn-nav btn-nav-admin">
                    <?= nav_icon('shield', '14') ?>
                    Quản trị
                </a>
            <?php else: ?>
                <a href="<?= $base ?>pages/dashboard/index.php" class="btn-nav btn-nav-user">
                    <?= nav_icon('user-circle', '14') ?>
                    Khu vực cá nhân
                </a>
            <?php endif; ?>
            <?php if (!$is_admin_or_staff): ?>
            <div class="nav-notif-wrapper">
                <button class="nav-notif-btn" id="navNotifBtn" onclick="toggleNavNotif(event)" title="Thông báo">
                    <?= nav_icon('bell', '18') ?>
                    <span class="nav-notif-badge" id="navNotifBadge" style="<?= $nav_notif_count > 0 ? '' : 'display:none;' ?>">
                        <?= $nav_notif_count ?>
                    </span>
                </button>

                <div class="nav-notif-dropdown" id="navNotifDropdown">
                    <div class="nav-notif-head">
                        <span>Thông báo</span>
                        <span class="nav-notif-count"><?= count($nav_notifications) ?> mới</span>
                    </div>
                    <div class="nav-notif-list">
                        <?php if (!empty($nav_notifications)): ?>
                            <?php foreach ($nav_notifications as $notif):
                                $is_approved = ($notif['TrangThai'] === 'Đã duyệt');
                                $time_diff = time() - strtotime($notif['NgayDang']);
                                if ($time_diff < 60) $time_str = 'Vừa xong';
                                elseif ($time_diff < 3600) $time_str = floor($time_diff / 60) . ' phút trước';
                                elseif ($time_diff < 86400) $time_str = floor($time_diff / 3600) . ' giờ trước';
                                elseif ($time_diff < 604800) $time_str = floor($time_diff / 86400) . ' ngày trước';
                                else $time_str = date('d/m/Y', strtotime($notif['NgayDang']));
                            ?>
                                <a href="<?= $base ?>pages/documents/detail.php?id=<?= $notif['MaTL'] ?>" class="nav-notif-item">
                                    <div class="nav-notif-icon <?= $is_approved ? 'approved' : 'rejected' ?>">
                                        <?= nav_icon($is_approved ? 'check' : 'x', '16') ?>
                                    </div>
                                    <div class="nav-notif-content">
                                        <div class="nav-notif-title">
                                            <?= $is_approved ? 'Tài liệu của bạn đã được duyệt' : 'Tài liệu của bạn bị từ chối' ?>
                                        </div>
                                        <div class="nav-notif-doc"><?= htmlspecialchars($notif['TenTaiLieu']) ?></div>
                                        <div class="nav-notif-time"><?= $time_str ?></div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="nav-notif-empty">
                                <?= nav_icon('inbox', '32') ?>
                                <p>Chưa có thông báo nào</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="user-dropdown">
                <button class="user-btn" onclick="toggleUserMenu(event)">
                    <div class="user-avatar"><?= htmlspecialchars($initial) ?></div>
                    <span><?= htmlspecialchars($ho_ten) ?></span>
                    <?= nav_icon('chevron-down', '12') ?>
                </button>

                <div class="user-menu" id="userMenu">
                    <a href="<?= $base ?>pages/dashboard/index.php"><?= nav_icon('user-circle', '14') ?> Khu vực cá nhân</a>
                    <a href="<?= $base ?>pages/favorites/index.php"><?= nav_icon('heart', '14') ?> Tài liệu yêu thích</a>
                    <a href="<?= $base ?>pages/profile/history.php"><?= nav_icon('clock', '14') ?> Lịch sử xem</a>
                    <a href="<?= $base ?>pages/profile/index.php"><?= nav_icon('id-card', '14') ?> Thông tin cá nhân</a>

                    <?php if ($is_admin_or_staff): ?>
                        <a href="<?= $base ?>admin/index.php"><?= nav_icon('gear', '14') ?> Quản trị</a>
                    <?php endif; ?>

                    <hr>
                    <a href="<?= $base ?>pages/auth/logout.php" class="logout">
                        <?= nav_icon('logout', '14') ?> Đăng xuất
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="auth-buttons">
                <a href="<?= $base ?>pages/auth/login.php" class="btn-login">
                    <?= nav_icon('user', '14') ?> Đăng nhập
                </a>
            </div>
        <?php endif; ?>

    </div>
</header>

<style>
    .btn-nav {
        padding: 10px 18px;
        border-radius: 10px;
        text-decoration: none;
        font-weight: 700;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-right: 8px;
        white-space: nowrap;
        color: #fff;
    }
    .btn-nav-admin { background: linear-gradient(135deg, #0c1e3e, #1e3a5f); }
    .btn-nav-user  { background: linear-gradient(135deg, #0d9488, #14b8a6); }
    .user-btn svg { margin-left: 4px; }
    .user-menu a { display: flex; align-items: center; gap: 10px; }

    .nav-notif-wrapper {
        position: relative;
        display: inline-block;
        margin-right: 12px;
    }

    .nav-notif-btn {
        position: relative;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #f1f5f9;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #475569;
        transition: all 0.2s;
    }

    .nav-notif-btn:hover {
        background: #e2e8f0;
        color: #16a34a;
    }

    .nav-notif-badge {
        position: absolute;
        top: -2px;
        right: -2px;
        background: #dc2626;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        min-width: 18px;
        height: 18px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
        border: 2px solid #fff;
    }

    .nav-notif-dropdown {
        position: absolute;
        top: calc(100% + 12px);
        right: 0;
        width: 360px;
        max-width: 90vw;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        box-shadow: 0 8px 24px rgba(12, 30, 62, 0.12);
        z-index: 1000;
        display: none;
        overflow: hidden;
    }

    .nav-notif-dropdown.show {
        display: block;
    }

    .nav-notif-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 14px 16px;
        border-bottom: 1px solid #e2e8f0;
        font-size: 14px;
        font-weight: 700;
        color: #0c1e3e;
    }

    .nav-notif-count {
        font-size: 11px;
        font-weight: 600;
        color: #16a34a;
        background: rgba(22,163,74,0.08);
        padding: 3px 8px;
        border-radius: 4px;
    }

    .nav-notif-list {
        max-height: 400px;
        overflow-y: auto;
    }

    .nav-notif-item {
        display: flex;
        gap: 12px;
        padding: 12px 16px;
        text-decoration: none;
        color: inherit;
        border-bottom: 1px solid #f1f5f9;
        transition: background 0.15s;
    }

    .nav-notif-item:last-child {
        border-bottom: none;
    }

    .nav-notif-item:hover {
        background: #f8fafc;
    }

    .nav-notif-icon {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .nav-notif-icon.approved {
        background: rgba(22,163,74,0.1);
        color: #16a34a;
    }

    .nav-notif-icon.rejected {
        background: rgba(220,38,38,0.1);
        color: #dc2626;
    }

    .nav-notif-content {
        flex: 1;
        min-width: 0;
    }

    .nav-notif-title {
        font-size: 13px;
        font-weight: 600;
        color: #0c1e3e;
        margin-bottom: 2px;
    }

    .nav-notif-doc {
        font-size: 12px;
        color: #64748b;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        margin-bottom: 2px;
    }

    .nav-notif-time {
        font-size: 11px;
        color: #94a3b8;
    }

    .nav-notif-empty {
        padding: 40px 20px;
        text-align: center;
        color: #94a3b8;
    }

    .nav-notif-empty p {
        margin: 8px 0 0;
        font-size: 13px;
    }

    @media (max-width: 640px) {
        .nav-notif-dropdown {
            width: 300px;
            right: -50px;
        }
    }
</style>

<script>
function toggleUserMenu(e) {
    e.stopPropagation();
    document.getElementById('userMenu').classList.toggle('show');
    const notif = document.getElementById('navNotifDropdown');
    if (notif) notif.classList.remove('show');
}

function toggleNavNotif(e) {
    e.stopPropagation();
    const dropdown = document.getElementById('navNotifDropdown');
    const isOpening = !dropdown.classList.contains('show');

    dropdown.classList.toggle('show');
    const menu = document.getElementById('userMenu');
    if (menu) menu.classList.remove('show');

    if (isOpening) {
        const badge = document.getElementById('navNotifBadge');
        if (badge) badge.style.display = 'none';

        fetch('<?= $base ?>includes/navbar.php?mark_notif_read=1', {
            method: 'GET',
            credentials: 'same-origin',
            cache: 'no-store'
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            console.log('✅ Đã đánh dấu đọc:', data);
        })
        .catch(function(err) {
            console.error('❌ Lỗi mark read:', err);
        });
    }
}

document.addEventListener('click', function(e) {
    const menu = document.getElementById('userMenu');
    if (menu && !e.target.closest('.user-dropdown')) {
        menu.classList.remove('show');
    }
    const notif = document.getElementById('navNotifDropdown');
    if (notif && !e.target.closest('.nav-notif-wrapper')) {
        notif.classList.remove('show');
    }
});
</script>
<?php include __DIR__ . '/ai_chatbox.php'; ?>
</body>
</html>