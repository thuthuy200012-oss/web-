<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

const SESSION_TIMEOUT = 7200; // 2 giờ

function check_session_timeout(): void
{
    if (empty($_SESSION['MaND'])) {
        return;
    }
    if (isset($_SESSION['last_activity'])
        && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {

        if (function_exists('ghi_log') && isset($GLOBALS['conn'])) {
            ghi_log($GLOBALS['conn'], 'LOGOUT', 'Hết hạn phiên (timeout 2 giờ)');
        }

        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();

        header('Location: /pages/auth/login.php?expired=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function try_remember_login(mysqli $conn): void
{
    if (!empty($_SESSION['MaND']) || empty($_COOKIE['remember_token'])) {
        return;
    }

    $hash = hash('sha256', $_COOKIE['remember_token']);

    $stmt = $conn->prepare("
        SELECT r.MaND,
               nd.HoTen,
               nd.Email,
               nd.MaVaiTro,
               nd.MaPB,
               vt.TenVaiTro
        FROM remember_tokens r
        JOIN nguoidung nd ON nd.MaND = r.MaND
        LEFT JOIN vaitro vt ON nd.MaVaiTro = vt.MaVaiTro
        WHERE r.TokenHash = ? AND r.HetHan > NOW() AND nd.TrangThai = 1
        LIMIT 1
    ");
    $stmt->bind_param("s", $hash);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        session_regenerate_id(true);

        $_SESSION['MaND']          = $row['MaND'];
        $_SESSION['HoTen']         = $row['HoTen'];
        $_SESSION['Email']         = $row['Email'];
        $_SESSION['MaVaiTro']      = $row['MaVaiTro'];
        $_SESSION['TenVaiTro']     = $row['TenVaiTro'];
        $_SESSION['MaPB']          = $row['MaPB'];
        $_SESSION['login_time']    = time();
        $_SESSION['last_activity'] = time();
    } else {
        setcookie('remember_token', '', time() - 3600, '/');
        setcookie('remember_email', '', time() - 3600, '/');
    }
}