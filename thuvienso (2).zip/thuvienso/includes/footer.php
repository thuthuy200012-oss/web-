<footer class="main-footer" style="background-color: #f9fafb; border-top: 1px solid #e5e7eb; padding: 16px; text-align: center; margin-top: 40px; font-size: 13px; color: #6b7280;">
        <div class="container">
            <p style="margin: 0 0 6px 0;">
                &copy; <?php echo date("Y"); ?> <strong>Thư viện số</strong>. Hệ thống quản lý & chia sẻ tài liệu.
            </p>
            <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                Thiết kế & Phát triển cho Hệ thống Thư viện Trường Đại học Phan Thiết
            </p>
        </div>
    </footer>
</body>
</html>