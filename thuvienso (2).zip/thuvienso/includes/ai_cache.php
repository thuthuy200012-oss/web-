<?php

if (!defined('AI_CACHE_DIR')) {
    define('AI_CACHE_DIR', dirname(__DIR__) . '/cache/ai/');
}

if (!is_dir(AI_CACHE_DIR)) {
    @mkdir(AI_CACHE_DIR, 0755, true);
}

if (!function_exists('ai_cache_get')) {
    function ai_cache_get(string $key, int $ttl = 86400) { // 24h
        $file = AI_CACHE_DIR . md5($key) . '.json';
        if (file_exists($file) && (time() - filemtime($file)) < $ttl) {
            $data = json_decode(file_get_contents($file), true);
            return is_array($data) ? $data : null;
        }
        return null;
    }
}

if (!function_exists('ai_cache_set')) {
    function ai_cache_set(string $key, $data): void {
        $file = AI_CACHE_DIR . md5($key) . '.json';
        @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE));
    }
}

if (!function_exists('ai_check_rate_limit')) {
    /**
     * Giới hạn số câu hỏi AI mỗi user/ngày
     * @return array ['allowed' => bool, 'remaining' => int]
     */
    function ai_check_rate_limit(string $ma_nd, int $max_per_day = 20): array {
        $file = AI_CACHE_DIR . 'rate_' . md5($ma_nd) . '.json';
        $today = date('Y-m-d');

        $usage = file_exists($file) ? json_decode(file_get_contents($file), true) : null;
        if (!is_array($usage) || ($usage['date'] ?? '') !== $today) {
            $usage = ['date' => $today, 'count' => 0];
        }

        if ($usage['count'] >= $max_per_day) {
            return ['allowed' => false, 'remaining' => 0];
        }

        $usage['count']++;
        @file_put_contents($file, json_encode($usage));
        return ['allowed' => true, 'remaining' => $max_per_day - $usage['count']];
    }
}