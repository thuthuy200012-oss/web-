<?php

if (!function_exists('track_visit')) {
    function track_visit(mysqli $conn): void {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/bot|crawl|spider|slurp|facebook|googlebot|bingbot/i', $ua)) return;

        $uri = $_SERVER['REQUEST_URI'] ?? '';
        if (strpos($uri, '/admin/') !== false) return;

        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $session_key = 'last_visit_' . md5($ip . $uri);
        if (isset($_SESSION[$session_key]) && (time() - $_SESSION[$session_key]) < 30) {
            return;
        }
        $_SESSION[$session_key] = time();

        $ma_nd = $_SESSION['MaND'] ?? null;

        $stmt = $conn->prepare("INSERT INTO luot_truy_cap (MaND, IPAddress, UserAgent, TrangTruyCap) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssss", $ma_nd, $ip, $ua, $uri);
            $stmt->execute();
            $stmt->close();
        }
    }
}