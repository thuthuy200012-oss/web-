<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/auth.php';
if (!isset($conn)) {
    require_once __DIR__ . '/../connect.php';
}
if (!function_exists('ghi_log')) {
    require_once __DIR__ . '/audit.php';
}
try_remember_login($conn);
check_session_timeout();

$ADMIN_ROLES = ['ADMIN', 'THUTHU'];

if (!isset($_SESSION['MaND']) || empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để tiếp tục!";
    header('Location: /thuvienso/pages/auth/login.php');
    exit();
}

$current_role = $_SESSION['MaVaiTro'] ?? '';
if (!in_array($current_role, $ADMIN_ROLES)) {
    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>403 — Truy cập bị từ chối</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Tahoma, sans-serif;
                background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            .error-box {
                background: #fff;
                padding: 50px 55px;
                border-radius: 24px;
                text-align: center;
                box-shadow: 0 20px 60px rgba(220, 38, 38, 0.25);
                max-width: 540px;
                width: 100%;
                animation: fadeUp 0.5s ease;
            }
            @keyframes fadeUp {
                from { opacity: 0; transform: translateY(20px); }
                to   { opacity: 1; transform: translateY(0); }
            }
            .shield-icon {
                font-size: 80px;
                color: #dc2626;
                margin-bottom: 16px;
                animation: pulse 2s ease-in-out infinite;
            }
            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50%      { transform: scale(1.08); }
            }
            .error-box h1 {
                font-size: 30px;
                color: #1e293b;
                margin: 0 0 12px;
                font-weight: 800;
            }
            .error-box .code-403 {
                display: inline-block;
                padding: 4px 14px;
                background: #fee2e2;
                color: #b91c1c;
                border-radius: 999px;
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 1px;
                margin-bottom: 16px;
            }
            .error-box p {
                font-size: 15px;
                color: #64748b;
                margin: 0 0 24px;
                line-height: 1.7;
            }
            .error-box p b { color: #1e293b; }
            .user-badge {
                display: inline-flex;
                align-items: center;
                gap: 10px;
                padding: 10px 18px;
                background: #f1f5f9;
                border-radius: 999px;
                font-size: 14px;
                color: #475569;
                margin-bottom: 26px;
            }
            .user-badge i { color: #2563eb; }
            .user-badge b { color: #1e293b; }
            .btn-group {
                display: flex;
                gap: 12px;
                justify-content: center;
                flex-wrap: wrap;
            }
            .btn {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 12px 26px;
                text-decoration: none;
                border-radius: 12px;
                font-weight: 700;
                font-size: 14px;
                transition: all 0.25s ease;
                border: none;
                cursor: pointer;
                color: #fff;
            }
            .btn-home {
                background: linear-gradient(135deg, #2563eb, #1d4ed8);
                box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35);
            }
            .btn-home:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 22px rgba(37, 99, 235, 0.45);
            }
            .btn-logout {
                background: linear-gradient(135deg, #dc2626, #b91c1c);
                box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35);
            }
            .btn-logout:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 22px rgba(220, 38, 38, 0.45);
            }
            .footer-note {
                margin-top: 24px;
                font-size: 12px;
                color: #94a3b8;
            }
        </style>
    </head>
    <body>
        <div class="error-box">
            <div class="shield-icon">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <span class="code-403">LỖI 403</span>
            <h1>Truy cập bị từ chối</h1>
            <p>
                Bạn không có quyền truy cập vào khu vực quản trị.<br>
                Trang này chỉ dành cho <b>Quản trị viên</b> và <b>Thủ thư</b>.
            </p>

            <div class="user-badge">
                <i class="fa-solid fa-user-circle"></i>
                <?= htmlspecialchars($_SESSION['HoTen'] ?? 'Người dùng') ?>
                — <b><?= htmlspecialchars($_SESSION['TenVaiTro'] ?? $_SESSION['MaVaiTro'] ?? '') ?></b>
            </div>

            <div class="btn-group">
                <a href="/thuvienso/pages/home/index.php" class="btn btn-home">
                    <i class="fa-solid fa-house"></i> Về trang chủ
                </a>
                <a href="/thuvienso/pages/auth/logout.php" class="btn btn-logout">
                    <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                </a>
            </div>

            <div class="footer-note">
                Nếu bạn cho rằng đây là lỗi, vui lòng liên hệ Thủ thư.
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}
