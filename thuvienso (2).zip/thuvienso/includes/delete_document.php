<?php

if (!function_exists('delete_document')) {
    function delete_document(mysqli $conn, string $ma_tl): array {
        if (empty($ma_tl)) {
            return ['success' => false, 'error' => 'Thiếu mã tài liệu'];
        }


        $stmt = $conn->prepare("
            SELECT TenTaiLieu, FileTaiLieu, AnhBia 
            FROM tai_lieu 
            WHERE MaTL = ? 
            LIMIT 1
        ");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $doc = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$doc) {
            return ['success' => false, 'error' => 'Không tìm thấy tài liệu'];
        }

        $file_pdf = !empty($doc['FileTaiLieu']) ? $doc['FileTaiLieu'] : null;
        $file_anh = !empty($doc['AnhBia'])      ? $doc['AnhBia']      : null;
        $conn->begin_transaction();

        try {
            $stmt = $conn->prepare("DELETE FROM tailieutacgia WHERE MaTL = ?");
            $stmt->bind_param("s", $ma_tl);
            if (!$stmt->execute()) {
                error_log("delete_document: Xóa tailieutacgia lỗi - " . $conn->error . " | MaTL: $ma_tl");
                throw new Exception("Không thể xóa liên kết tác giả");
            }
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM yeuthich WHERE MaTL = ?");
            $stmt->bind_param("s", $ma_tl);
            if (!$stmt->execute()) {
                error_log("delete_document: Xóa yeuthich lỗi - " . $conn->error . " | MaTL: $ma_tl");
                throw new Exception("Không thể xóa dữ liệu yêu thích");
            }
            $stmt->close();

            $stmt = $conn->prepare("DELETE FROM lichsudoc WHERE MaTL = ?");
            $stmt->bind_param("s", $ma_tl);
            if (!$stmt->execute()) {
                error_log("delete_document: Xóa lichsudoc lỗi - " . $conn->error . " | MaTL: $ma_tl");
                throw new Exception("Không thể xóa lịch sử đọc");
            }
            $stmt->close();
            $stmt = $conn->prepare("DELETE FROM tai_lieu WHERE MaTL = ?");
            $stmt->bind_param("s", $ma_tl);
            if (!$stmt->execute()) {
                error_log("delete_document: Xóa tai_lieu lỗi - " . $conn->error . " | MaTL: $ma_tl");
                throw new Exception("Không thể xóa tài liệu");
            }
            $stmt->close();
            $deleted_files = [];

            if ($file_pdf && file_exists(__DIR__ . "/../" . $file_pdf)) {
                if (@unlink(__DIR__ . "/../" . $file_pdf)) {
                    $deleted_files[] = $file_pdf;
                }
            }
            if ($file_anh && file_exists(__DIR__ . "/../" . $file_anh)) {
                if (@unlink(__DIR__ . "/../" . $file_anh)) {
                    $deleted_files[] = $file_anh;
                }
            }

            return [
                'success'       => true,
                'ma_tl'         => $ma_tl,
                'ten_tl'        => $doc['TenTaiLieu'],
                'deleted_files' => $deleted_files,
            ];

        } catch (Exception $e) {
            $conn->rollback();
            return ['success' => false, 'error' => 'Không thể xóa tài liệu. Vui lòng thử lại!'];
        }
    }
}