<?php
/**
 * Sinh mã tuần tự tiếp theo: DM001, DM002, ..., DM999, DM1000
 * Dùng MAX(CAST(SUBSTRING(...) AS UNSIGNED)) thay vì ORDER BY chuỗi
 *
 * @param mysqli $conn   Kết nối CSDL
 * @param string $table  Tên bảng (whitelist)
 * @param string $column Tên cột khoá chính (whitelist)
 * @param string $prefix Tiền tố (VD: 'DM', 'TG')
 * @return string        Mã tiếp theo
 */
function taoMa(mysqli $conn, string $table, string $column, string $prefix): string
{
    $allowed = [
        'danh_muc'    => ['MaDM'],
        'tac_gia'     => ['MaTG'],
        'phong_ban'   => ['MaPB'],
        'loaitailieu' => ['MaLoai'],
        'namhoc'      => ['MaNam'],
        'tukhoa'      => ['MaTK'],
        'nganh'       => ['MaNganh'],
    ];

    if (!isset($allowed[$table]) || !in_array($column, $allowed[$table], true)) {
        throw new InvalidArgumentException("Bảng/cột không hợp lệ: $table.$column");
    }

    $sql = "SELECT MAX(CAST(SUBSTRING(`$column`, ?) AS UNSIGNED)) AS max_num
            FROM `$table`
            WHERE `$column` LIKE ?";
    $prefixLen   = strlen($prefix) + 1;   
    $likePattern = $prefix . '%';

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $prefixLen, $likePattern);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $next = ((int)($row['max_num'] ?? 0)) + 1;
    $padLength = max(3, strlen((string)$next));
    return $prefix . str_pad($next, $padLength, '0', STR_PAD_LEFT);
}
/**
 * Xoá tài liệu hoàn toàn: DB + file PDF + ảnh bìa + liên kết tác giả
 *
 * @param mysqli $conn     Kết nối CSDL
 * @param string $ma_tl    Mã tài liệu cần xoá
 * @param string $root_dir Thư mục gốc project (VD: __DIR__ . '/../')
 * @return array ['success' => bool, 'message' => string]
 */
function xoa_tai_lieu(mysqli $conn, string $ma_tl, string $root_dir = ''): array
{
    $stmt = $conn->prepare("SELECT TenTaiLieu, FileTaiLieu, AnhBia FROM tai_lieu WHERE MaTL = ? LIMIT 1");
    $stmt->bind_param("s", $ma_tl);
    $stmt->execute();
    $doc = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$doc) {
        return ['success' => false, 'message' => 'Không tìm thấy tài liệu!'];
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare("DELETE FROM tailieutacgia WHERE MaTL = ?");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM phienbanfile WHERE MaTL = ?");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM lichsudoc WHERE MaTL = ?");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM yeuthich WHERE MaTL = ?");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM tai_lieu WHERE MaTL = ?");
        $stmt->bind_param("s", $ma_tl);
        $stmt->execute();
        $stmt->close();

        $conn->commit();

        if (!empty($doc['FileTaiLieu']) && !empty($root_dir)) {
            $path = $root_dir . ltrim($doc['FileTaiLieu'], '/');
            if (is_file($path)) @unlink($path);
        }
        if (!empty($doc['AnhBia']) && !empty($root_dir)) {
            $path = $root_dir . ltrim($doc['AnhBia'], '/');
            if (is_file($path)) @unlink($path);
        }

        return ['success' => true, 'message' => "Đã xoá tài liệu \"{$doc['TenTaiLieu']}\"!"];
    } catch (Throwable $e) {
        $conn->rollback();
        error_log("xoa_tai_lieu() error: " . $e->getMessage() . " | MaTL: $ma_tl");
        return ['success' => false, 'message' => 'Không thể xoá tài liệu. Vui lòng thử lại!'];
    }
}


/**
 * Yêu cầu user phải đăng nhập. Nếu chưa → redirect về login.
 *
 * @param string $login_url URL trang login (mặc định tính toán tự động)
 * @return void
 */
function require_login(string $login_url = ''): void
{
    if (!empty($_SESSION['MaND'])) {
        return;
    }

    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? '';
    $_SESSION['flash_msg'] = 'Vui lòng đăng nhập để tiếp tục!';

    if (empty($login_url)) {
        $login_url = '/thuvienso/pages/auth/login.php';
    }

    header("Location: $login_url");
    exit();
}


/**
 * Yêu cầu user phải là ADMIN hoặc THUTHU.
 * Tự động gọi require_login() nếu chưa đăng nhập.
 *
 * @return void
 */
function require_admin(): void
{
    require_login();

    $role = $_SESSION['MaVaiTro'] ?? '';
    if ($role === 'ADMIN' || $role === 'THUTHU') {
        return;
    }

    http_response_code(403);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>403</title></head><body>';
    echo '<h1>403 — Truy cập bị từ chối</h1>';
    echo '<p>Bạn không có quyền truy cập khu vực quản trị.</p>';
    echo '<a href="/thuvienso/pages/home/index.php">Về trang chủ</a>';
    echo '</body></html>';
    exit();
}
function format_bytes(int $bytes, int $precision = 2): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow   = $bytes ? floor(log($bytes, 1024)) : 0;
    $pow   = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}
function time_ago(?string $datetime): string
{
    if (empty($datetime)) return '—';

    $diff = time() - strtotime($datetime);
    if ($diff < 60)         return 'vừa xong';
    if ($diff < 3600)       return floor($diff / 60) . ' phút trước';
    if ($diff < 86400)      return floor($diff / 3600) . ' giờ trước';
    if ($diff < 604800)     return floor($diff / 86400) . ' ngày trước';
    return date('d/m/Y', strtotime($datetime));
}
function hien_thi_trang_thai(string $trang_thai): string
{
    $map = [
        'Chờ duyệt' => ['Chờ duyệt', 'warning'],
        'Đã duyệt'  => ['Đã duyệt',  'success'],
        'Từ chối'   => ['Từ chối',   'danger'],
        'Ẩn'        => ['Đã ẩn',     'secondary'],
    ];
    [$label, $type] = $map[$trang_thai] ?? [$trang_thai, 'secondary'];
    return "<span class=\"badge badge-$type\">" . htmlspecialchars($label) . "</span>";
}

function validate_upload_file(array $file, array $allowed_ext, array $allowed_mimes, int $max_size): array
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'msg' => 'Lỗi upload file!'];
    }
    if ($file['size'] > $max_size) {
        return ['ok' => false, 'msg' => 'File quá lớn! Tối đa ' . format_bytes($max_size) . '.'];
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext, true)) {
        return ['ok' => false, 'msg' => 'Định dạng không hợp lệ! Chỉ chấp nhận: ' . implode(', ', $allowed_ext)];
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, $allowed_mimes, true)) {
        return ['ok' => false, 'msg' => "Nội dung file không hợp lệ! (MIME: $mime)"];
    }
    return ['ok' => true, 'msg' => '', 'ext' => $ext, 'mime' => $mime];
}
/**
 * Sinh mã ngẫu nhiên duy nhất — chống trùng khi nhiều request cùng lúc.
 * Format: prefix + 10 ký tự hex
 * VD: 'TL' + 'A1B2C3D4E5' = 'TLA1B2C3D4E5' (12 ký tự, vừa varchar(15))
 *
 * @param mysqli $conn       Kết nối CSDL
 * @param string $table      Tên bảng (whitelist)
 * @param string $column     Tên cột khoá chính (whitelist)
 * @param string $prefix     Tiền tố (VD: 'ND', 'TL')
 * @param int    $maxRetries Số lần thử lại tối đa
 * @return string            Mã duy nhất
 * @throws RuntimeException  nếu không sinh được mã sau $maxRetries lần
 */
function generate_unique_id(
    mysqli $conn,
    string $table,
    string $column,
    string $prefix,
    int $maxRetries = 10
): string {
    $allowedTables  = ['nguoidung', 'tai_lieu', 'danh_muc', 'tac_gia',
                       'phong_ban', 'loaitailieu', 'namhoc', 'tukhoa', 'nganh'];
    $allowedColumns = ['MaND', 'MaTL', 'MaDM', 'MaTG',
                       'MaPB', 'MaLoai', 'MaNam', 'MaTK', 'MaNganh'];

    if (!in_array($table, $allowedTables, true)) {
        throw new InvalidArgumentException("Bảng không hợp lệ: $table");
    }
    if (!in_array($column, $allowedColumns, true)) {
        throw new InvalidArgumentException("Cột không hợp lệ: $column");
    }

    for ($i = 0; $i < $maxRetries; $i++) {
        $candidate = $prefix . strtoupper(bin2hex(random_bytes(5)));

        $stmt = $conn->prepare("SELECT 1 FROM `$table` WHERE `$column` = ? LIMIT 1");
        $stmt->bind_param("s", $candidate);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if (!$exists) {
            return $candidate;
        }
    }

    throw new RuntimeException("Không thể sinh mã duy nhất sau $maxRetries lần thử.");
}