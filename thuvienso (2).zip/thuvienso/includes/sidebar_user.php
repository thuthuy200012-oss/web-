<?php
$current_page = $_SERVER['PHP_SELF'];
$base = $base_url ?? '/thuvienso/';
?>
<style>
    .sidebar-user {
        width: 260px;
        background: #0f172a;
        color: #94a3b8;
        padding: 24px 16px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        gap: 8px;
        min-height: calc(100vh - 72px);
        flex-shrink: 0;
    }

    .sidebar-user .user-info-box {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px;
        background: rgba(255,255,255,0.05);
        border-radius: 12px;
        margin-bottom: 16px;
    }

    .sidebar-user .user-info-box .avatar-lg {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: linear-gradient(135deg, #2563eb, #7c3aed);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 16px;
        flex-shrink: 0;
    }

    .sidebar-user .user-info-box .info {
        flex: 1;
        min-width: 0;
    }

    .sidebar-user .user-info-box .info .name {
        color: #fff;
        font-size: 13.5px;
        font-weight: 700;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .sidebar-user .user-info-box .info .role {
        font-size: 11px;
        color: #64748b;
    }

    .sidebar-user .section-title {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        color: #64748b;
        font-weight: 700;
        margin: 16px 0 8px 12px;
    }

    .sidebar-user .menu {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .sidebar-user .menu li a {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 11px 16px;
        color: #94a3b8;
        text-decoration: none;
        font-size: 13.5px;
        font-weight: 500;
        border-radius: 8px;
        transition: all 0.2s ease;
    }

    .sidebar-user .menu li a i {
        font-size: 15px;
        width: 18px;
        text-align: center;
        color: #64748b;
    }

    .sidebar-user .menu li a:hover {
        background: rgba(255, 255, 255, 0.06);
        color: #f8fafc;
    }

    .sidebar-user .menu li a:hover i {
        color: #60a5fa;
    }

    .sidebar-user .menu li.active a {
        background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
        color: #fff;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.35);
    }

    .sidebar-user .menu li.active a i {
        color: #fff;
    }
</style>

<aside class="sidebar-user">

    <div class="user-info-box">
        <div class="avatar-lg"><?= htmlspecialchars(mb_substr($_SESSION['HoTen'] ?? 'U', 0, 1)) ?></div>
        <div class="info">
            <div class="name"><?= htmlspecialchars($_SESSION['HoTen'] ?? 'Người dùng') ?></div>
            <div class="role"><?= htmlspecialchars($_SESSION['TenVaiTro'] ?? 'Thành viên') ?></div>
        </div>
    </div>

    <div class="section-title">Tài khoản</div>
    <ul class="menu">
        <li class="<?= strpos($current_page, '/pages/home/') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/home/index.php">
                <i class="fa-solid fa-house"></i>
                <span>Trang chủ</span>
            </a>
        </li>
        <li class="<?= strpos($current_page, '/pages/profile/index.php') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/profile/index.php">
                <i class="fa-solid fa-id-card"></i>
                <span>Hồ sơ cá nhân</span>
            </a>
        </li>
        <li class="<?= strpos($current_page, '/pages/profile/history.php') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/profile/history.php">
                <i class="fa-solid fa-clock-rotate-left"></i>
                <span>Lịch sử đọc</span>
            </a>
        </li>
    </ul>

    <div class="section-title">Tài liệu</div>
    <ul class="menu">
        <li class="<?= strpos($current_page, '/pages/documents/') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/documents/index.php">
                <i class="fa-solid fa-file-lines"></i>
                <span>Tra cứu tài liệu</span>
            </a>
        </li>
        <li class="<?= strpos($current_page, '/pages/favorites/') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/favorites/index.php">
                <i class="fa-solid fa-heart"></i>
                <span>Tài liệu yêu thích</span>
            </a>
        </li>
        <li class="<?= strpos($current_page, '/pages/citation/') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/citation/index.php">
                <i class="fa-solid fa-quote-right"></i>
                <span>Trích dẫn</span>
            </a>
        </li>
    </ul>

    <div class="section-title">Nộp tài liệu</div>
    <ul class="menu">
        <li class="<?= strpos($current_page, '/pages/submission/') !== false ? 'active' : '' ?>">
            <a href="<?= $base ?>pages/submission/index.php">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <span>Bài đã nộp</span>
            </a>
        </li>
        <li>
            <a href="<?= $base ?>pages/submission/create.php">
                <i class="fa-solid fa-plus-circle"></i>
                <span>Nộp tài liệu mới</span>
            </a>
        </li>
    </ul>

    <div class="section-title">Khác</div>
    <ul class="menu">
        <li>
            <a href="<?= $base ?>pages/auth/logout.php">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Đăng xuất</span>
            </a>
        </li>
    </ul>

</aside>