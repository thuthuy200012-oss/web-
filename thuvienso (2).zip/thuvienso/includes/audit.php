<?php

if (!function_exists('ghi_log')) {
    function ghi_log(
        mysqli $conn,
        string $hanh_dong,
        string $mo_ta = '',
        string $doi_tuong = '',
        string $ma_doi_tuong = ''
    ): void {
        $ma_nd  = $_SESSION['MaND']   ?? null;
        $ho_ten = $_SESSION['HoTen']  ?? null;

        $ip = $_SERVER['HTTP_X_FORWARDED_FOR']
            ?? $_SERVER['HTTP_X_REAL_IP']
            ?? $_SERVER['REMOTE_ADDR']
            ?? null;
        if ($ip && strpos($ip, ',') !== false) {
            $ip = trim(explode(',', $ip)[0]);
        }
if ($ip === '::1') {
    $ip = '127.0.0.1';
}
elseif ($ip && strpos($ip, '::ffff:') === 0) {
    $ip = substr($ip, 7);
}

        $ua = $_SERVER['HTTP_USER_AGENT'] ?? null;
        if ($ua !== null) $ua = mb_substr($ua, 0, 500);

        $stmt = $conn->prepare("
            INSERT INTO nhatkyhoatdong
            (MaND, HoTen, HanhDong, MoTa, DoiTuong, MaDoiTuong, IPAddress, UserAgent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        if (!$stmt) return;
        $stmt->bind_param("ssssssss",
            $ma_nd, $ho_ten, $hanh_dong, $mo_ta, $doi_tuong, $ma_doi_tuong, $ip, $ua);
        $stmt->execute();
        $stmt->close();
    }
}

if (!function_exists('ghi_log_guest')) {
    function ghi_log_guest(
        mysqli $conn,
        string $ma_nd,
        string $ho_ten,
        string $hanh_dong,
        string $mo_ta = ''
    ): void {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $ua = mb_substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

        $stmt = $conn->prepare("
            INSERT INTO nhatkyhoatdong
            (MaND, HoTen, HanhDong, MoTa, IPAddress, UserAgent)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        if (!$stmt) return;
        $stmt->bind_param("ssssss", $ma_nd, $ho_ten, $hanh_dong, $mo_ta, $ip, $ua);
        $stmt->execute();
        $stmt->close();
    }
}