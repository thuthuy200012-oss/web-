<?php
if (empty($_SESSION['MaND'])) return;

require_once __DIR__ . '/config_helper.php';
$ai_enabled_chat = get_config($conn, 'ai_enabled', '0');
if ($ai_enabled_chat !== '1') return;

$base_chat = $base_url ?? '/thuvienso/';
?>

<button class="ai-chat-fab" id="aiChatFab" onclick="toggleAIChat()" title="Trợ lý AI - Tra cứu tài liệu nội sinh">
    <i class="fa-solid fa-robot"></i>
    <span class="ai-chat-fab-badge">AI</span>
</button>

<div class="ai-chat-window" id="aiChatWindow">
    <div class="ai-chat-header">
        <div class="ai-chat-header-info">
            <div class="ai-chat-avatar"><i class="fa-solid fa-robot"></i></div>
            <div>
                <div class="ai-chat-title">Trợ lý Thư viện AI</div>
                <div class="ai-chat-status">
                    <span class="ai-chat-dot"></span> Tra cứu tài liệu nội sinh
                </div>
            </div>
        </div>
        <div style="display:flex; gap:6px;">
            <button class="ai-chat-close" onclick="clearAIChat()" title="Xóa lịch sử">
                <i class="fa-solid fa-rotate-right"></i>
            </button>
            <button class="ai-chat-close" onclick="toggleAIChat()" title="Đóng">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    </div>

    <div class="ai-chat-body" id="aiChatBody">
        <div class="ai-chat-msg ai-chat-msg-bot">
            <div class="ai-chat-msg-avatar"><i class="fa-solid fa-robot"></i></div>
            <div class="ai-chat-msg-content">
                <p>Xin chào <b><?= htmlspecialchars($_SESSION['HoTen'] ?? 'bạn') ?></b>! 👋</p>
                <p>Tôi là <b>Trợ lý Thư viện AI</b>, chuyên hỗ trợ tra cứu <b>tài liệu nội sinh</b> (Luận văn, Khóa luận, Đề tài NCKH) của Trường Đại học Phan Thiết.</p>
                <p>Bạn có thể hỏi tôi bằng câu hỏi tự nhiên:</p>
                <div class="ai-chat-suggestions">
                    <button onclick="aiQuickAsk('Tìm luận văn về CNTT')">Luận văn về CNTT</button>
                    <button onclick="aiQuickAsk('Đề tài NCKH mới nhất')">Đề tài NCKH mới nhất</button>
                    <button onclick="aiQuickAsk('Khóa luận về kinh tế')">Khóa luận về kinh tế</button>
                    <button onclick="aiQuickAsk('Tài liệu về du lịch')">Tài liệu về du lịch</button>
                </div>
            </div>
        </div>
    </div>

    <div class="ai-chat-footer">
        <div class="ai-chat-input-wrap">
            <input type="text" id="aiChatInput"
                   placeholder="Hỏi về tài liệu nội sinh..."
                   onkeypress="if(event.key==='Enter') sendAIChat()">
            <button class="ai-chat-mic" id="aiChatMic" onclick="startVoiceChat()" title="Nói">
                <i class="fa-solid fa-microphone"></i>
            </button>
        </div>
        <button class="ai-chat-send" onclick="sendAIChat()">
            <i class="fa-solid fa-paper-plane"></i>
        </button>
    </div>
</div>

<style>
    .ai-chat-fab {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: linear-gradient(135deg, #8b5cf6, #7c3aed);
        color: #fff;
        border: none;
        cursor: pointer;
        font-size: 26px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 8px 24px rgba(139, 92, 246, 0.4);
        z-index: 9998;
        transition: all 0.3s;
    }
    .ai-chat-fab:hover {
        transform: scale(1.1);
        box-shadow: 0 12px 32px rgba(139, 92, 246, 0.6);
    }
    .ai-chat-fab-badge {
        position: absolute;
        top: -4px;
        right: -4px;
        background: #dc2626;
        color: #fff;
        font-size: 10px;
        font-weight: 800;
        padding: 3px 7px;
        border-radius: 10px;
        border: 2px solid #fff;
        letter-spacing: 0.5px;
        animation: aiChatPulse 2s infinite;
    }
    @keyframes aiChatPulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.15); }
    }
    .ai-chat-fab.active { transform: rotate(90deg) scale(0.9); }

    .ai-chat-window {
        position: fixed;
        bottom: 100px;
        right: 24px;
        width: 400px;
        max-width: calc(100vw - 32px);
        height: 600px;
        max-height: calc(100vh - 140px);
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 20px 60px rgba(15, 23, 42, 0.3);
        display: none;
        flex-direction: column;
        z-index: 9999;
        overflow: hidden;
        animation: aiChatSlideUp 0.3s ease;
    }
    .ai-chat-window.show { display: flex; }
    @keyframes aiChatSlideUp {
        from { opacity: 0; transform: translateY(20px) scale(0.95); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
    }
    .ai-chat-header {
        background: linear-gradient(135deg, #8b5cf6, #7c3aed);
        color: #fff;
        padding: 14px 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-shrink: 0;
    }
    .ai-chat-header-info { display: flex; align-items: center; gap: 12px; }
    .ai-chat-avatar {
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
    }
    .ai-chat-title { font-size: 15px; font-weight: 700; }
    .ai-chat-status {
        font-size: 11px;
        opacity: 0.85;
        display: flex;
        align-items: center;
        gap: 5px;
        margin-top: 2px;
    }
    .ai-chat-dot {
        width: 6px;
        height: 6px;
        background: #22c55e;
        border-radius: 50%;
        display: inline-block;
        animation: aiChatPulse 1.5s infinite;
    }
    .ai-chat-close {
        background: rgba(255, 255, 255, 0.15);
        border: none;
        color: #fff;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .ai-chat-close:hover { background: rgba(255, 255, 255, 0.3); }

    .ai-chat-body {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        background: #f8fafc;
        display: flex;
        flex-direction: column;
        gap: 14px;
    }
    .ai-chat-body::-webkit-scrollbar { width: 6px; }
    .ai-chat-body::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }

    .ai-chat-msg { display: flex; gap: 10px; animation: aiChatMsgIn 0.3s ease; }
    @keyframes aiChatMsgIn {
        from { opacity: 0; transform: translateY(10px); }
        to   { opacity: 1; transform: translateY(0); }
    }
    .ai-chat-msg-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        flex-shrink: 0;
    }
    .ai-chat-msg-bot .ai-chat-msg-avatar {
        background: linear-gradient(135deg, #8b5cf6, #7c3aed);
        color: #fff;
    }
    .ai-chat-msg-user { flex-direction: row-reverse; }
    .ai-chat-msg-user .ai-chat-msg-avatar { background: #16a34a; color: #fff; }
    .ai-chat-msg-content {
        background: #fff;
        padding: 10px 14px;
        border-radius: 12px;
        max-width: 82%;
        font-size: 13.5px;
        line-height: 1.5;
        border: 1px solid #e2e8f0;
    }
    .ai-chat-msg-user .ai-chat-msg-content {
        background: #dcfce7;
        border-color: #86efac;
    }
    .ai-chat-msg-content p { margin: 0 0 6px; }
    .ai-chat-msg-content p:last-child { margin-bottom: 0; }
    .ai-chat-msg-content ul { padding-left: 20px; margin: 6px 0; }
    .ai-chat-msg-content li { margin-bottom: 6px; font-size: 13px; }
    .ai-chat-msg-content a { color: #7c3aed; font-weight: 600; text-decoration: none; }
    .ai-chat-msg-content a:hover { text-decoration: underline; }

    .ai-chat-suggestions { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
    .ai-chat-suggestions button {
        padding: 6px 12px;
        background: #f1f5f9;
        border: 1px solid #e2e8f0;
        border-radius: 999px;
        font-size: 12px;
        color: #475569;
        cursor: pointer;
        transition: all 0.15s;
        font-family: inherit;
    }
    .ai-chat-suggestions button:hover {
        background: #ede9fe;
        border-color: #8b5cf6;
        color: #7c3aed;
    }

    .ai-chat-filters { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
    .ai-chat-filter-chip {
        padding: 3px 10px;
        background: #ede9fe;
        color: #6d28d9;
        border-radius: 999px;
        font-size: 11.5px;
        font-weight: 600;
    }

    .ai-chat-typing {
        display: flex;
        gap: 4px;
        padding: 12px 16px;
        background: #fff;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        width: fit-content;
    }
    .ai-chat-typing span {
        width: 8px;
        height: 8px;
        background: #8b5cf6;
        border-radius: 50%;
        animation: aiChatTyping 1.4s infinite;
    }
    .ai-chat-typing span:nth-child(2) { animation-delay: 0.2s; }
    .ai-chat-typing span:nth-child(3) { animation-delay: 0.4s; }
    @keyframes aiChatTyping {
        0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
        30% { transform: translateY(-6px); opacity: 1; }
    }
    .ai-chat-footer {
        padding: 12px 14px;
        background: #fff;
        border-top: 1px solid #e2e8f0;
        display: flex;
        gap: 8px;
        align-items: center;
        flex-shrink: 0;
    }
    .ai-chat-input-wrap {
        flex: 1;
        display: flex;
        align-items: center;
        background: #f8fafc;
        border: 1.5px solid #e2e8f0;
        border-radius: 999px;
        padding: 0 8px 0 14px;
        transition: border-color 0.2s;
    }
    .ai-chat-input-wrap:focus-within { border-color: #8b5cf6; }
    .ai-chat-input-wrap input {
        flex: 1;
        border: none;
        background: transparent;
        padding: 10px 0;
        font-size: 13.5px;
        outline: none;
        font-family: inherit;
    }
    .ai-chat-mic {
        background: none;
        border: none;
        color: #64748b;
        cursor: pointer;
        padding: 6px;
        font-size: 15px;
    }
    .ai-chat-mic:hover { color: #8b5cf6; }
    .ai-chat-mic.recording { color: #dc2626; animation: aiChatMicPulse 1s infinite; }
    @keyframes aiChatMicPulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.2); }
    }
    .ai-chat-send {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #8b5cf6, #7c3aed);
        color: #fff;
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 15px;
        flex-shrink: 0;
        transition: all 0.2s;
    }
    .ai-chat-send:hover { transform: scale(1.08); }
    @media (max-width: 500px) {
        .ai-chat-window {
            bottom: 0; right: 0;
            width: 100%; height: 100%;
            max-height: 100%;
            border-radius: 0;
        }
        .ai-chat-fab { bottom: 16px; right: 16px; }
    }
</style>

<script>
(function() {
    'use strict';
    const BASE_URL = '<?= $base_chat ?>';

    window.toggleAIChat = function() {
        const win = document.getElementById('aiChatWindow');
        const fab = document.getElementById('aiChatFab');
        win.classList.toggle('show');
        fab.classList.toggle('active');
        if (win.classList.contains('show')) {
            setTimeout(() => document.getElementById('aiChatInput').focus(), 200);
        }
    };

    window.clearAIChat = function() {
        if (!confirm('Xóa toàn bộ lịch sử trò chuyện?')) return;
        const body = document.getElementById('aiChatBody');
        body.innerHTML = `
            <div class="ai-chat-msg ai-chat-msg-bot">
                <div class="ai-chat-msg-avatar"><i class="fa-solid fa-robot"></i></div>
                <div class="ai-chat-msg-content"><p>Đã xóa lịch sử! Tôi có thể giúp gì cho bạn? 🤖</p></div>
            </div>
        `;
    };

    window.aiQuickAsk = function(query) {
        document.getElementById('aiChatInput').value = query;
        sendAIChat();
    };

    window.sendAIChat = function() {
        const input = document.getElementById('aiChatInput');
        const query = input.value.trim();
        if (!query) return;

        addUserMessage(query);
        input.value = '';

        const typingId = addTypingIndicator();

        fetch(BASE_URL + 'pages/search/ai_search.php?q=' + encodeURIComponent(query))
            .then(res => res.json())
            .then(data => {
                removeTypingIndicator(typingId);
                if (!data.success) {
                    addBotMessage('❌ <b>Lỗi:</b> ' + escapeHtml(data.error));
                    return;
                }
                showBotResults(data);
            })
            .catch(err => {
                removeTypingIndicator(typingId);
                addBotMessage('❌ <b>Lỗi kết nối:</b> ' + escapeHtml(err.message));
            });
    };

    function addUserMessage(text) {
        const body = document.getElementById('aiChatBody');
        body.insertAdjacentHTML('beforeend', `
            <div class="ai-chat-msg ai-chat-msg-user">
                <div class="ai-chat-msg-avatar"><i class="fa-solid fa-user"></i></div>
                <div class="ai-chat-msg-content"><p>${escapeHtml(text)}</p></div>
            </div>
        `);
        scrollToBottom();
    }

    function addBotMessage(html) {
        const body = document.getElementById('aiChatBody');
        body.insertAdjacentHTML('beforeend', `
            <div class="ai-chat-msg ai-chat-msg-bot">
                <div class="ai-chat-msg-avatar"><i class="fa-solid fa-robot"></i></div>
                <div class="ai-chat-msg-content">${html}</div>
            </div>
        `);
        scrollToBottom();
    }

    function showBotResults(data) {
        const filters = data.filters || {};
        const docs = data.docs || [];

        let filterChips = '';
        const filterLabels = {
            keyword: 'Từ khóa',
            loai_tai_lieu: 'Loại',
            nam_xuat_ban: 'Năm',
            tac_gia: 'Tác giả',
            nganh: 'Ngành',
            danh_muc: 'Danh mục',
        };
        for (const [key, label] of Object.entries(filterLabels)) {
            const val = filters[key];
            if (val && val !== 0 && val !== '') {
                filterChips += `<span class="ai-chat-filter-chip">${label}: ${escapeHtml(val)}</span>`;
            }
        }

        let html = '';
        if (filterChips) {
            html += `<p><b>🎯 Tôi hiểu bạn muốn tìm:</b></p>`;
            html += `<div class="ai-chat-filters">${filterChips}</div>`;
        }

        if (docs.length === 0) {
            html += `<p style="margin-top:10px;">😔 Không tìm thấy tài liệu nội sinh nào khớp.</p>`;
            html += `<p style="font-size:12px; color:#64748b;">Gợi ý: Thử hỏi cụ thể hơn như "Luận văn về CNTT năm 2024"</p>`;
        } else {
            html += `<p style="margin-top:10px;"><b>📚 Tìm thấy ${docs.length} tài liệu nội sinh:</b></p>`;
            html += '<ul>';
            docs.slice(0, 5).forEach(doc => {
                const url = BASE_URL + 'pages/documents/detail.php?id=' + encodeURIComponent(doc.MaTL);
                html += `<li><a href="${url}" target="_blank">${escapeHtml(doc.TenTaiLieu)}</a>`;
                if (doc.TenTacGia) html += `<br><small style="color:#64748b;">✍️ ${escapeHtml(doc.TenTacGia)}</small>`;
                if (doc.NamXuatBan) html += `<small style="color:#64748b;"> · ${doc.NamXuatBan}</small>`;
                html += `</li>`;
            });
            html += '</ul>';
            if (docs.length > 5) {
                html += `<p style="font-size:12px; color:#64748b;">... và ${docs.length - 5} tài liệu khác</p>`;
            }
        }

        addBotMessage(html);
    }

    function addTypingIndicator() {
        const body = document.getElementById('aiChatBody');
        const id = 'typing_' + Date.now();
        body.insertAdjacentHTML('beforeend', `
            <div class="ai-chat-msg ai-chat-msg-bot" id="${id}">
                <div class="ai-chat-msg-avatar"><i class="fa-solid fa-robot"></i></div>
                <div class="ai-chat-typing"><span></span><span></span><span></span></div>
            </div>
        `);
        scrollToBottom();
        return id;
    }

    function removeTypingIndicator(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    function scrollToBottom() {
        const body = document.getElementById('aiChatBody');
        setTimeout(() => { body.scrollTop = body.scrollHeight; }, 50);
    }

    let chatRecognition = null;
    let isChatRecording = false;

    window.startVoiceChat = function() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            alert('Trình duyệt không hỗ trợ nhận diện giọng nói.');
            return;
        }
        if (isChatRecording) return;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        chatRecognition = new SpeechRecognition();
        chatRecognition.lang = 'vi-VN';
        chatRecognition.continuous = false;
        chatRecognition.interimResults = false;

        const micBtn = document.getElementById('aiChatMic');

        chatRecognition.onstart = () => {
            isChatRecording = true;
            if (micBtn) micBtn.classList.add('recording');
        };
        chatRecognition.onresult = (e) => {
            const text = e.results[0][0].transcript;
            document.getElementById('aiChatInput').value = text;
            setTimeout(() => sendAIChat(), 300);
        };
        chatRecognition.onerror = (e) => {
            isChatRecording = false;
            if (micBtn) micBtn.classList.remove('recording');
            if (e.error === 'not-allowed') alert('Vui lòng cho phép truy cập micro.');
        };
        chatRecognition.onend = () => {
            isChatRecording = false;
            if (micBtn) micBtn.classList.remove('recording');
        };
        chatRecognition.start();
    };

    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
})();
</script>