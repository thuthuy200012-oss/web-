<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';
define('MAIL_HOST',     'smtp.gmail.com');
define('MAIL_USERNAME', 'thuthuy200012@gmail.com');      
define('MAIL_PASSWORD', 'ckqvgmyaumoczyyi');          
define('MAIL_FROM',     'Thư viện số');
define('MAIL_PORT',     587);

/**
 * Gửi email đặt lại mật khẩu
 * @param string $toEmail  Email người nhận
 * @param string $hoTen    Tên người nhận
 * @param string $token    Token reset password
 * @return bool            TRUE nếu gửi thành công
 */
function guiMailResetPassword($toEmail, $hoTen, $token) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = MAIL_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM);
        $mail->addAddress($toEmail, $hoTen);
        $baseUrl = 'http://localhost:8080/thuvienso';
        $linkReset = $baseUrl . '/pages/auth/reset-password.php?token=' . $token;
        $mail->isHTML(true);
        $mail->Subject = 'Đặt lại mật khẩu — Thư viện số';

        $mail->Body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #f8fafc; border-radius: 12px;'>
            <div style='text-align: center; margin-bottom: 24px;'>
                <h1 style='color: #2563eb; margin: 0;'>📚 THƯ VIỆN SỐ</h1>
            </div>

            <div style='background: #fff; padding: 30px; border-radius: 10px;'>
                <h2 style='color: #1e293b; margin-top: 0;'>Xin chào, " . htmlspecialchars($hoTen) . "!</h2>

                <p style='color: #475569; line-height: 1.6;'>
                    Chúng tôi nhận được yêu cầu <b>đặt lại mật khẩu</b> cho tài khoản của bạn.
                </p>

                <p style='color: #475569; line-height: 1.6;'>
                    Vui lòng click vào nút bên dưới để đặt lại mật khẩu:
                </p>

                <div style='text-align: center; margin: 30px 0;'>
                    <a href='" . $linkReset . "'
                       style='display: inline-block; padding: 14px 32px; background: #2563eb; color: #fff; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 15px;'>
                        🔑 Đặt lại mật khẩu
                    </a>
                </div>

                <p style='color: #64748b; font-size: 13px; line-height: 1.6;'>
                    <b>⏰ Link có hiệu lực trong 15 phút.</b><br>
                    Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.
                </p>

                <hr style='border: none; border-top: 1px dashed #e2e8f0; margin: 24px 0;'>

                <p style='color: #94a3b8; font-size: 12px;'>
                    Nếu nút không hoạt động, copy link sau vào trình duyệt:<br>
                    <a href='" . $linkReset . "' style='color: #2563eb; word-break: break-all;'>" . $linkReset . "</a>
                </p>
            </div>

            <p style='text-align: center; color: #94a3b8; font-size: 12px; margin-top: 20px;'>
                © " . date('Y') . " Thư viện số — Đại học Phan Thiết
            </p>
        </div>
        ";

        $mail->AltBody = "Xin chào $hoTen,\n\n"
                       . "Click link sau để đặt lại mật khẩu:\n"
                       . "$linkReset\n\n"
                       . "Link có hiệu lực trong 15 phút.";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Lỗi gửi mail: " . $mail->ErrorInfo);
        return false;
    }
}