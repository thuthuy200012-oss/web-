<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$base_path = '/thuvienso/';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . " - Thư viện số" : "Thư viện số Nội sinh"; ?></title>
    
    <link rel="stylesheet" href="<?php echo $base_path; ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .site-header {
            background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
            color: #ffffff;
            padding: 0 28px;
            height: 64px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(37, 99, 235, 0.15);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .header-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: #ffffff;
            font-size: 20px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .header-brand i {
            font-size: 24px;
            color: #60a5fa;
        }
        .header-user-nav {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .user-welcome {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            background: rgba(255, 255, 255, 0.12);
            padding: 6px 14px;
            border-radius: 20px;
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        .btn-header {
            padding: 7px 16px;
            font-size: 13px;
            font-weight: 600;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-header-admin {
            background-color: #3b82f6;
            color: #ffffff;
        }
        .btn-header-admin:hover {
            background-color: #60a5fa;
            transform: translateY(-1px);
        }
        .btn-header-logout {
            background-color: rgba(239, 68, 68, 0.85);
            color: #ffffff;
        }
        .btn-header-logout:hover {
            background-color: #ef4444;
            transform: translateY(-1px);
        }
        .btn-header-login {
            background-color: #ffffff;
            color: #1e3a8a;
        }
        .btn-header-login:hover {
            background-color: #f3f4f6;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>
    <header class="site-header">
        <a href="<?php echo $base_path; ?>index.php" class="header-brand">
            <i class="fa-solid fa-book-bookmark"></i>
            <span>THƯ VIỆN SỐ</span>
        </a>

        <div class="header-user-nav">
            <?php if (isset($_SESSION["MaND"])): ?>
                <div class="user-welcome">
                    <i class="fa-regular fa-circle-user" style="font-size: 16px; color: #93c5fd;"></i>
                    <span>Xin chào, <strong><?php echo htmlspecialchars($_SESSION["HoTen"] ?? $_SESSION["MaND"]); ?></strong></span>
                </div>
                <a href="<?php echo $base_path; ?>pages/auth/logout.php" class="btn-header btn-header-logout">
                    <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất
                </a>
            <?php else: ?>
                <a href="<?php echo $base_path; ?>pages/auth/login.php" class="btn-header btn-header-login">
                    <i class="fa-solid fa-right-to-bracket"></i> Đăng nhập
                </a>
            <?php endif; ?>
        </div>
    </header>