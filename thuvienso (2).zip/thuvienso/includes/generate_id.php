<?php
/**
 * includes/generate_id.php
 * Sinh mã duy nhất có tiền tố — chống trùng khi nhiều request cùng lúc
 */

/**
 * Sinh mã duy nhất.
 * Format: prefix + 10 ký tự hex ngẫu nhiên
 * VD: 'ND' + 'A1B2C3D4E5' = 'NDA1B2C3D4E5' (12 ký tự, vừa varchar(15))
 *
 * @throws RuntimeException nếu không sinh được mã sau $maxRetries lần
 */
function generate_unique_id(
    mysqli $conn,
    string $table,
    string $column,
    string $prefix,
    int $maxRetries = 10
): string {
    $allowedTables  = ['nguoidung', 'tai_lieu', 'danh_muc', 'tac_gia',
                       'phong_ban', 'loaitailieu', 'namhoc', 'tukhoa'];
    $allowedColumns = ['MaND', 'MaTL', 'MaDM', 'MaTG',
                       'MaPB', 'MaLoai', 'MaNam', 'MaTK'];

    if (!in_array($table, $allowedTables, true)) {
        throw new InvalidArgumentException("Bảng không hợp lệ: $table");
    }
    if (!in_array($column, $allowedColumns, true)) {
        throw new InvalidArgumentException("Cột không hợp lệ: $column");
    }

    for ($i = 0; $i < $maxRetries; $i++) {
        $candidate = $prefix . strtoupper(bin2hex(random_bytes(5)));

        $stmt = $conn->prepare("SELECT 1 FROM `$table` WHERE `$column` = ? LIMIT 1");
        $stmt->bind_param("s", $candidate);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if (!$exists) {
            return $candidate;
        }
    }

    throw new RuntimeException("Không thể sinh mã duy nhất sau $maxRetries lần thử.");
}