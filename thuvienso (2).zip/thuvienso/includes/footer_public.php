<footer class="footer-public">
    <div class="footer-container">
        <div class="footer-col">
            <div class="footer-logo">
                <i class="fa-solid fa-graduation-cap"></i>
                <div>
                    <strong>THƯ VIỆN SỐ</strong>
                    <small>Đại học Phan Thiết</small>
                </div>
            </div>
            <p>Kho tri thức số phục vụ học tập, nghiên cứu và đổi mới sáng tạo.</p>
        </div>
        <div class="footer-col">
            <h4>Liên kết nhanh</h4>
            <a href="<?= $base ?>index.php">Trang chủ</a>
            <a href="<?= $base ?>pages/documents/index.php">Tài liệu</a>
            <a href="<?= $base ?>pages/documents/authors.php">Tác giả</a>
        </div>
        <div class="footer-col">
            <h4>Hỗ trợ</h4>
            <a href="<?= $base ?>pages/about/index.php">Giới thiệu</a>
            <a href="<?= $base ?>pages/documents/guide.php">Hướng dẫn</a>
        </div>
        <div class="footer-col">
            <h4>Liên hệ</h4>
            <p><i class="fa-solid fa-location-dot"></i> Đại học Phan Thiết</p>
            <p><i class="fa-solid fa-envelope"></i> support@thuvienso.edu.vn</p>
        </div>
    </div>
    <div class="footer-bottom">
        © <?= date('Y') ?> Thư viện số - Đại học Phan Thiết.
    </div>
</footer>

</body>
</html>