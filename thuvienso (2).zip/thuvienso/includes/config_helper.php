<?php
if (!function_exists('get_config')) {
    function get_config($conn, string $key, string $default = ''): string {
        static $cache = [];
        if (array_key_exists($key, $cache)) return $cache[$key];

        $stmt = $conn->prepare("SELECT GiaTri FROM cau_hinh WHERE Khoa = ? LIMIT 1");
        if (!$stmt) return $default;

        $stmt->bind_param('s', $key);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res->fetch_assoc();
        $stmt->close();

        $value = $row['GiaTri'] ?? $default;
        $cache[$key] = $value;
        return $value;
    }
}

if (!function_exists('get_configs_by_group')) {
    function get_configs_by_group(mysqli $conn, string $nhom): array {
        $result = [];
        $stmt = $conn->prepare("SELECT Khoa, GiaTri FROM cau_hinh WHERE Nhom = ? ORDER BY MaCH ASC");
        if (!$stmt) return $result;

        $stmt->bind_param("s", $nhom);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $result[$row['Khoa']] = $row['GiaTri'];
        }
        $stmt->close();
        return $result;
    }
}

if (!function_exists('set_config')) {
    function set_config(mysqli $conn, string $key, $value): bool {
        $value = (string)$value;

        $nhom = null;
        $mota = null;
        $stmt = $conn->prepare("SELECT Nhom, MoTa FROM cau_hinh WHERE Khoa = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $key);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row) {
                $nhom = $row['Nhom'];
                $mota = $row['MoTa'];
            }
        }
        if ($nhom === null) {
            if (strpos($key, 'ai_') === 0)          $nhom = 'ai';
            elseif (strpos($key, 'smtp_') === 0)    $nhom = 'smtp';
            elseif (strpos($key, 'seo_') === 0)     $nhom = 'seo';
            elseif (strpos($key, 'lib_') === 0)     $nhom = 'thu_vien';
            elseif (strpos($key, 'contact_') === 0) $nhom = 'lien_he';
            elseif (strpos($key, 'site_') === 0)    $nhom = 'chung';
            else                                     $nhom = 'chung';
        }

        $stmt = $conn->prepare("DELETE FROM cau_hinh WHERE Khoa = ?");
        if (!$stmt) return false;
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $stmt->close();

        if ($mota !== null) {
            $stmt = $conn->prepare("INSERT INTO cau_hinh (Khoa, GiaTri, Nhom, MoTa, NgayCapNhat) VALUES (?, ?, ?, ?, NOW())");
            if (!$stmt) return false;
            $stmt->bind_param("ssss", $key, $value, $nhom, $mota);
        } else {
            $stmt = $conn->prepare("INSERT INTO cau_hinh (Khoa, GiaTri, Nhom, NgayCapNhat) VALUES (?, ?, ?, NOW())");
            if (!$stmt) return false;
            $stmt->bind_param("sss", $key, $value, $nhom);
        }

        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }
}

if (!function_exists('save_configs')) {
    function save_configs(mysqli $conn, array $data): bool {
        foreach ($data as $key => $value) {
            if (!set_config($conn, $key, $value)) return false;
        }
        return true;
    }
}