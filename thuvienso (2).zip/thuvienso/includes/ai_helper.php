<?php
/**
 * includes/ai_helper.php
 * Gọi Google Gemini API 2.0 Flash + Trích xuất filter tìm kiếm
 *
 * ✅ Model: gemini-2.0-flash (chính thức, quota 1500 req/ngày miễn phí)
 * ✅ Ép IPv4 + HTTP/1.1 tránh timeout XAMPP
 * ✅ Bắt lỗi quota thân thiện
 * ✅ Prompt chuyên biệt cho tài liệu nội sinh ĐH Phan Thiết
 */

if (!function_exists('call_gemini_api')) {
    /**
     * Gọi Gemini API
     *
     * @param string $api_key  API key (có thể nhiều key cách nhau dấu phẩy)
     * @param string $model    Model (mặc định: gemini-2.0-flash)
     * @param string $prompt   Câu hỏi / prompt
     * @return array ['success' => bool, 'text' => string, 'error' => string]
     */
    function call_gemini_api(string $api_key, string $model, string $prompt): array {
        if (empty($api_key)) {
            return ['success' => false, 'error' => 'API key trống.'];
        }

        // ✅ Mặc định dùng gemini-2.0-flash
        if (empty($model) || !preg_match('/^gemini-/', $model)) {
            $model = 'gemini-2.0-flash';
        }

        // ✅ Hỗ trợ nhiều API key xoay vòng (cách nhau dấu phẩy)
        $keys = array_values(array_filter(array_map('trim', explode(',', $api_key))));
        if (empty($keys)) {
            return ['success' => false, 'error' => 'Không có API key hợp lệ.'];
        }
        // Xoay vòng key mỗi 5 phút
        $current_key = $keys[(int)(time() / 300) % count($keys)];

        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . urlencode($current_key);

        $payload = [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'temperature'     => 0.3,
                'maxOutputTokens' => 1024,
            ]
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER    => true,
            CURLOPT_POST              => true,
            CURLOPT_HTTPHEADER        => [
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_POSTFIELDS        => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT           => 60,
            CURLOPT_CONNECTTIMEOUT    => 30,
            CURLOPT_IPRESOLVE         => CURL_IPRESOLVE_V4,
            CURLOPT_HTTP_VERSION      => CURL_HTTP_VERSION_1_1,
            CURLOPT_DNS_CACHE_TIMEOUT => 300,
            CURLOPT_SSL_VERIFYPEER    => false,
            CURLOPT_SSL_VERIFYHOST    => false,
            CURLOPT_FOLLOWLOCATION    => true,
            CURLOPT_MAXREDIRS         => 3,
            CURLOPT_USERAGENT         => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            CURLOPT_ENCODING          => '',
        ]);

        $response   = curl_exec($ch);
        $http_code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        $curl_errno = curl_errno($ch);
        $total_time = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
        curl_close($ch);

        if ($curl_errno !== 0 || !empty($curl_error)) {
            error_log("Gemini API cURL Error #$curl_errno: $curl_error | Time: {$total_time}s | Model: $model");
            return [
                'success' => false,
                'error'   => "Lỗi kết nối mạng (cURL #$curl_errno). Vui lòng kiểm tra Internet."
            ];
        }

        if ($http_code !== 200) {
            $err_data = json_decode($response, true);
            $err_msg  = $err_data['error']['message'] ?? "HTTP $http_code";

            // ✅ Bắt lỗi quota → trả về thông báo thân thiện
            if ($http_code === 429 || stripos($err_msg, 'quota') !== false || stripos($err_msg, 'exceeded') !== false) {
                error_log("Gemini API Quota Exceeded: $err_msg");
                return [
                    'success' => false,
                    'error'   => 'QUOTA_EXCEEDED',
                    'detail'  => $err_msg
                ];
            }

            // Lỗi model không tồn tại
            if ($http_code === 404 || stripos($err_msg, 'not found') !== false) {
                error_log("Gemini API Model Not Found: $err_msg");
                return [
                    'success' => false,
                    'error'   => 'MODEL_NOT_FOUND',
                    'detail'  => $err_msg
                ];
            }

            error_log("Gemini API HTTP Error $http_code: $err_msg");
            return ['success' => false, 'error' => "Lỗi API: $err_msg"];
        }

        $data = json_decode($response, true);

        if ($data === null) {
            error_log("Gemini API JSON Parse Error. Response: " . substr($response, 0, 500));
            return ['success' => false, 'error' => 'Response không phải JSON hợp lệ.'];
        }

        if (isset($data['promptFeedback']['blockReason'])) {
            return [
                'success' => false,
                'error'   => 'Nội dung bị chặn: ' . $data['promptFeedback']['blockReason']
            ];
        }

        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

        if (empty($text)) {
            $finish_reason = $data['candidates'][0]['finishReason'] ?? 'UNKNOWN';
            error_log("Gemini API empty text. Finish reason: $finish_reason");
            return [
                'success' => false,
                'error'   => "Không nhận được phản hồi từ AI. (Lý do: $finish_reason)"
            ];
        }

        return [
            'success' => true,
            'text'    => trim($text)
        ];
    }
}

// ============================================================
// ✅ TRÍCH XUẤT FILTER TÌM KIẾM
// ============================================================
if (!function_exists('ai_extract_search_filters')) {
    function ai_extract_search_filters(string $api_key, string $model, string $user_query): array {
        $prompt = <<<PROMPT
Bạn là trợ lý AI của Thư viện số Trường Đại học Phan Thiết.
Nhiệm vụ: Hỗ trợ sinh viên và giảng viên tra cứu MỌI LOẠI TÀI LIỆU (Giáo trình, Luận văn, Khóa luận, Đề tài NCKH, Kỷ yếu, Bài báo, Sách tham khảo...).

Người dùng sẽ hỏi bằng tiếng Việt tự nhiên. Bạn hãy phân tích và trích xuất các tiêu chí tìm kiếm.

QUY TẮC:
1. Chỉ trả về DUY NHẤT một JSON object. KHÔNG có text giải thích, KHÔNG có markdown code block.
2. Loại tài liệu: Nếu user đề cập, trả về đúng tên loại trong DB (VD: "Luận văn", "Khóa luận", "Đề tài NCKH", "Giáo trình", "Kỷ yếu", "Bài báo"). Nếu user không đề cập → để rỗng "".
3. Năm xuất bản: chỉ lấy 4 chữ số. Nếu user nói "mới nhất" hoặc "gần đây" → để 0.
4. Ngành: Trả về TÊN ĐẦY ĐỦ của ngành trong DB:
   - "Công nghệ thông tin" (nếu user nói: "công nghệ thông tin", "CNTT", "IT", "AI", "lập trình")
   - "Kỹ thuật" (nếu user nói: "kỹ thuật", "cơ khí", "điện")
   - "Du lịch" (nếu user nói: "du lịch", "khách sạn")
   - "Kinh tế" (nếu user nói: "kinh tế", "tài chính", "kế toán")
   - "Ngoại ngữ" (nếu user nói: "tiếng anh", "ngoại ngữ")
   - Để rỗng "" nếu user không đề cập ngành cụ thể.
5. Từ khóa: chỉ lấy 1-5 từ khóa chính. VD: "du lịch Bình Thuận", "trí tuệ nhân tạo".
6. Sắp xếp: "newest" nếu user hỏi mới nhất; "popular" nếu hỏi phổ biến; còn lại "relevant".

Cấu trúc JSON:
{
  "keyword": "từ khóa chính",
  "loai_tai_lieu": "Luận văn | Khóa luận | Đề tài NCKH | Giáo trình | Kỷ yếu | Bài báo | rỗng",
  "nam_xuat_ban": năm dạng số (0 nếu không rõ),
  "tac_gia": "tên tác giả (rỗng nếu không có)",
  "nganh": "tên ngành đầy đủ (rỗng nếu không có)",
  "danh_muc": "tên danh mục (rỗng nếu không có)",
  "sap_xep": "relevant | newest | popular"
}

VÍ DỤ:
- "Tìm giáo trình về lập trình" → {"keyword":"lập trình","loai_tai_lieu":"Giáo trình","nam_xuat_ban":0,"tac_gia":"","nganh":"Công nghệ thông tin","danh_muc":"","sap_xep":"relevant"}
- "Luận văn CNTT" → {"keyword":"CNTT","loai_tai_lieu":"Luận văn","nam_xuat_ban":0,"tac_gia":"","nganh":"Công nghệ thông tin","danh_muc":"","sap_xep":"relevant"}

Câu hỏi người dùng: "$user_query"

Trả về JSON:
PROMPT;

        $result = call_gemini_api($api_key, $model, $prompt);

        if (!$result['success']) {
            return ['success' => false, 'error' => $result['error'], 'detail' => $result['detail'] ?? ''];
        }

        // Clean response
        $text = trim($result['text']);
        $text = preg_replace('/^```json\s*/i', '', $text);
        $text = preg_replace('/^```\s*/i', '', $text);
        $text = preg_replace('/```\s*$/', '', $text);
        $text = trim($text);

        if (preg_match('/\{.*\}/s', $text, $matches)) {
            $text = $matches[0];
        }

        $filters = json_decode($text, true);

        if (!$filters || !is_array($filters)) {
            return [
                'success' => false,
                'error'   => 'AI trả về không phải JSON hợp lệ.',
                'raw'     => substr($text, 0, 300)
            ];
        }

        // Chuẩn hóa giá trị mặc định
        $filters = array_merge([
            'keyword'       => '',
            'loai_tai_lieu' => '',
            'nam_xuat_ban'  => 0,
            'tac_gia'       => '',
            'nganh'         => '',
            'danh_muc'      => '',
            'sap_xep'       => 'relevant',
        ], $filters);

        // Chuẩn hóa loại tài liệu
        $filters['loai_tai_lieu'] = trim($filters['loai_tai_lieu']);
        if ($filters['loai_tai_lieu'] !== '') {
            $map_loai = [
                'luận văn'                    => 'Luận văn',
                'luận văn thạc sĩ'            => 'Luận văn',
                'khóa luận'                   => 'Khóa luận',
                'khóa luận tốt nghiệp'        => 'Khóa luận',
                'đề tài nckh'                 => 'Đề tài NCKH',
                'đề tài nghiên cứu khoa học'  => 'Đề tài NCKH',
                'nghiên cứu khoa học'         => 'Đề tài NCKH',
            ];
            $key = mb_strtolower($filters['loai_tai_lieu'], 'UTF-8');
            if (isset($map_loai[$key])) {
                $filters['loai_tai_lieu'] = $map_loai[$key];
            }
        }

        // Chuẩn hóa ngành
        $filters['nganh'] = trim($filters['nganh']);
        if ($filters['nganh'] !== '') {
            $map_nganh = [
                'cntt'                => 'Công nghệ thông tin',
                'it'                  => 'Công nghệ thông tin',
                'công nghệ thông tin' => 'Công nghệ thông tin',
                'kỹ thuật'            => 'Kỹ thuật',
                'ky thuat'            => 'Kỹ thuật',
                'du lịch'             => 'Du lịch',
                'du lich'             => 'Du lịch',
                'kinh tế'             => 'Kinh tế',
                'kinh te'             => 'Kinh tế',
                'ngoại ngữ'           => 'Ngoại ngữ',
                'ngoai ngu'           => 'Ngoại ngữ',
            ];
            $key = mb_strtolower($filters['nganh'], 'UTF-8');
            if (isset($map_nganh[$key])) {
                $filters['nganh'] = $map_nganh[$key];
            }
        }

        // Chuẩn hóa năm
        $filters['nam_xuat_ban'] = (int)$filters['nam_xuat_ban'];
        if ($filters['nam_xuat_ban'] < 1900 || $filters['nam_xuat_ban'] > (int)date('Y') + 1) {
            $filters['nam_xuat_ban'] = 0;
        }

        // Chuẩn hóa sap_xep
        if (!in_array($filters['sap_xep'], ['relevant', 'newest', 'popular'], true)) {
            $filters['sap_xep'] = 'relevant';
        }

        return ['success' => true, 'filters' => $filters];
    }
}