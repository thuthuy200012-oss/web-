<?php
require_once "../includes/check_admin.php";
require_once "../connect.php";

$base_url = "../";
$page_title = "Backup Database";
$current_page = '/backups/backup.php';

$msg = '';
$msg_type = '';

$backup_dir = __DIR__ . "/";
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = 'backup_' . date('Ymd_His') . '.sql';
    $filepath = $backup_dir . $filename;
    
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    while ($row = $result->fetch_row()) $tables[] = $row[0];
    
    $sql_dump = "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $table) {
        $res = $conn->query("SHOW CREATE TABLE `$table`");
        $row = $res->fetch_row();
        $sql_dump .= "DROP TABLE IF EXISTS `$table`;\n";
        $sql_dump .= $row[1] . ";\n\n";
        
        $res = $conn->query("SELECT * FROM `$table`");
        if ($res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                $values = array_map(function($v) use ($conn) {
                    if ($v === null) return 'NULL';
                    return "'" . $conn->real_escape_string($v) . "'";
                }, array_values($row));
                $sql_dump .= "INSERT INTO `$table` VALUES (" . implode(',', $values) . ");\n";
            }
            $sql_dump .= "\n";
        }
    }
    $sql_dump .= "SET FOREIGN_KEY_CHECKS=1;\n";
    
    if (file_put_contents($filepath, $sql_dump)) {
        $msg = "✅ Đã tạo file backup: <b>$filename</b>";
        $msg_type = 'success';
    } else {
        $msg = "❌ Lỗi: Không thể ghi file backup.";
        $msg_type = 'danger';
    }
}

if ($action === 'delete' && isset($_GET['file'])) {
    $file = basename($_GET['file']);
    $filepath = $backup_dir . $file;
    
    if (file_exists($filepath) && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
        if (unlink($filepath)) {
            $msg = "🗑️ Đã xóa file: <b>$file</b>";
            $msg_type = 'success';
        } else {
            $msg = "❌ Không thể xóa file.";
            $msg_type = 'danger';
        }
    } else {
        $msg = "❌ File không tồn tại hoặc không hợp lệ.";
        $msg_type = 'danger';
    }
}

if ($action === 'download' && isset($_GET['file'])) {
    $file = basename($_GET['file']);
    $filepath = $backup_dir . $file;
    
    if (file_exists($filepath) && pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Pragma: public');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        readfile($filepath);
        exit;
    } else {
        $msg = "❌ File không tồn tại hoặc không hợp lệ.";
        $msg_type = 'danger';
    }
}

$backup_files = [];
if (is_dir($backup_dir)) {
    foreach (glob($backup_dir . '*.sql') as $file) {
        $backup_files[] = [
            'name' => basename($file),
            'size' => filesize($file),
            'date' => date('d/m/Y H:i:s', filemtime($file)),
        ];
    }
    usort($backup_files, fn($a, $b) => strcmp($b['name'], $a['name']));
}

include "../includes/header.php";
?>

<style>
    .backup-container { background: #fff; border-radius: 10px; padding: 24px; border: 1px solid #e2e8f0; }
    .backup-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .btn-create { 
        background: #16a34a; color: #fff; border: none; padding: 10px 20px; 
        border-radius: 8px; font-weight: 600; cursor: pointer; display: inline-flex; 
        align-items: center; gap: 8px; transition: 0.2s; font-size: 14px;
    }
    .btn-create:hover { background: #15803d; }
    .backup-table { width: 100%; border-collapse: collapse; }
    .backup-table th { text-align: left; padding: 12px; border-bottom: 2px solid #e2e8f0; font-size: 13px; color: #475569; text-transform: uppercase; }
    .backup-table td { padding: 12px; border-bottom: 1px solid #f1f5f9; font-size: 14px; color: #334155; }
    .file-name { display: flex; align-items: center; gap: 10px; font-weight: 600; color: #1e293b; }
    .file-icon { color: #16a34a; font-size: 18px; }
    .action-btns { display: flex; gap: 8px; justify-content: flex-end; }
    .btn-icon { 
        width: 34px; height: 34px; border-radius: 6px; border: 1px solid #e2e8f0; 
        background: #fff; display: flex; align-items: center; justify-content: center; 
        cursor: pointer; transition: 0.2s; color: #475569; text-decoration: none;
    }
    .btn-icon:hover { background: #f8fafc; }
    .btn-icon.download:hover { color: #16a34a; border-color: #16a34a; }
    .btn-icon.delete:hover { color: #dc2626; border-color: #dc2626; }
    .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; }
    .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
</style>

<div class="layout">
    <?php include "../includes/sidebar.php"; ?>

    <main class="main">
        <div class="page-header">
            <div class="title-block">
                <h1>Backup Database</h1>
                <p style="color:#64748b; font-size:14px; margin-top:4px;">Tạo và quản lý các bản sao lưu cơ sở dữ liệu.</p>
            </div>
        </div>

        <?php if ($msg): ?>
            <div class="alert alert-<?= $msg_type ?>"><?= $msg ?></div>
        <?php endif; ?>

        <div class="backup-container">
            <div class="backup-header">
                <h2 style="font-size:16px; font-weight:700; color:#0c1e3e; margin:0;">Danh sách bản sao lưu</h2>
                <form method="POST" action="?action=create" style="margin:0;" onsubmit="return confirm('Bạn có chắc muốn tạo bản backup mới?');">
                    <button type="submit" class="btn-create">
                        <i class="fa-solid fa-plus"></i> Tạo backup mới
                    </button>
                </form>
            </div>

            <table class="backup-table">
                <thead>
                    <tr>
                        <th>Tên file</th>
                        <th>Ngày backup</th>
                        <th>Dung lượng</th>
                        <th style="text-align:right;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($backup_files)): ?>
                        <tr>
                            <td colspan="4" style="text-align:center; padding:40px; color:#94a3b8;">
                                <i class="fa-solid fa-folder-open" style="font-size:32px; margin-bottom:10px; display:block;"></i>
                                Chưa có file backup nào.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($backup_files as $f): ?>
                            <tr>
                                <td>
                                    <div class="file-name">
                                        <i class="fa-solid fa-file-code file-icon"></i>
                                        <?= htmlspecialchars($f['name']) ?>
                                    </div>
                                </td>
                                <td><?= $f['date'] ?></td>
                                <td><?= round($f['size'] / 1024 / 1024, 2) ?> MB</td>
                                <td>
                                    <div class="action-btns">
                                        <a href="?action=download&file=<?= urlencode($f['name']) ?>" class="btn-icon download" title="Tải xuống">
                                            <i class="fa-solid fa-download"></i>
                                        </a>
                                        <a href="?action=delete&file=<?= urlencode($f['name']) ?>" class="btn-icon delete" title="Xóa" onclick="return confirm('Bạn có chắc muốn xóa file backup này?');">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php include "../includes/footer.php"; ?>