<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/audit.php";

// ============================================================
// 1. KIỂM TRA ĐĂNG NHẬP
// ============================================================
if (!isset($_SESSION['MaND'])) {
    header("Location: ../auth/login.php");
    exit();
}

// ============================================================
// 2. LẤY ID
// ============================================================
$id = trim($_GET['id'] ?? '');
if (empty($id)) {
    die("Thiếu ID tài liệu!");
}

// ============================================================
// 3. TRUY VẤN TÀI LIỆU
// ============================================================
$stmt = $conn->prepare("
    SELECT MaTL, TenTaiLieu, FileTaiLieu, MucTruyCap
    FROM tai_lieu
    WHERE MaTL = ? AND TrangThai = 'Đã duyệt'
    LIMIT 1
");
$stmt->bind_param("s", $id);
$stmt->execute();
$doc = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doc) {
    die("Tài liệu không tồn tại hoặc chưa được duyệt!");
}

if (empty($doc['FileTaiLieu'])) {
    die("Tài liệu này chưa có file đính kèm!");
}

// ============================================================
// 4. ✅ FIX 1.7: KIỂM TRA MỨC TRUY CẬP
// ============================================================
$current_role = $_SESSION['MaVaiTro'] ?? 'SV';
$muc_truy_cap = $doc['MucTruyCap'] ?? 'Công khai';

if ($muc_truy_cap === 'Nội bộ' && !in_array($current_role, ['ADMIN', 'THUTHU', 'GV'])) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    die("
        <!DOCTYPE html>
        <html><head><meta charset='UTF-8'><title>Không có quyền</title>
        <style>body{font-family:sans-serif;text-align:center;padding:50px;}</style></head>
        <body>
            <h2>🔒 Tài liệu này chỉ dành cho Nội bộ</h2>
            <p>Tài liệu này chỉ có thể tải bởi Giảng viên, Thủ thư và Quản trị viên.</p>
            <p><a href='javascript:history.back()'>← Quay lại</a></p>
        </body></html>
    ");
}

// ============================================================
// 5. ✅ FIX 1.7: TĂNG LƯỢT TẢI + GHI LOG
// ============================================================
$ma_nd = $_SESSION['MaND'];

// Tăng lượt tải
$stmt_up = $conn->prepare("UPDATE tai_lieu SET SoLuotTai = SoLuotTai + 1 WHERE MaTL = ?");
$stmt_up->bind_param("s", $id);
$stmt_up->execute();
$stmt_up->close();

// Ghi log lịch sử đọc (bảng cũ)
$stmt_log = $conn->prepare("INSERT INTO lichsudoc (MaND, MaTL, HanhDong) VALUES (?, ?, 'tai')");
$stmt_log->bind_param("ss", $ma_nd, $id);
$stmt_log->execute();
$stmt_log->close();

// Ghi log nhật ký hoạt động
ghi_log($conn, 'DOWNLOAD',
    "Tải tài liệu: {$doc['TenTaiLieu']}",
    'tai_lieu', $doc['MaTL']);

// ============================================================
// 6. ✅ FIX 1.7: CHUYỂN SANG STREAM.PHP
// ============================================================
header("Location: stream.php?id=" . urlencode($id) . "&download=1");
exit();