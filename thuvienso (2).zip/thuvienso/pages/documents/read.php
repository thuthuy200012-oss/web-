<?php
session_start();
require_once "../../connect.php";

// ============================================================
// 1. KIỂM TRA ĐĂNG NHẬP
// ============================================================
if (!isset($_SESSION['MaND'])) {
    header("Location: ../auth/login.php");
    exit();
}

// ============================================================
// 2. LẤY ID
// ============================================================
$id = trim($_GET['id'] ?? '');
if (empty($id)) {
    die("Thiếu ID tài liệu!");
}

// ============================================================
// 3. TRUY VẤN TÀI LIỆU
// ============================================================
$stmt = $conn->prepare("
    SELECT MaTL, TenTaiLieu, FileTaiLieu, MucTruyCap
    FROM tai_lieu
    WHERE MaTL = ? AND TrangThai = 'Đã duyệt'
    LIMIT 1
");
$stmt->bind_param("s", $id);
$stmt->execute();
$doc = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doc) {
    die("Tài liệu không tồn tại hoặc chưa được duyệt!");
}

if (empty($doc['FileTaiLieu'])) {
    die("Tài liệu này chưa có file đính kèm!");
}

// ============================================================
// 4. ✅ FIX 1.7: KIỂM TRA MỨC TRUY CẬP
// ============================================================
$current_role = $_SESSION['MaVaiTro'] ?? 'SV';
$muc_truy_cap = $doc['MucTruyCap'] ?? 'Công khai';

if ($muc_truy_cap === 'Nội bộ' && !in_array($current_role, ['ADMIN', 'THUTHU', 'GV'])) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    die("
        <!DOCTYPE html>
        <html><head><meta charset='UTF-8'><title>Không có quyền</title>
        <style>body{font-family:sans-serif;text-align:center;padding:50px;}</style></head>
        <body>
            <h2>🔒 Tài liệu này chỉ dành cho Nội bộ</h2>
            <p><a href='javascript:history.back()'>← Quay lại</a></p>
        </body></html>
    ");
}

// ============================================================
// 5. GHI LOG ĐỌC
// ============================================================
$ma_nd = $_SESSION['MaND'];
$stmt_log = $conn->prepare("INSERT INTO lichsudoc (MaND, MaTL, HanhDong) VALUES (?, ?, 'doc')");
$stmt_log->bind_param("ss", $ma_nd, $id);
$stmt_log->execute();
$stmt_log->close();

// Ghi log nhật ký hoạt động
if (file_exists("../../includes/audit.php")) {
    require_once "../../includes/audit.php";
    ghi_log($conn, 'VIEW',
        "Xem tài liệu: {$doc['TenTaiLieu']}",
        'tai_lieu', $doc['MaTL']);
}

// ============================================================
// 6. XÁC ĐỊNH LOẠI FILE
// ============================================================
$ext = strtolower(pathinfo($doc['FileTaiLieu'], PATHINFO_EXTENSION));

// ✅ FIX 1.7: URL trỏ qua stream.php, KHÔNG dùng link trực tiếp
$stream_url = "/thuvienso/pages/documents/stream.php?id=" . urlencode($doc['MaTL']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($doc['TenTaiLieu']) ?> - Đọc online</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background: #1e293b;
            color: #fff;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .reader-toolbar {
            background: #0f172a;
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10;
            flex-shrink: 0;
        }

        .reader-title {
            font-size: 15px;
            font-weight: 600;
            color: #f8fafc;
            display: flex;
            align-items: center;
            gap: 10px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 60%;
        }

        .reader-title i {
            color: #60a5fa;
        }

        .reader-actions {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .reader-btn {
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
        }

        .btn-download {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: #fff;
        }
        .btn-download:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(37,99,235,0.4);
        }

        .btn-back {
            background: rgba(255,255,255,0.1);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .btn-back:hover {
            background: rgba(255,255,255,0.2);
        }

        .reader-content {
            flex: 1;
            position: relative;
            background: #334155;
        }

        .reader-iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .reader-msg {
            position: absolute;
            inset: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px;
            text-align: center;
        }

        .reader-msg i {
            font-size: 64px;
            color: #64748b;
            margin-bottom: 20px;
        }

        .reader-msg h2 {
            color: #f1f5f9;
            margin-bottom: 12px;
        }

        .reader-msg p {
            color: #94a3b8;
            margin-bottom: 24px;
        }

        .reader-msg a {
            color: #60a5fa;
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="reader-toolbar">
    <div class="reader-title">
        <i class="fa-solid fa-book-open-reader"></i>
        <?= htmlspecialchars($doc['TenTaiLieu']) ?>
    </div>

    <div class="reader-actions">
        <a href="/thuvienso/pages/documents/download.php?id=<?= urlencode($doc['MaTL']) ?>" class="reader-btn btn-download">
            <i class="fa-solid fa-download"></i> Tải xuống
        </a>
        <a href="/thuvienso/pages/documents/detail.php?id=<?= urlencode($doc['MaTL']) ?>" class="reader-btn btn-back">
            <i class="fa-solid fa-arrow-left"></i> Quay lại
        </a>
    </div>
</div>

<div class="reader-content">
    <?php if ($ext === 'pdf'): ?>
        <?php /* ✅ FIX 1.7: Dùng stream.php thay vì link trực tiếp */ ?>
        <iframe class="reader-iframe" src="<?= htmlspecialchars($stream_url) ?>"></iframe>
    <?php else: ?>
        <div class="reader-msg">
            <i class="fa-solid fa-file-word"></i>
            <h2>Không thể xem trực tuyến</h2>
            <p>Định dạng <b>.<?= htmlspecialchars($ext) ?></b> không hỗ trợ xem trực tiếp. Vui lòng tải xuống để xem.</p>
            <a href="/thuvienso/pages/documents/download.php?id=<?= urlencode($doc['MaTL']) ?>">
                Tải xuống ngay →
            </a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>