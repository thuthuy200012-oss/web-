<?php
session_start();
require_once "../../connect.php";

$base_url = '/thuvienso/';
$current_page = 'documents';

$keyword   = trim($_GET['q'] ?? '');
$danh_muc  = trim($_GET['danh_muc'] ?? '');
$nam       = (int)($_GET['nam'] ?? 0);
$sort      = $_GET['sort'] ?? 'newest';
$page      = max(1, (int)($_GET['page'] ?? 1));
$per_page  = 12;
$offset    = ($page - 1) * $per_page;

$loai_arr = $_GET['loai_arr'] ?? []; 

$where = "WHERE tl.TrangThai = 'Đã duyệt'";
$params = []; $types = "";

if ($keyword !== '') {
    $where .= " AND (tl.TenTaiLieu LIKE ? OR tl.TuKhoa LIKE ? OR tl.TomTat LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw; $params[] = $kw;
    $types .= "sss";
}
if ($danh_muc !== '') {
    $where .= " AND tl.MaDM = ?";
    $params[] = $danh_muc; $types .= "s";
}

if (!empty($loai_arr) && is_array($loai_arr)) {
    $placeholders = implode(',', array_fill(0, count($loai_arr), '?'));
    $where .= " AND tl.LoaiTaiLieu IN ($placeholders)";
    foreach ($loai_arr as $l) {
        $params[] = $l;
        $types .= "s";
    }
}

if ($nam > 0) {
    $where .= " AND tl.NamXuatBan = ?";
    $params[] = $nam; $types .= "i";
}

$order_sql = "ORDER BY tl.NgayDang DESC";
if ($sort === 'views') $order_sql = "ORDER BY tl.SoLuotXem DESC";
elseif ($sort === 'downloads') $order_sql = "ORDER BY tl.SoLuotTai DESC";
elseif ($sort === 'name') $order_sql = "ORDER BY tl.TenTaiLieu ASC";

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu tl $where");
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'];
$total_pages = max(1, ceil($total / $per_page));

$sql = "SELECT tl.*, dm.TenDanhMuc,
            GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
        FROM tai_lieu tl
        LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
        LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
        LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
        $where
        GROUP BY tl.MaTL
        $order_sql
        LIMIT $per_page OFFSET $offset";
$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$documents = $stmt->get_result();

$categories = $conn->query("SELECT * FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");
$loai_list  = $conn->query("SELECT * FROM loaitailieu ORDER BY ThuTu");
$nam_list   = $conn->query("SELECT DISTINCT NamXuatBan FROM tai_lieu WHERE NamXuatBan IS NOT NULL AND TrangThai='Đã duyệt' ORDER BY NamXuatBan DESC");

$page_title = "Tra cứu tài liệu";
include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/documents.css">

<style>
.docs-page-wrapper {
    max-width: 1280px;
    margin: 0 auto;
    padding: 32px 24px 60px;
    display: flex;
    gap: 24px;
    align-items: flex-start;
}

.filter-sidebar {
    width: 280px;
    flex-shrink: 0;
    background: #fff;
    border-radius: 8px;
    padding: 20px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    position: sticky;
    top: 20px;
}

.filter-title {
    font-size: 16px;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 20px;
    text-transform: uppercase;
}

.filter-group {
    margin-bottom: 24px;
}

.filter-group-title {
    font-size: 13px;
    font-weight: 700;
    color: #475569;
    margin-bottom: 12px;
    text-transform: uppercase;
}

.checkbox-list {
    max-height: 200px;
    overflow-y: auto;
    padding-right: 8px;
}
.checkbox-item {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 10px;
    font-size: 14px;
    color: #334155;
    cursor: pointer;
}
.checkbox-item input[type="checkbox"] {
    width: 16px;
    height: 16px;
    accent-color: #16a34a;
    cursor: pointer;
}

.filter-select {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 14px;
    color: #334155;
    outline: none;
    background: #fff;
    cursor: pointer;
}
.filter-select:focus { border-color: #16a34a; }

.filter-input {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 14px;
    outline: none;
}
.filter-input:focus { border-color: #16a34a; }

.btn-filter-submit {
    width: 100%;
    padding: 12px;
    background: #16a34a;
    color: #fff;
    border: none;
    border-radius: 6px;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
    transition: 0.2s;
}
.btn-filter-submit:hover { background: #15803d; }

.btn-filter-reset {
    display: block;
    text-align: center;
    margin-top: 12px;
    padding: 10px;
    background: #f1f5f9;
    color: #475569;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    border: 1px solid #cbd5e1;
}
.btn-filter-reset:hover { background: #e2e8f0; }

.results-area {
    flex-grow: 1;
    min-width: 0;
}

.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.top-bar h1 {
    font-size: 22px;
    font-weight: 700;
    color: #1e293b;
    margin: 0;
}

.sort-wrapper {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: #475569;
}
.sort-select {
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    outline: none;
    font-size: 14px;
}

@media (max-width: 900px) {
    .docs-page-wrapper { flex-direction: column; }
    .filter-sidebar { width: 100%; position: static; }
}
</style>

<main class="docs-page-wrapper">

    <aside class="filter-sidebar">
        <div class="filter-title">Bộ lọc</div>
        
        <form method="GET" action="">
            <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">

            <div class="filter-group">
                <div class="filter-group-title">Thể loại</div>
                <div class="checkbox-list">
                    <?php if ($loai_list && $loai_list->num_rows > 0): ?>
                        <?php while ($l = $loai_list->fetch_assoc()): ?>
                            <label class="checkbox-item">
                                <input type="checkbox" name="loai_arr[]" value="<?= htmlspecialchars($l['TenLoai']) ?>"
                                    <?= in_array($l['TenLoai'], $loai_arr) ? 'checked' : '' ?>>
                                <?= htmlspecialchars($l['TenLoai']) ?>
                            </label>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p style="font-size:13px; color:#94a3b8;">Chưa có dữ liệu</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="filter-group">
                <div class="filter-group-title">Danh mục</div>
                <select name="danh_muc" class="filter-select">
                    <option value="">-- Tất cả danh mục --</option>
                    <?php 
                    $categories->data_seek(0); 
                    while ($c = $categories->fetch_assoc()): 
                    ?>
                        <option value="<?= htmlspecialchars($c['MaDM']) ?>" <?= $danh_muc === $c['MaDM'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['TenDanhMuc']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="filter-group">
                <div class="filter-group-title">Năm xuất bản</div>
                <select name="nam" class="filter-select">
                    <option value="">-- Tất cả năm --</option>
                    <?php 
                    $nam_list->data_seek(0);
                    while ($n = $nam_list->fetch_assoc()): 
                    ?>
                        <option value="<?= $n['NamXuatBan'] ?>" <?= $nam == $n['NamXuatBan'] ? 'selected' : '' ?>>
                            <?= $n['NamXuatBan'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="filter-group">
                <div class="filter-group-title">Từ khóa</div>
                <input type="text" name="q" class="filter-input" placeholder="Nhập từ khóa..." value="<?= htmlspecialchars($keyword) ?>">
            </div>

            <button type="submit" class="btn-filter-submit">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
                </svg>
                Lọc
            </button>

            <?php if ($keyword || $danh_muc || !empty($loai_arr) || $nam): ?>
                <a href="index.php" class="btn-filter-reset">Đặt lại</a>
            <?php endif; ?>
        </form>
    </aside>

    <section class="results-area">
        
        <div class="top-bar">
            <h1>Tra cứu tài liệu</h1>
            <div class="sort-wrapper">
                <span>Sắp xếp:</span>
                <form method="GET" action="" style="margin:0;">
                    <input type="hidden" name="q" value="<?= htmlspecialchars($keyword) ?>">
                    <input type="hidden" name="danh_muc" value="<?= htmlspecialchars($danh_muc) ?>">
                    <input type="hidden" name="nam" value="<?= htmlspecialchars($nam) ?>">
                    
                    <?php foreach ($loai_arr as $l_val): ?>
                        <input type="hidden" name="loai_arr[]" value="<?= htmlspecialchars($l_val) ?>">
                    <?php endforeach; ?>

                    <select name="sort" class="sort-select" onchange="this.form.submit()">
                        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Mới nhất</option>
                        <option value="views" <?= $sort === 'views' ? 'selected' : '' ?>>Xem nhiều</option>
                        <option value="downloads" <?= $sort === 'downloads' ? 'selected' : '' ?>>Tải nhiều</option>
                        <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Tên A-Z</option>
                    </select>
                </form>
            </div>
        </div>

        <div class="results-info" style="margin-bottom: 20px;">
            <p style="color: #64748b; font-size: 14px;">Tìm thấy <b><?= $total ?></b> tài liệu</p>
        </div>

        <?php if ($documents && $documents->num_rows > 0): ?>
            <div class="documents-grid">
                <?php while ($doc = $documents->fetch_assoc()): ?>
                    <div class="doc-card">
                        <div class="doc-thumb">
                            <?php if (!empty($doc['AnhBia']) && file_exists("../../" . $doc['AnhBia'])): ?>
                                <img src="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>&type=cover" alt="<?= htmlspecialchars($doc['TenTaiLieu']) ?>">
                            <?php else: ?>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:#86efac;">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
                                </svg>
                            <?php endif; ?>
                            <span class="doc-type-badge"><?= htmlspecialchars($doc['LoaiTaiLieu'] ?? 'Khác') ?></span>
                        </div>
                        <div class="doc-body">
                            <h3><?= htmlspecialchars($doc['TenTaiLieu']) ?></h3>
                            <p class="doc-author">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                <?= htmlspecialchars($doc['TenTacGia'] ?? 'Chưa rõ') ?>
                            </p>
                            <p class="doc-cat">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                                <?= htmlspecialchars($doc['TenDanhMuc'] ?? 'Chưa phân loại') ?>
                                <?php if (!empty($doc['NamXuatBan'])): ?> · <?= $doc['NamXuatBan'] ?><?php endif; ?>
                            </p>
                            <div class="doc-meta">
                                <span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg> <?= number_format($doc['SoLuotXem']) ?></span>
                                <span><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> <?= number_format($doc['SoLuotTai']) ?></span>
                            </div>
                            <div class="doc-actions">
                                <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= urlencode($doc['MaTL']) ?>" class="btn-view">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg> Xem
                                </a>
                                <a href="<?= $base_url ?>pages/documents/download.php?id=<?= urlencode($doc['MaTL']) ?>" class="btn-download">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Tải
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination-user">
                    <?php if ($page > 1): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">‹</a>
                    <?php endif; ?>

                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>

                    <?php if ($page < $total_pages): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">›</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <div class="empty-docs">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 14l1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2"/></svg>
                <h3>Không tìm thấy tài liệu nào</h3>
                <p>Thử thay đổi từ khóa hoặc bộ lọc</p>
            </div>
        <?php endif; ?>
    </section>
</main>

<?php include "../../includes/footer_public.php"; ?>