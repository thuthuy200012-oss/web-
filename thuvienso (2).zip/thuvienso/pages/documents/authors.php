<?php
session_start();
require_once "../../connect.php";

$base_url     = '/thuvienso/';
$current_page = 'tac-gia';
$page_title   = "Tác giả";

// ============================================================
// LẤY DANH SÁCH TẤT CẢ TÁC GIẢ (kể cả chưa có tài liệu)
// ============================================================
$keyword  = trim($_GET['q'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$per_page = 24;
$offset   = ($page - 1) * $per_page;

// Điều kiện cơ bản
$where  = "WHERE tg.TrangThai = 1";
$params = [];
$types  = "";

// Thêm điều kiện tìm kiếm
if ($keyword !== '') {
    $where .= " AND (tg.HoTen LIKE ? OR tg.HocVi LIKE ? OR tg.ChucVu LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw; $params[] = $kw;
    $types   .= "sss";
}

// ============================================================
// ĐẾM TỔNG TÁC GIẢ
// ============================================================
$sql_count = "
    SELECT COUNT(*) AS c
    FROM tac_gia tg
    $where
";
$stmt = $conn->prepare($sql_count);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();
$total_pages = max(1, ceil($total / $per_page));

// ============================================================
// LẤY DANH SÁCH TÁC GIẢ
// Dùng LEFT JOIN để tác giả không có tài liệu vẫn hiện
// ============================================================
$sql = "
    SELECT tg.MaTG, tg.HoTen, tg.HocVi, tg.ChucVu, tg.Email,
        pb.TenPhongBan,
        COUNT(DISTINCT tl.MaTL) AS SoTaiLieu
    FROM tac_gia tg
    LEFT JOIN phong_ban pb ON tg.MaPB = pb.MaPB
    LEFT JOIN tailieutacgia tltg ON tg.MaTG = tltg.MaTG
    LEFT JOIN tai_lieu tl ON tltg.MaTL = tl.MaTL AND tl.TrangThai = 'Đã duyệt'
    $where
    GROUP BY tg.MaTG
    ORDER BY SoTaiLieu DESC, tg.HoTen ASC
    LIMIT $per_page OFFSET $offset
";
$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$authors = $stmt->get_result();

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/public.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/documents.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/authors.css">

<main class="authors-wrapper">

    <div class="authors-header">
        <h1>Tác giả</h1>
        <p>Khám phá các tác giả đã đóng góp tài liệu cho thư viện</p>
    </div>

    <!-- Search bar -->
    <form method="GET" class="authors-search">
        <input type="text" name="q" placeholder="Tìm theo tên, học vị, chức vụ..." value="<?= htmlspecialchars($keyword) ?>" autofocus>
        <button type="submit">
            <i class="fa-solid fa-magnifying-glass"></i> Tìm kiếm
        </button>
    </form>

    <!-- Info bar -->
    <div class="authors-info">
        <span>Tìm thấy <b><?= number_format($total) ?></b> tác giả</span>
        <?php if ($total_pages > 1): ?>
            <span>Trang <b><?= $page ?></b> / <b><?= $total_pages ?></b></span>
        <?php endif; ?>
    </div>

    <!-- Grid tác giả -->
    <?php if ($authors && $authors->num_rows > 0): ?>
        <div class="authors-grid">
            <?php while ($a = $authors->fetch_assoc()):
                $initial = mb_substr($a['HoTen'], 0, 1);
                $so_tl   = (int)$a['SoTaiLieu'];
                $has_docs = ($so_tl > 0);
            ?>
                <a href="<?= $base_url ?>pages/documents/index.php?tac_gia=<?= urlencode($a['MaTG']) ?>" class="author-card">
                    <div class="author-avatar <?= $has_docs ? '' : 'author-avatar-empty' ?>">
                        <?= htmlspecialchars($initial) ?>
                    </div>
                    <div class="author-info">
                        <div class="author-name"><?= htmlspecialchars($a['HoTen']) ?></div>

                        <?php if (!empty($a['HocVi']) || !empty($a['ChucVu']) || !empty($a['TenPhongBan'])): ?>
                            <div class="author-meta">
                                <?php if (!empty($a['HocVi'])): ?>
                                    <span><i class="fa-solid fa-graduation-cap"></i> <?= htmlspecialchars($a['HocVi']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($a['ChucVu'])): ?>
                                    <span><i class="fa-solid fa-briefcase"></i> <?= htmlspecialchars($a['ChucVu']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($a['TenPhongBan'])): ?>
                                    <span><i class="fa-solid fa-building-columns"></i> <?= htmlspecialchars($a['TenPhongBan']) ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="author-count <?= $has_docs ? '' : 'author-count-empty' ?>">
                            <i class="fa-solid fa-file-lines"></i>
                            <?php if ($has_docs): ?>
                                <?= $so_tl ?> tài liệu
                            <?php else: ?>
                                Chưa có tài liệu
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <div class="pagination-authors">
                <?php if ($page > 1): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">‹</a>
                <?php endif; ?>

                <?php
                $start = max(1, $page - 2);
                $end   = min($total_pages, $page + 2);

                if ($start > 1) {
                    echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => 1])) . '">1</a>';
                    if ($start > 2) echo '<span class="dots">...</span>';
                }

                for ($i = $start; $i <= $end; $i++):
                ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"
                    class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor;

                if ($end < $total_pages) {
                    if ($end < $total_pages - 1) echo '<span class="dots">...</span>';
                    echo '<a href="?' . http_build_query(array_merge($_GET, ['page' => $total_pages])) . '">' . $total_pages . '</a>';
                }
                ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">›</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="authors-empty">
            <i class="fa-solid fa-user-slash"></i>
            <h3>Không tìm thấy tác giả nào</h3>
            <p>
                <?php if ($keyword): ?>
                    Không có kết quả cho "<?= htmlspecialchars($keyword) ?>"
                <?php else: ?>
                    Chưa có tác giả nào trong hệ thống
                <?php endif; ?>
            </p>
            <?php if ($keyword): ?>
                <a href="authors.php" class="btn-reset">
                    <i class="fa-solid fa-rotate-left"></i> Xem tất cả
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</main>

<?php include "../../includes/footer_public.php"; ?>