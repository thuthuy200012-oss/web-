<?php
/**
 * ✅ FIX 1.7: Stream file với kiểm tra đăng nhập + MucTruyCap
 * 
 * Cách dùng:
 *   - Xem PDF:    /pages/documents/stream.php?id=TL001
 *   - Tải PDF:    /pages/documents/stream.php?id=TL001&download=1
 *   - Xem ảnh:    /pages/documents/stream.php?id=TL001&type=cover
 */

session_start();
require_once "../../connect.php";

// ============================================================
// 1. KIỂM TRA ĐĂNG NHẬP
// ============================================================
if (!isset($_SESSION['MaND'])) {
    http_response_code(401);
    header('Content-Type: text/html; charset=utf-8');
    die("
        <!DOCTYPE html>
        <html><head><meta charset='UTF-8'><title>Cần đăng nhập</title>
        <style>body{font-family:sans-serif;text-align:center;padding:50px;}
        a{color:#2563eb;}</style></head>
        <body>
            <h2>⚠️ Bạn cần đăng nhập để xem tài liệu</h2>
            <p><a href='../auth/login.php'>Đăng nhập ngay</a></p>
        </body></html>
    ");
}

// ============================================================
// 2. LẤY THAM SỐ
// ============================================================
$id          = trim($_GET['id'] ?? '');
$is_download = isset($_GET['download']) && $_GET['download'] == '1';
$type        = $_GET['type'] ?? 'file';   // 'file' hoặc 'cover'

if (empty($id)) {
    http_response_code(400);
    die("Thiếu tham số id");
}

// ============================================================
// 3. TRUY VẤN TÀI LIỆU (lấy thêm AnhBia)
// ============================================================
$stmt = $conn->prepare("
    SELECT MaTL, TenTaiLieu, FileTaiLieu, AnhBia, MucTruyCap
    FROM tai_lieu
    WHERE MaTL = ? AND TrangThai = 'Đã duyệt'
    LIMIT 1
");
$stmt->bind_param("s", $id);
$stmt->execute();
$doc = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doc) {
    http_response_code(404);
    die("Không tìm thấy tài liệu (hoặc tài liệu chưa được duyệt)");
}

// ============================================================
// 4. KIỂM TRA MỨC TRUY CẬP (chỉ check cho FILE, không check ẢNH BÌA)
// ============================================================
$current_role = $_SESSION['MaVaiTro'] ?? 'SV';
$muc_truy_cap = $doc['MucTruyCap'] ?? 'Công khai';

// Ảnh bìa thì cho phép xem công khai — không cần check MucTruyCap
if ($type !== 'cover' && $muc_truy_cap === 'Nội bộ' && !in_array($current_role, ['ADMIN', 'THUTHU', 'GV'])) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    die("
        <!DOCTYPE html>
        <html><head><meta charset='UTF-8'><title>Không có quyền</title>
        <style>body{font-family:sans-serif;text-align:center;padding:50px;}</style></head>
        <body>
            <h2>🔒 Tài liệu này chỉ dành cho Nội bộ</h2>
            <p><a href='javascript:history.back()'>← Quay lại</a></p>
        </body></html>
    ");
}

// ============================================================
// 5. XÁC ĐỊNH FILE CẦN STREAM (FILE PDF hay ẢNH BÌA)
// ============================================================
if ($type === 'cover') {
    // ----- ẢNH BÌA -----
    if (empty($doc['AnhBia'])) {
        http_response_code(404);
        die("Không có ảnh bìa");
    }
    $file_path = "../../" . $doc['AnhBia'];
    $is_image  = true;
} else {
    // ----- FILE PDF -----
    if (empty($doc['FileTaiLieu'])) {
        http_response_code(404);
        die("Tài liệu chưa có file đính kèm");
    }
    $file_path = "../../" . $doc['FileTaiLieu'];
    $is_image  = false;
}

if (!file_exists($file_path)) {
    http_response_code(404);
    die("File không tồn tại trên hệ thống");
}

// ============================================================
// 6. LẤY MIME TYPE + WHITELIST
// ============================================================
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file_path);
finfo_close($finfo);

if (!$mime) $mime = 'application/octet-stream';

if ($is_image) {
    // Whitelist cho ảnh
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];
} else {
    // Whitelist cho file
    $allowed_mimes = [
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
    ];
}

if (!isset($allowed_mimes[$mime])) {
    http_response_code(415);
    die("Định dạng không được hỗ trợ");
}

// ============================================================
// 7. GHI LOG (chỉ ghi cho FILE, không ghi cho ẢNH BÌA)
// ============================================================
if (!$is_image && file_exists("../../includes/audit.php")) {
    require_once "../../includes/audit.php";
    $hanh_dong = $is_download ? 'DOWNLOAD' : 'VIEW';
    $mo_ta = $is_download
        ? "Tải tài liệu: {$doc['TenTaiLieu']}"
        : "Xem tài liệu: {$doc['TenTaiLieu']}";
    ghi_log($conn, $hanh_dong, $mo_ta, 'tai_lieu', $doc['MaTL']);
}

// ============================================================
// 8. TRẢ FILE VỀ TRÌNH DUYỆT
// ============================================================
if (ob_get_level()) ob_end_clean();

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($file_path));
header('X-Content-Type-Options: nosniff');

if ($is_image) {
    // Ảnh bìa: cache public 1 giờ
    header('Cache-Control: public, max-age=3600');
    header('Content-Disposition: inline');
} else {
    // File PDF/DOC: cache private
    header('Cache-Control: private, max-age=3600');

    // Đặt tên file hiển thị (không có path)
    $ten_hien_thi = preg_replace('/[^a-zA-Z0-9_\-\s\.]/u', '', $doc['TenTaiLieu']);
    $ten_hien_thi .= '.' . $allowed_mimes[$mime];

    if ($is_download) {
        header('Content-Disposition: attachment; filename="' . $ten_hien_thi . '"');
    } else {
        header('Content-Disposition: inline; filename="' . $ten_hien_thi . '"');
    }
}

readfile($file_path);
exit();