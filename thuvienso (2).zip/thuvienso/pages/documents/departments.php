<?php
session_start();
require_once "../../connect.php";

$base_url     = '/thuvienso/';
$current_page = 'khoa';
$page_title   = "Khoa / Ngành";

// ============================================================
// LẤY DANH SÁCH KHOA / PHÒNG BAN CÓ TÀI LIỆU
// ============================================================
$keyword = trim($_GET['q'] ?? '');

$where  = "WHERE pb.TrangThai = 1";
$params = [];
$types  = "";

if ($keyword !== '') {
    $where .= " AND (pb.TenPhongBan LIKE ? OR pb.TenVietTat LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw;
    $types   .= "ss";
}

$sql = "
    SELECT pb.MaPB, pb.TenPhongBan, pb.TenVietTat, pb.Email, pb.SoDienThoai, pb.MoTa,
           (SELECT COUNT(DISTINCT tltg.MaTL)
            FROM tailieutacgia tltg
            INNER JOIN tai_lieu tl ON tltg.MaTL = tl.MaTL
            INNER JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
            WHERE tg.MaPB = pb.MaPB AND tl.TrangThai = 'Đã duyệt') AS SoTaiLieu,
           (SELECT COUNT(*)
            FROM tac_gia tg
            WHERE tg.MaPB = pb.MaPB AND tg.TrangThai = 1) AS SoTacGia
    FROM phong_ban pb
    $where
    ORDER BY SoTaiLieu DESC, pb.TenPhongBan ASC
";

$stmt = $conn->prepare($sql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$departments = $stmt->get_result();
$total = $departments->num_rows;

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/public.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/documents.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/departments.css">

<main class="dept-wrapper">

    <div class="dept-header">
        <h1>Khoa / Ngành</h1>
        <p>Khám phá tài liệu theo từng khoa, phòng ban trong trường</p>
    </div>

    <!-- Search bar -->
    <form method="GET" class="dept-search">
        <input type="text" name="q" placeholder="Tìm theo tên khoa, viết tắt..." value="<?= htmlspecialchars($keyword) ?>" autofocus>
        <button type="submit">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            Tìm kiếm
        </button>
    </form>

    <!-- Info bar -->
    <div class="dept-info">
        <span>Tìm thấy <b><?= number_format($total) ?></b> khoa / phòng ban</span>
    </div>

    <!-- Grid khoa -->
    <?php if ($departments && $departments->num_rows > 0): ?>
        <div class="dept-grid">
            <?php while ($d = $departments->fetch_assoc()):
                $so_tl  = (int)$d['SoTaiLieu'];
                $so_tg  = (int)$d['SoTacGia'];
            ?>
                <a href="<?= $base_url ?>pages/documents/index.php?ma_pb=<?= urlencode($d['MaPB']) ?>" class="dept-card">
                    <div class="dept-card-top">
                        <div class="dept-icon">
                            <!-- ✅ SVG thay cho <i class="fa-solid fa-building-columns"> -->
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="4" y="2" width="16" height="20" rx="2"/>
                                <path d="M9 22v-4h6v4"/>
                                <path d="M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>
                            </svg>
                        </div>
                        <div class="dept-info-block">
                            <h3 class="dept-name"><?= htmlspecialchars($d['TenPhongBan']) ?></h3>
                            <?php if (!empty($d['TenVietTat'])): ?>
                                <span class="dept-abbr"><?= htmlspecialchars($d['TenVietTat']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!empty($d['Email']) || !empty($d['SoDienThoai'])): ?>
                        <div class="dept-contact">
                            <?php if (!empty($d['Email'])): ?>
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect x="2" y="4" width="20" height="16" rx="2"/>
                                        <polyline points="22,6 12,13 2,6"/>
                                    </svg>
                                    <?= htmlspecialchars($d['Email']) ?>
                                </span>
                            <?php endif; ?>
                            <?php if (!empty($d['SoDienThoai'])): ?>
                                <span>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
                                    </svg>
                                    <?= htmlspecialchars($d['SoDienThoai']) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="dept-stats">
                        <div class="dept-stat">
                            <div class="dept-stat-num"><?= $so_tl ?></div>
                            <div class="dept-stat-lbl">Tài liệu</div>
                        </div>
                        <div class="dept-stat">
                            <div class="dept-stat-num"><?= $so_tg ?></div>
                            <div class="dept-stat-lbl">Tác giả</div>
                        </div>
                    </div>
                </a>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="dept-empty">
            <!-- ✅ SVG thay cho icon empty -->
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:#d1d5db; margin-bottom:18px;">
                <path d="M3 21h18"/>
                <path d="M5 21V7l8-4v18"/>
                <path d="M19 21V11l-6-4"/>
            </svg>
            <h3>Không tìm thấy khoa nào</h3>
            <p>
                <?php if ($keyword): ?>
                    Không có kết quả cho "<?= htmlspecialchars($keyword) ?>"
                <?php else: ?>
                    Chưa có khoa / phòng ban nào
                <?php endif; ?>
            </p>
            <?php if ($keyword): ?>
                <a href="departments.php" class="btn-reset">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="1 4 1 10 7 10"/>
                        <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>
                    </svg>
                    Xem tất cả
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</main>

<?php include "../../includes/footer_public.php"; ?>