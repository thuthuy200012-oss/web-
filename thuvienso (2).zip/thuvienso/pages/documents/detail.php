<?php
session_start();
require_once "../../connect.php";

if (!isset($_SESSION['MaND'])) {
    header("Location: ../auth/login.php");
    exit();
}

$base_url = '/thuvienso/';
$current_page = 'documents';

$id = trim($_GET['id'] ?? '');
if (empty($id)) {
    header("Location: index.php");
    exit();
}

// ============ FIX 1: SELECT tài liệu — Prepared Statement ============
$stmt = $conn->prepare("
    SELECT tl.*, dm.TenDanhMuc
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    WHERE tl.MaTL = ? AND tl.TrangThai = 'Đã duyệt'
");
$stmt->bind_param("s", $id);
$stmt->execute();
$doc = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doc) {
    echo "<h2 style='text-align:center; margin-top:50px; font-family:sans-serif;'>Không tìm thấy tài liệu!</h2>";
    echo "<p style='text-align:center;'><a href='index.php'>← Quay lại danh sách</a></p>";
    exit();
}

// ============ FIX 2: UPDATE lượt xem — Prepared Statement ============
$session_key = 'viewed_tl_' . $id;
if (!isset($_SESSION[$session_key])) {
    $stmt = $conn->prepare("UPDATE tai_lieu SET SoLuotXem = SoLuotXem + 1 WHERE MaTL = ?");
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $stmt->close();

    $_SESSION[$session_key] = time();
}

// ============ FIX 3: INSERT lịch sử đọc — Prepared Statement ============
$ma_nd = $_SESSION['MaND'];
$stmt = $conn->prepare("INSERT INTO lichsudoc (MaND, MaTL, HanhDong) VALUES (?, ?, 'xem')");
$stmt->bind_param("ss", $ma_nd, $id);
$stmt->execute();
$stmt->close();

// ============ FIX 4: SELECT danh sách tác giả — Prepared Statement ============
$stmt = $conn->prepare("
    SELECT tg.HoTen, tltg.VaiTro
    FROM tailieutacgia tltg
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    WHERE tltg.MaTL = ?
");
$stmt->bind_param("s", $id);
$stmt->execute();
$tac_gia_list = $stmt->get_result();
$stmt->close();

// ============ FIX 5: KIỂM TRA YÊU THÍCH — Prepared Statement ============
$stmt = $conn->prepare("SELECT 1 FROM yeuthich WHERE MaND = ? AND MaTL = ? LIMIT 1");
$stmt->bind_param("ss", $ma_nd, $id);
$stmt->execute();
$is_favorite = $stmt->get_result()->num_rows > 0;
$stmt->close();

$page_title = $doc['TenTaiLieu'];
include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">
<link rel="stylesheet" href="<?= $base_url ?>assets/css/documents.css">

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <nav class="breadcrumb-user">
            <a href="<?= $base_url ?>pages/home/index.php">Trang chủ</a>
            <span>›</span>
            <a href="<?= $base_url ?>pages/documents/index.php">Tài liệu</a>
            <span>›</span>
            <strong><?= htmlspecialchars($doc['TenTaiLieu']) ?></strong>
        </nav>

        <div class="detail-wrapper">

            <div class="detail-cover">
                <?php if (!empty($doc['AnhBia']) && file_exists("../../" . $doc['AnhBia'])): ?>
                    <?php /* ✅ FIX 1.7: Ảnh bìa đi qua stream.php (không dùng link trực tiếp) */ ?>
                    <img src="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>&type=cover"
                         alt="<?= htmlspecialchars($doc['TenTaiLieu']) ?>">
                <?php else: ?>
                    <i class="fa-solid fa-file-lines"></i>
                <?php endif; ?>
            </div>

            <div class="detail-info">
                <h1><?= htmlspecialchars($doc['TenTaiLieu']) ?></h1>

                <div class="detail-badges">
                    <span class="badge-type"><?= htmlspecialchars($doc['LoaiTaiLieu'] ?? 'Khác') ?></span>
                    <?php if (!empty($doc['NgonNgu'])): ?>
                        <span class="badge-lang"><?= htmlspecialchars($doc['NgonNgu']) ?></span>
                    <?php endif; ?>
                    <?php if (!empty($doc['NamXuatBan'])): ?>
                        <span class="badge-year"><?= $doc['NamXuatBan'] ?></span>
                    <?php endif; ?>
                </div>

                <div class="detail-meta">
                    <div class="meta-row">
                        <i class="fa-solid fa-folder"></i>
                        <b>Danh mục:</b> <?= htmlspecialchars($doc['TenDanhMuc'] ?? 'Chưa phân loại') ?>
                    </div>
                    <div class="meta-row">
                        <i class="fa-solid fa-user-pen"></i>
                        <b>Tác giả:</b>
                        <?php
                        $tac_gia_arr = [];
                        while ($tg = $tac_gia_list->fetch_assoc()) {
                            $tac_gia_arr[] = $tg['HoTen'] . ($tg['VaiTro'] ? ' (' . $tg['VaiTro'] . ')' : '');
                        }
                        echo htmlspecialchars(implode(', ', $tac_gia_arr) ?: 'Chưa rõ');
                        ?>
                    </div>
                    <?php if (!empty($doc['SoTrang'])): ?>
                        <div class="meta-row">
                            <i class="fa-solid fa-file"></i>
                            <b>Số trang:</b> <?= $doc['SoTrang'] ?>
                        </div>
                    <?php endif; ?>
                    <div class="meta-row">
                        <i class="fa-solid fa-eye"></i>
                        <b>Lượt xem:</b> <?= number_format($doc['SoLuotXem']) ?>
                    </div>
                    <div class="meta-row">
                        <i class="fa-solid fa-download"></i>
                        <b>Lượt tải:</b> <?= number_format($doc['SoLuotTai']) ?>
                    </div>
                    <div class="meta-row">
                        <i class="fa-solid fa-calendar"></i>
                        <b>Ngày đăng:</b> <?= date('d/m/Y', strtotime($doc['NgayDang'])) ?>
                    </div>
                </div>

                <?php if (!empty($doc['TuKhoa'])): ?>
                    <div class="detail-keywords">
                        <b>Từ khóa:</b>
                        <?php foreach (explode(',', $doc['TuKhoa']) as $kw): ?>
                            <span class="keyword-tag"><?= htmlspecialchars(trim($kw)) ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($doc['TomTat'])): ?>
                    <div class="detail-abstract">
                        <h3>Tóm tắt</h3>
                        <p><?= nl2br(htmlspecialchars($doc['TomTat'])) ?></p>
                    </div>
                <?php endif; ?>

                <div class="detail-actions">
                    <?php if (!empty($doc['FileTaiLieu'])): ?>
                        <?php /* ✅ FIX 1.7: Nút "Đọc online" trỏ qua stream.php */ ?>
                        <a href="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>"
                           class="btn-secondary-lg" target="_blank">
                            <i class="fa-solid fa-book-open"></i> Đọc online
                        </a>

                        <?php /* ✅ FIX 1.7: Nút "Tải xuống" đi qua download.php */ ?>
                        <a href="<?= $base_url ?>pages/documents/download.php?id=<?= urlencode($doc['MaTL']) ?>"
                           class="btn-primary-lg">
                            <i class="fa-solid fa-download"></i> Tải xuống
                        </a>
                    <?php endif; ?>

                    <button type="button" class="btn-favorite <?= $is_favorite ? 'active' : '' ?>" onclick="toggleFavorite('<?= htmlspecialchars($doc['MaTL']) ?>')">
                        <i class="fa-<?= $is_favorite ? 'solid' : 'regular' ?> fa-heart"></i>
                        <span><?= $is_favorite ? 'Đã yêu thích' : 'Yêu thích' ?></span>
                    </button>

                    <a href="<?= $base_url ?>pages/citation/index.php?id=<?= urlencode($doc['MaTL']) ?>" class="btn-citation">
                        <i class="fa-solid fa-quote-right"></i> Trích dẫn
                    </a>
                </div>

            </div>
        </div>

    </main>
</div>

<script>
function toggleFavorite(id) {
    fetch('<?= $base_url ?>pages/documents/favorite_action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + encodeURIComponent(id)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message || 'Có lỗi xảy ra');
        }
    })
    .catch(err => {
        alert('Lỗi kết nối: ' + err.message);
    });
}
</script>

<?php include "../../includes/footer_public.php"; ?>