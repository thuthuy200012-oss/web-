<?php
session_start();
require_once "../../connect.php"; 

$base_url = '/thuvienso/';
$current_page = 'lien_he';

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ho_ten = trim($_POST['ho_ten'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $chu_de = trim($_POST['chu_de'] ?? '');
    $noi_dung = trim($_POST['noi_dung'] ?? '');

    if (empty($ho_ten) || empty($email) || empty($noi_dung)) {
        $msg = "Vui lòng điền đầy đủ các trường bắt buộc (*).";
        $msg_type = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $msg = "Địa chỉ email không hợp lệ.";
        $msg_type = "error";
    } else {
        $stmt = $conn->prepare("INSERT INTO lien_he (HoTen, Email, ChuDe, NoiDung) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $ho_ten, $email, $chu_de, $noi_dung);
        
        if ($stmt->execute()) {
            $msg = "Cảm ơn bạn! Tin nhắn của bạn đã được gửi thành công. Chúng tôi sẽ phản hồi sớm nhất có thể.";
            $msg_type = "success";
            $ho_ten = $email = $chu_de = $noi_dung = '';
        } else {
            $msg = "Có lỗi xảy ra, vui lòng thử lại sau.";
            $msg_type = "error";
        }
        $stmt->close();
    }
}

$page_title = "Liên hệ";
include "../../includes/navbar.php"; 
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<style>
    .contact-wrapper {
        max-width: 1200px;
        margin: 40px auto;
        padding: 0 20px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .contact-banner {
        background: linear-gradient(135deg, #064e3b, #15803d);
        color: #fff;
        padding: 40px;
        border-radius: 4px;
        margin-bottom: 40px;
    }
    .contact-banner h1 {
        font-size: 28px;
        font-weight: 700;
        margin: 0 0 10px 0;
    }
    .contact-banner p {
        font-size: 15px;
        margin: 0;
        opacity: 0.9;
    }

    .contact-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 30px;
    }

    .contact-form-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 30px;
    }
    .contact-form-card h3 {
        font-size: 18px;
        color: #1e293b;
        margin-top: 0;
        margin-bottom: 20px;
    }

    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: #334155;
        margin-bottom: 8px;
    }
    .form-group label span {
        color: #dc2626;
    }
    .form-group input, 
    .form-group textarea {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        font-size: 14px;
        outline: none;
        transition: 0.2s;
        box-sizing: border-box;
    }
    .form-group input:focus, 
    .form-group textarea:focus {
        border-color: #16a34a;
        box-shadow: 0 0 0 3px rgba(22, 163, 74, 0.1);
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .btn-submit {
        background: #16a34a;
        color: #fff;
        border: none;
        padding: 12px 24px;
        font-size: 15px;
        font-weight: 600;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.2s;
    }
    .btn-submit:hover {
        background: #15803d;
    }

    .alert {
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 14px;
    }
    .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
    .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

    .contact-info-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        padding: 30px;
        height: fit-content;
    }
    .contact-info-card h3 {
        font-size: 16px;
        color: #1e293b;
        margin-top: 0;
        margin-bottom: 20px;
    }
    .info-item {
        margin-bottom: 15px;
        font-size: 14px;
        color: #475569;
    }
    .info-item b {
        color: #1e293b;
    }

    @media (max-width: 768px) {
        .contact-grid {
            grid-template-columns: 1fr;
        }
        .form-row {
            grid-template-columns: 1fr;
        }
    }
</style>

<main class="contact-wrapper">

    <div class="contact-banner">
        <h1>Liên hệ</h1>
        <p>Mọi thắc mắc xin liên hệ với thư viện qua form bên dưới hoặc thông tin liên lạc.</p>
    </div>

    <div class="contact-grid">
        <div class="contact-form-card">
            <h3>Gửi liên hệ</h3>
            
            <?php if ($msg): ?>
                <div class="alert alert-<?= $msg_type === 'success' ? 'success' : 'error' ?>">
                    <?= $msg ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label>Họ tên <span>*</span></label>
                        <input type="text" name="ho_ten" value="<?= htmlspecialchars($ho_ten ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email <span>*</span></label>
                        <input type="email" name="email" value="<?= htmlspecialchars($email ?? '') ?>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Chủ đề</label>
                    <input type="text" name="chu_de" value="<?= htmlspecialchars($chu_de ?? '') ?>">
                </div>

                <div class="form-group">
                    <label>Nội dung <span>*</span></label>
                    <textarea name="noi_dung" rows="6" required><?= htmlspecialchars($noi_dung ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn-submit">Gửi liên hệ</button>
            </form>
        </div>

        <div class="contact-info-card">
            <h3>Thông tin liên hệ</h3>
        
        </div>
    </div>

</main>

<?php include "../../includes/footer_public.php"; ?>