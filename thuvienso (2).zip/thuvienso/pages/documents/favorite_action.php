<?php
session_start();
require_once "../../connect.php";

header('Content-Type: application/json');

// ============================================================
// 1. KIỂM TRA ĐĂNG NHẬP
// ============================================================
if (!isset($_SESSION['MaND'])) {
    echo json_encode(['success' => false, 'message' => 'Chưa đăng nhập']);
    exit();
}

$ma_nd = $_SESSION['MaND'];

// ============================================================
// 2. ✅ FIX 1.8: LẤY ID DẠNG CHUỖI (KHÔNG ép int)
// ============================================================
$id = trim($_POST['id'] ?? '');

if ($id === '') {
    echo json_encode(['success' => false, 'message' => 'ID không hợp lệ']);
    exit();
}

// ============================================================
// 3. ✅ FIX 1.8: KIỂM TRA TÀI LIỆU TỒN TẠI
// ============================================================
$stmt = $conn->prepare("
    SELECT 1 FROM tai_lieu
    WHERE MaTL = ? AND TrangThai = 'Đã duyệt'
    LIMIT 1
");
$stmt->bind_param("s", $id);
$stmt->execute();
$doc_exists = $stmt->get_result()->num_rows > 0;
$stmt->close();

if (!$doc_exists) {
    echo json_encode(['success' => false, 'message' => 'Tài liệu không tồn tại']);
    exit();
}

// ============================================================
// 4. KIỂM TRA ĐÃ YÊU THÍCH CHƯA
// ============================================================
$stmt = $conn->prepare("
    SELECT 1 FROM yeuthich
    WHERE MaND = ? AND MaTL = ?
    LIMIT 1
");
$stmt->bind_param("ss", $ma_nd, $id);
$stmt->execute();
$exists = $stmt->get_result()->num_rows > 0;
$stmt->close();

// ============================================================
// 5. THÊM hoặc XÓA YÊU THÍCH
// ============================================================
if ($exists) {
    $stmt = $conn->prepare("DELETE FROM yeuthich WHERE MaND = ? AND MaTL = ?");
    $stmt->bind_param("ss", $ma_nd, $id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true, 'action' => 'removed']);
} else {
    $stmt = $conn->prepare("INSERT INTO yeuthich (MaND, MaTL) VALUES (?, ?)");
    $stmt->bind_param("ss", $ma_nd, $id);
    $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => true, 'action' => 'added']);
}