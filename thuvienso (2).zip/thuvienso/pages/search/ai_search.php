<?php

session_start();
require_once "../../connect.php";
require_once "../../includes/config_helper.php";
require_once "../../includes/ai_helper.php";
require_once "../../includes/ai_cache.php";

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['MaND'])) {
    echo json_encode(['success' => false, 'error' => 'Vui lòng đăng nhập.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$ai_enabled = get_config($conn, 'ai_enabled', '0');
if ($ai_enabled !== '1') {
    echo json_encode(['success' => false, 'error' => 'Chức năng tìm kiếm AI đang tắt.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$api_key = get_config($conn, 'ai_api_key', '');
$model   = get_config($conn, 'ai_model', 'gemini-2.0-flash');

if (empty($model) || !preg_match('/^gemini-/', $model)) {
    $model = 'gemini-2.0-flash';
}

if (empty($api_key)) {
    echo json_encode(['success' => false, 'error' => 'Chưa cấu hình API Key.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$query = trim($_GET['q'] ?? $_POST['q'] ?? '');
if (empty($query)) {
    echo json_encode(['success' => false, 'error' => 'Vui lòng nhập câu hỏi tìm kiếm.'], JSON_UNESCAPED_UNICODE);
    exit;
}
if (mb_strlen($query) > 500) {
    echo json_encode(['success' => false, 'error' => 'Câu hỏi quá dài (tối đa 500 ký tự).'], JSON_UNESCAPED_UNICODE);
    exit;
}

$limit = ai_check_rate_limit($_SESSION['MaND'], 20); // 20 câu/ngày/user
if (!$limit['allowed']) {
    echo json_encode([
        'success' => false,
        'error'   => '🤖 Bạn đã dùng hết 20 lượt hỏi AI hôm nay. Vui lòng quay lại vào ngày mai!'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$cache_key = 'search_' . mb_strtolower(trim($query));
$cached = ai_cache_get($cache_key, 86400); // Cache 24h

if ($cached !== null) {
    $cached['from_cache'] = true;
    $cached['remaining']  = $limit['remaining'];
    echo json_encode($cached, JSON_UNESCAPED_UNICODE);
    exit;
}

$result = ai_extract_search_filters($api_key, $model, $query);

if (!$result['success']) {
    if (($result['error'] ?? '') === 'QUOTA_EXCEEDED') {
        $fallback = ai_cache_get($cache_key, 604800);
        if ($fallback) {
            $fallback['from_cache'] = true;
            $fallback['warning']    = 'Kết quả có thể không mới nhất (AI đang nghỉ).';
            echo json_encode($fallback, JSON_UNESCAPED_UNICODE);
            exit;
        }
        echo json_encode([
            'success' => false,
            'error'   => '🤖 Trợ lý AI đang nghỉ ngơi (hết lượt gọi miễn phí hôm nay). Vui lòng thử lại vào ngày mai!'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (($result['error'] ?? '') === 'MODEL_NOT_FOUND') {
        echo json_encode([
            'success' => false,
            'error'   => "⚠️ Model '$model' không khả dụng. Vui lòng liên hệ Admin kiểm tra cấu hình AI."
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'Lỗi AI: ' . $result['error']], JSON_UNESCAPED_UNICODE);
    exit;
}

$filters = $result['filters'];
$where = ["tl.TrangThai = 'Đã duyệt'"];
$params = [];
$types = "";

if (!empty($filters['keyword'])) {
    $where[] = "(tl.TenTaiLieu LIKE ? OR tl.TuKhoa LIKE ? OR tl.TomTat LIKE ?)";
    $kw = "%{$filters['keyword']}%";
    $params[] = $kw; $params[] = $kw; $params[] = $kw;
    $types .= "sss";
}

if (!empty($filters['loai_tai_lieu'])) {
    $where[] = "LOWER(tl.LoaiTaiLieu) = LOWER(?)";
    $params[] = $filters['loai_tai_lieu'];
    $types .= "s";
}

if (!empty($filters['nam_xuat_ban']) && (int)$filters['nam_xuat_ban'] > 0) {
    $where[] = "tl.NamXuatBan = ?";
    $params[] = (int)$filters['nam_xuat_ban'];
    $types .= "i";
}

if (!empty($filters['tac_gia'])) {
    $where[] = "tg.HoTen LIKE ?";
    $params[] = "%{$filters['tac_gia']}%";
    $types .= "s";
}

if (!empty($filters['danh_muc'])) {
    $where[] = "dm.TenDanhMuc LIKE ?";
    $params[] = "%{$filters['danh_muc']}%";
    $types .= "s";
}

if (!empty($filters['nganh'])) {
    $where[] = "ng.TenNganh LIKE ?";
    $params[] = "%{$filters['nganh']}%";
    $types .= "s";
}

$where_sql = implode(' AND ', $where);

$order_by = 'tl.SoLuotXem DESC';
if (!empty($filters['sap_xep'])) {
    if ($filters['sap_xep'] === 'newest') {
        $order_by = 'tl.NgayDang DESC';
    } elseif ($filters['sap_xep'] === 'popular') {
        $order_by = 'tl.SoLuotXem DESC';
    } elseif ($filters['sap_xep'] === 'relevant') {
        $order_by = !empty($filters['keyword']) ? 'tl.NgayDang DESC' : 'tl.SoLuotXem DESC';
    }
}

$sql = "
    SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.NamXuatBan, tl.AnhBia,
           tl.SoLuotXem, tl.SoLuotTai, dm.TenDanhMuc,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    LEFT JOIN nganh ng ON tl.MaNganh = ng.MaNganh
    LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    WHERE $where_sql
    GROUP BY tl.MaTL
    ORDER BY $order_by
    LIMIT 20
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'error' => 'Lỗi SQL: ' . $conn->error], JSON_UNESCAPED_UNICODE);
    exit;
}
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$docs = [];
while ($row = $result->fetch_assoc()) {
    $docs[] = [
        'MaTL'        => $row['MaTL'],
        'TenTaiLieu'  => $row['TenTaiLieu'],
        'LoaiTaiLieu' => $row['LoaiTaiLieu'],
        'NamXuatBan'  => $row['NamXuatBan'],
        'TenTacGia'   => $row['TenTacGia'],
        'TenDanhMuc'  => $row['TenDanhMuc'],
        'SoLuotXem'   => (int)$row['SoLuotXem'],
        'AnhBia'      => $row['AnhBia'],
    ];
}
$stmt->close();
$response = [
    'success'   => true,
    'query'     => $query,
    'filters'   => $filters,
    'total'     => count($docs),
    'docs'      => $docs,
    'remaining' => $limit['remaining'],
];

ai_cache_set($cache_key, $response);

echo json_encode($response, JSON_UNESCAPED_UNICODE);