<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

$base_url     = '/thuvienso/';
$current_page = 'dashboard';
$page_title   = "Khu vực cá nhân";

// ✅ Bắt buộc đăng nhập
if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để vào khu vực cá nhân!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd = $_SESSION['MaND'];

// ============================================================
// STATS CÁ NHÂN
// ============================================================
$my_uploads = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE MaND = ?");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$my_uploads = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

$my_pending = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM tai_lieu WHERE MaND = ? AND TrangThai='Chờ duyệt'");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$my_pending = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

$my_favorites = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM yeuthich WHERE MaND = ?");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$my_favorites = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

$my_history = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lichsudoc WHERE MaND = ?");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$my_history = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

// ============================================================
// THÔNG BÁO (Tài liệu đã duyệt / từ chối)
// ============================================================
$notifications = [];
$stmt = $conn->prepare("
    SELECT MaTL, TenTaiLieu, TrangThai, NgayDang
    FROM tai_lieu
    WHERE MaND = ? AND TrangThai IN ('Đã duyệt', 'Từ chối')
    ORDER BY NgayDang DESC
    LIMIT 10
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $notifications[] = $row;
}
$stmt->close();

$notif_unread = 0;
$stmt = $conn->prepare("
    SELECT COUNT(*) AS c FROM tai_lieu
    WHERE MaND = ? AND TrangThai IN ('Đã duyệt', 'Từ chối')
    AND NgayDang >= DATE_SUB(NOW(), INTERVAL 7 DAY)
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$notif_unread = $stmt->get_result()->fetch_assoc()['c'] ?? 0;
$stmt->close();

// ============================================================
// LĨNH VỰC QUAN TÂM
// ============================================================
$fav_cat_ids = [];
$stmt = $conn->prepare("
    SELECT tl.MaDM
    FROM lichsudoc ls
    LEFT JOIN tai_lieu tl ON ls.MaTL = tl.MaTL
    WHERE ls.MaND = ? AND tl.MaDM IS NOT NULL
    GROUP BY tl.MaDM
    ORDER BY COUNT(*) DESC
    LIMIT 3
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$fav_cats = $stmt->get_result();
while ($fc = $fav_cats->fetch_assoc()) {
    $fav_cat_ids[] = $fc['MaDM'];
}
$stmt->close();

// ============================================================
// ĐỀ XUẤT
// ============================================================
if (!empty($fav_cat_ids)) {
    $placeholders = implode(',', array_fill(0, count($fav_cat_ids), '?'));
    $types = str_repeat('s', count($fav_cat_ids));

    $sql = "
        SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.AnhBia, tl.NamXuatBan,
               dm.TenDanhMuc,
               GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
        FROM tai_lieu tl
        LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
        LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
        LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
        WHERE tl.TrangThai = 'Đã duyệt' AND tl.MaDM IN ($placeholders)
        GROUP BY tl.MaTL
        ORDER BY tl.SoLuotXem DESC
        LIMIT 3
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$fav_cat_ids);
    $stmt->execute();
    $suggested = $stmt->get_result();
    $stmt->close();
} else {
    $suggested = $conn->query("
        SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.AnhBia, tl.NamXuatBan,
               dm.TenDanhMuc,
               GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
        FROM tai_lieu tl
        LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
        LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
        LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
        WHERE tl.TrangThai = 'Đã duyệt'
        GROUP BY tl.MaTL
        ORDER BY tl.NgayDang DESC
        LIMIT 3
    ");
}

// ============================================================
// HOẠT ĐỘNG GẦN ĐÂY
// ============================================================
$stmt = $conn->prepare("
    SELECT ls.HanhDong, ls.ThoiGian, tl.TenTaiLieu, tl.MaTL, tl.LoaiTaiLieu
    FROM lichsudoc ls
    LEFT JOIN tai_lieu tl ON ls.MaTL = tl.MaTL
    WHERE ls.MaND = ?
    ORDER BY ls.ThoiGian DESC
    LIMIT 5
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$activities = $stmt->get_result();
$stmt->close();

// ============================================================
// TOP XEM NHIỀU
// ============================================================
$top_week = $conn->query("
    SELECT tl.MaTL, tl.TenTaiLieu, tl.SoLuotXem, tl.LoaiTaiLieu,
           dm.TenDanhMuc
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    WHERE tl.TrangThai = 'Đã duyệt'
    ORDER BY tl.SoLuotXem DESC
    LIMIT 5
");

// ============================================================
// HÀM TẠO ICON SVG
// ============================================================
if (!function_exists('ud_icon')) {
    function ud_icon(string $name, string $size = '16', string $color = 'currentColor'): string {
        $icons = [
            'cloud-upload' => '<path d="M4 16v1a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-1"/><polyline points="16 12 12 8 8 12"/><line x1="12" y1="8" x2="12" y2="20"/>',
            'clock'        => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
            'heart'        => '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
            'history'      => '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/>',
            'user-pen'     => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/><path d="M18 14l2 2-4 4h-2v-2z"/>',
            'folder'       => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
            'calendar'     => '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
            'arrow-right'  => '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
            'file-lines'   => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
            'eye'          => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
            'download'     => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
            'book-open'    => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
            'inbox'        => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
            'bell'         => '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
            'check'        => '<polyline points="20 6 9 17 4 12"/>',
            'x'            => '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        ];
        $path = $icons[$name] ?? '<circle cx="12" cy="12" r="10"/>';
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="'.$size.'" height="'.$size.'" fill="none" stroke="'.$color.'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;vertical-align:middle;">'.$path.'</svg>';
    }
}

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">


        <!-- ============================================================ -->
        <!-- STATS 4 CON SỐ -->
        <!-- ============================================================ -->
        <div class="ud-stats">
            <a href="<?= $base_url ?>pages/submission/index.php" class="ud-stat-card">
                <div class="ud-stat-icon ud-stat-icon-navy">
                    <?= ud_icon('cloud-upload', '24') ?>
                </div>
                <div class="ud-stat-body">
                    <div class="ud-stat-num"><?= $my_uploads ?></div>
                    <div class="ud-stat-lbl">Tài liệu đã nộp</div>
                </div>
            </a>

            <a href="<?= $base_url ?>pages/submission/index.php?trang_thai=Chờ duyệt" class="ud-stat-card">
                <div class="ud-stat-icon ud-stat-icon-amber">
                    <?= ud_icon('clock', '24') ?>
                </div>
                <div class="ud-stat-body">
                    <div class="ud-stat-num"><?= $my_pending ?></div>
                    <div class="ud-stat-lbl">Đang chờ duyệt</div>
                </div>
            </a>

            <a href="<?= $base_url ?>pages/favorites/index.php" class="ud-stat-card">
                <div class="ud-stat-icon ud-stat-icon-teal">
                    <?= ud_icon('heart', '24') ?>
                </div>
                <div class="ud-stat-body">
                    <div class="ud-stat-num"><?= $my_favorites ?></div>
                    <div class="ud-stat-lbl">Tài liệu yêu thích</div>
                </div>
            </a>

            <a href="<?= $base_url ?>pages/profile/history.php" class="ud-stat-card">
                <div class="ud-stat-icon ud-stat-icon-slate">
                    <?= ud_icon('history', '24') ?>
                </div>
                <div class="ud-stat-body">
                    <div class="ud-stat-num"><?= $my_history ?></div>
                    <div class="ud-stat-lbl">Lượt đọc gần đây</div>
                </div>
            </a>
        </div>

        <!-- ============================================================ -->
        <!-- TÀI LIỆU ĐỀ XUẤT -->
        <!-- ============================================================ -->
        <section class="ud-section">
            <div class="ud-section-head">
                <div>
                    <span class="ud-section-label">DÀNH RIÊNG CHO BẠN</span>
                    <h2>Tài liệu đề xuất</h2>
                    <p>Dựa trên lĩnh vực bạn quan tâm</p>
                </div>
                <a href="<?= $base_url ?>pages/documents/index.php" class="ud-section-link">
                    Khám phá thêm <?= ud_icon('arrow-right', '14') ?>
                </a>
            </div>

            <?php if ($suggested && $suggested->num_rows > 0): ?>
                <div class="ud-suggested-grid">
                    <?php while ($doc = $suggested->fetch_assoc()): ?>
                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= $doc['MaTL'] ?>" class="ud-suggest-card">
                            <div class="ud-suggest-cover">
                                <?php if (!empty($doc['AnhBia'])): ?>
                                    <img src="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>&type=cover"
                                         alt="<?= htmlspecialchars($doc['TenTaiLieu']) ?>"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="ud-suggest-cover-placeholder" style="display:none;">
                                        <?= ud_icon('file-lines', '48', '#86efac') ?>
                                    </div>
                                <?php else: ?>
                                    <div class="ud-suggest-cover-placeholder">
                                        <?= ud_icon('file-lines', '48', '#86efac') ?>
                                    </div>
                                <?php endif; ?>
                                <span class="ud-suggest-type"><?= htmlspecialchars($doc['LoaiTaiLieu'] ?? 'Tài liệu') ?></span>
                            </div>
                            <div class="ud-suggest-body">
                                <h3><?= htmlspecialchars($doc['TenTaiLieu']) ?></h3>
                                <p class="ud-suggest-author">
                                    <?= ud_icon('user-pen', '12', '#16a34a') ?>
                                    <?= htmlspecialchars($doc['TenTacGia'] ?? 'Chưa rõ tác giả') ?>
                                </p>
                                <div class="ud-suggest-meta">
                                    <span><?= ud_icon('folder', '12', '#16a34a') ?> <?= htmlspecialchars($doc['TenDanhMuc'] ?? 'Chưa phân loại') ?></span>
                                    <?php if ($doc['NamXuatBan']): ?>
                                        <span><?= ud_icon('calendar', '12', '#16a34a') ?> <?= $doc['NamXuatBan'] ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="ud-suggest-cta">
                                    Đọc ngay <?= ud_icon('arrow-right', '12', '#16a34a') ?>
                                </div>
                            </div>
                        </a>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="ud-empty">
                    <?= ud_icon('inbox', '48', '#cbd5e1') ?>
                    <h3>Chưa có tài liệu đề xuất</h3>
                    <p>Hãy bắt đầu đọc tài liệu để nhận đề xuất phù hợp với bạn</p>
                </div>
            <?php endif; ?>
        </section>

        <!-- ============================================================ -->
        <!-- HOẠT ĐỘNG + XEM NHIỀU NHẤT -->
        <!-- ============================================================ -->
        <div class="ud-row-2">

            <section class="ud-section">
                <div class="ud-section-head">
                    <div>
                        <span class="ud-section-label">GẦN ĐÂY</span>
                        <h2>Hoạt động của bạn</h2>
                    </div>
                    <a href="<?= $base_url ?>pages/profile/history.php" class="ud-section-link">
                        Tất cả <?= ud_icon('arrow-right', '14') ?>
                    </a>
                </div>

                <?php if ($activities && $activities->num_rows > 0): ?>
                    <div class="ud-activity-list">
                        <?php while ($act = $activities->fetch_assoc()):
                            $icon = 'eye'; $label = 'Xem'; $color = 'navy';
                            if ($act['HanhDong'] === 'tai') { $icon = 'download'; $label = 'Tải'; $color = 'teal'; }
                            elseif ($act['HanhDong'] === 'doc') { $icon = 'book-open'; $label = 'Đọc'; $color = 'amber'; }

                            $time_diff = time() - strtotime($act['ThoiGian']);
                            if ($time_diff < 60) $time_str = 'Vừa xong';
                            elseif ($time_diff < 3600) $time_str = floor($time_diff / 60) . ' phút trước';
                            elseif ($time_diff < 86400) $time_str = floor($time_diff / 3600) . ' giờ trước';
                            elseif ($time_diff < 604800) $time_str = floor($time_diff / 86400) . ' ngày trước';
                            else $time_str = date('d/m/Y', strtotime($act['ThoiGian']));
                        ?>
                            <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= $act['MaTL'] ?>" class="ud-activity-item">
                                <div class="ud-activity-icon ud-activity-<?= $color ?>">
                                    <?= ud_icon($icon, '16') ?>
                                </div>
                                <div class="ud-activity-body">
                                    <div class="ud-activity-action"><?= $label ?> tài liệu</div>
                                    <div class="ud-activity-title"><?= htmlspecialchars($act['TenTaiLieu'] ?? 'Không xác định') ?></div>
                                    <div class="ud-activity-time"><?= $time_str ?></div>
                                </div>
                            </a>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="ud-empty">
                        <?= ud_icon('inbox', '48', '#cbd5e1') ?>
                        <h3>Chưa có hoạt động</h3>
                        <p>Bắt đầu đọc tài liệu để xem lịch sử</p>
                    </div>
                <?php endif; ?>
            </section>

            <section class="ud-section">
                <div class="ud-section-head">
                    <div>
                        <span class="ud-section-label">XU HƯỚNG</span>
                        <h2>Xem nhiều nhất</h2>
                    </div>
                </div>

                <?php if ($top_week && $top_week->num_rows > 0): ?>
                    <div class="ud-top-list">
                        <?php $rank = 1; while ($top = $top_week->fetch_assoc()): ?>
                            <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= $top['MaTL'] ?>" class="ud-top-item">
                                <div class="ud-top-rank ud-rank-<?= $rank ?>"><?= $rank ?></div>
                                <div class="ud-top-body">
                                    <div class="ud-top-title"><?= htmlspecialchars($top['TenTaiLieu']) ?></div>
                                    <div class="ud-top-meta">
                                        <?= htmlspecialchars($top['TenDanhMuc'] ?? 'Chưa phân loại') ?>
                                        · <?= ud_icon('eye', '12', '#16a34a') ?> <?= number_format($top['SoLuotXem']) ?>
                                    </div>
                                </div>
                            </a>
                        <?php $rank++; endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="ud-empty">
                        <?= ud_icon('inbox', '48', '#cbd5e1') ?>
                        <h3>Chưa có dữ liệu</h3>
                    </div>
                <?php endif; ?>
            </section>

        </div>

    </main>
</div>

<!-- SCRIPT TOGGLE THÔNG BÁO -->
<script>
function toggleNotif(e) {
    e.stopPropagation();
    document.getElementById('notifDropdown').classList.toggle('show');
}
document.addEventListener('click', function(e) {
    const dropdown = document.getElementById('notifDropdown');
    const wrapper = document.querySelector('.ud-notif-wrapper');
    if (dropdown && wrapper && !wrapper.contains(e.target)) {
        dropdown.classList.remove('show');
    }
});
</script>

<?php include "../../includes/footer_public.php"; ?>