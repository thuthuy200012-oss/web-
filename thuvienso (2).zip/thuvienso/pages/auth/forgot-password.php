<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/mailer.php";

$thongbao = "";
$is_success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"] ?? "");

    if (empty($email)) {
        $thongbao = "Vui lòng nhập Email!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $thongbao = "Email không hợp lệ!";
    } else {
        $stmt_check = $conn->prepare("SELECT MaND, HoTen FROM nguoidung WHERE Email = ? AND TrangThai = 1");
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();

            // Tạo token ngẫu nhiên 64 ký tự
            $token  = bin2hex(random_bytes(32));
            $hetHan = date('Y-m-d H:i:s', time() + 15 * 60);
            $ip     = $_SERVER['REMOTE_ADDR'] ?? null;

            $conn->query("DELETE FROM PasswordResets WHERE Email = '$email' AND DaSuDung = 0");

            $stmt_token = $conn->prepare("INSERT INTO PasswordResets (Email, Token, HetHan, IP) VALUES (?, ?, ?, ?)");
            $stmt_token->bind_param("ssss", $email, $token, $hetHan, $ip);

            if ($stmt_token->execute()) {
                $gui_ok = guiMailResetPassword($email, $user['HoTen'], $token);

                if ($gui_ok) {
                    $is_success = true;
                    $thongbao = "Đã gửi email đặt lại mật khẩu tới <b>" . htmlspecialchars($email) . "</b>.<br>Vui lòng kiểm tra hộp thư (kể cả Spam) và click link trong vòng <b>15 phút</b>.";
                } else {
                    $thongbao = "Không thể gửi email. Vui lòng thử lại sau!";
                }
            } else {
                $thongbao = "Lỗi hệ thống. Vui lòng thử lại sau!";
            }
            $stmt_token->close();
        } else {
            $is_success = true;
            $thongbao = "Nếu email <b>" . htmlspecialchars($email) . "</b> tồn tại, chúng tôi đã gửi link đặt lại mật khẩu.<br>Vui lòng kiểm tra hộp thư.";
        }
        $stmt_check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quên mật khẩu — Thư viện số</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../../assets/css/auth.css">
</head>
<body>

<div class="auth-wrapper">

    <div class="auth-left">
        <div class="auth-left-content">
            <a href="../../index.php" class="brand">
                <i class="fa-solid fa-book-open-reader"></i>
                <h1>THƯ VIỆN SỐ</h1>
            </a>
            <p class="brand-subtitle">Khôi phục quyền truy cập vào tài khoản thư viện của bạn.</p>

            <ul class="feature-list">
                <li><i class="fa-solid fa-shield-halved"></i> Bảo mật bằng token 64 ký tự</li>
                <li><i class="fa-solid fa-envelope"></i> Link gửi qua email đã đăng ký</li>
                <li><i class="fa-solid fa-clock"></i> Link có hiệu lực 15 phút</li>
                <li><i class="fa-solid fa-lock"></i> Chỉ dùng được 1 lần</li>
            </ul>
        </div>
        <div class="auth-left-footer">
            © <?= date('Y') ?> Thư viện số — Đại học Phan Thiết
        </div>
    </div>

    <div class="auth-right">
        <div class="auth-form-container">

            <div class="auth-header">
                <h2>Quên mật khẩu</h2>
                <p>Nhập email để nhận link đặt lại mật khẩu</p>
            </div>

            <?php if ($thongbao != ""): ?>
                <div class="alert <?= $is_success ? 'alert-success' : 'alert-danger' ?>">
                    <i class="fa-solid <?= $is_success ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                    <span><?= $thongbao ?></span>
                </div>
            <?php endif; ?>

            <?php if (!$is_success): ?>
                <form method="POST">
                    <div class="form-group">
                        <label for="email">
                            <i class="fa-solid fa-envelope"></i> Email tài khoản
                        </label>
                        <input type="email" id="email" name="email"
                               value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                               placeholder="Nhập email đã đăng ký" required autofocus>
                        <div class="form-hint" style="font-size:12px; color:#94a3b8; margin-top:6px;">
                            💡 Link đặt lại mật khẩu sẽ được gửi tới email này
                        </div>
                    </div>

                    <button type="submit" class="btn-login">
                        <i class="fa-solid fa-paper-plane"></i> Gửi link đặt lại
                    </button>
                </form>
            <?php endif; ?>

            <div class="auth-divider">
                <span>hoặc</span>
            </div>

            <div class="auth-footer">
                Nhớ mật khẩu rồi?
                <a href="login.php">Đăng nhập ngay</a>
            </div>

        </div>
    </div>

</div>

</body>
</html>