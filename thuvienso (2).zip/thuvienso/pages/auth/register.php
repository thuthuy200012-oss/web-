<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/generate_id.php";   

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

if (isset($_SESSION['MaND'])) {
    header('Location: ../../index.php');
    exit();
}

$error = '';
$hoten_input = '';
$email_input = '';
$sdt_input   = '';
$maso_input  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $error = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
    } else {

        $hoten    = trim($_POST['hoten'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $sdt      = trim($_POST['sdt'] ?? '');
        $maso     = trim($_POST['maso'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        $vaitro = 'SV';

        $hoten_input = $hoten;
        $email_input = $email;
        $sdt_input   = $sdt;
        $maso_input  = $maso;

        if (empty($hoten) || empty($email) || empty($password) || empty($confirm)) {
            $error = "Vui lòng nhập đầy đủ thông tin bắt buộc!";
        }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Email không hợp lệ!";
        }
        elseif (!preg_match('/^[0-9]{10,11}$/', $sdt) && !empty($sdt)) {
            $error = "Số điện thoại phải là 10-11 chữ số!";
        }
        elseif (strlen($password) < 6) {
            $error = "Mật khẩu phải có ít nhất 6 ký tự!";
        }
        elseif ($password !== $confirm) {
            $error = "Mật khẩu xác nhận không khớp!";
        }
        else {
            $check = $conn->prepare("SELECT MaND FROM nguoidung WHERE Email = ? LIMIT 1");
            $check->bind_param("s", $email);
            $check->execute();
            $res = $check->get_result();

            if ($res->num_rows > 0) {
                $error = "Email này đã được đăng ký. Vui lòng dùng email khác!";
            } else {
    
                try {
                    $maND = generate_unique_id($conn, 'nguoidung', 'MaND', 'ND');
                } catch (RuntimeException $e) {
                    error_log("register.php generate_id error: " . $e->getMessage());
                    $maND = null;
                    $error = "Hệ thống đang bận, vui lòng thử lại sau!";
                }

                if ($maND !== null) {
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    $stmt = $conn->prepare("
                        INSERT INTO nguoidung 
                        (MaND, HoTen, Email, MatKhau, MaVaiTro, MaSo, SoDienThoai, TrangThai) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                    ");
                    $stmt->bind_param("sssssss", $maND, $hoten, $email, $hash, $vaitro, $maso, $sdt);

                    if ($stmt->execute()) {

                        ghi_log_guest(
                            $conn,
                            $maND,
                            $hoten,
                            'REGISTER',
                            "Đăng ký tài khoản mới: $email"
                        );

                        $_SESSION['flash_msg'] = "Đăng ký thành công! Vui lòng đăng nhập để tiếp tục.";
                        header('Location: login.php');
                        exit();
                    } else {
                        // ✅ FIX 2.1: Không lộ SQL
                        error_log("register.php SQL Error: " . $conn->error . " | Email: $email");
                        $error = "Đã xảy ra lỗi, vui lòng thử lại sau!";
                    }
                    $stmt->close();
                }
            }
            $check->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký — Thư viện số</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../../assets/css/auth.css">
    <style>
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .form-hint {
            font-size: 12px;
            color: var(--gray-500);
            margin-top: 4px;
            font-style: italic;
        }
        .auth-form-container {
            max-width: 480px;
        }
        .auth-header h2 {
            font-size: 26px;
        }
        .btn-login {
            margin-top: 4px;
        }
        .role-fixed-box {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            background: linear-gradient(135deg, #eff6ff, #dbeafe);
            border: 2px dashed #93c5fd;
            border-radius: 10px;
            margin-top: 6px;
        }
        .role-fixed-box .role-icon {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: #2563eb;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }
        .role-fixed-box .role-text b {
            display: block;
            color: #1d4ed8;
            font-size: 15px;
            margin-bottom: 2px;
        }
        .role-fixed-box .role-text small {
            color: #64748b;
            font-size: 12px;
            line-height: 1.4;
        }
        @media (max-width: 600px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="auth-wrapper">
    <div class="auth-left">
        <div class="auth-left-content">
            <div class="brand">
                <i class="fa-solid fa-book-open-reader"></i>
                <h1>THƯ VIỆN SỐ</h1>
            </div>
            <p class="brand-subtitle">Hệ thống quản lý và khai thác tài liệu nội sinh</p>

            <ul class="feature-list">
                <li><i class="fa-solid fa-circle-check"></i> Đăng ký miễn phí, dễ dàng</li>
                <li><i class="fa-solid fa-circle-check"></i> Tra cứu hàng nghìn tài liệu</li>
                <li><i class="fa-solid fa-circle-check"></i> Đọc trực tuyến mọi lúc, mọi nơi</li>
                <li><i class="fa-solid fa-circle-check"></i> Trích dẫn tự động APA / IEEE</li>
            </ul>
        </div>
        <div class="auth-left-footer">
            © <?= date('Y') ?> Thư viện số — Đại học Phan Thiết
        </div>
    </div>
    <div class="auth-right">
        <div class="auth-form-container">

            <div class="auth-header">
                <h2>Tạo tài khoản mới</h2>
                <p>Đăng ký để bắt đầu sử dụng thư viện số</p>
            </div>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="" id="registerForm" autocomplete="off">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">

                <div class="form-group">
                    <label for="hoten">
                        <i class="fa-solid fa-user"></i> Họ và tên <span style="color:red">*</span>
                    </label>
                    <input type="text"
                           id="hoten"
                           name="hoten"
                           placeholder="Nguyễn Văn A"
                           value="<?= htmlspecialchars($hoten_input) ?>"
                           required
                           autofocus>
                </div>
                <div class="form-group">
                    <label for="email">
                        <i class="fa-solid fa-envelope"></i> Email <span style="color:red">*</span>
                    </label>
                    <input type="email"
                           id="email"
                           name="email"
                           placeholder="example@thuvienso.edu.vn"
                           value="<?= htmlspecialchars($email_input) ?>"
                           required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="maso">
                            <i class="fa-solid fa-id-card"></i> Mã số
                        </label>
                        <input type="text"
                               id="maso"
                               name="maso"
                               placeholder="SV001..."
                               value="<?= htmlspecialchars($maso_input) ?>">
                    </div>

                    <div class="form-group">
                        <label for="sdt">
                            <i class="fa-solid fa-phone"></i> SĐT
                        </label>
                        <input type="tel"
                               id="sdt"
                               name="sdt"
                               placeholder="0912345678"
                               value="<?= htmlspecialchars($sdt_input) ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label>
                        <i class="fa-solid fa-user-tag"></i> Vai trò
                    </label>
                    <div class="role-fixed-box">
                        <div class="role-icon">
                            <i class="fa-solid fa-graduation-cap"></i>
                        </div>
                        <div class="role-text">
                            <b>Sinh viên</b>
                            <small>Tài khoản Giảng viên do Quản trị viên cấp sau khi xác minh.</small>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">
                        <i class="fa-solid fa-lock"></i> Mật khẩu <span style="color:red">*</span>
                    </label>
                    <div class="password-wrapper">
                        <input type="password"
                               id="password"
                               name="password"
                               placeholder="Ít nhất 6 ký tự..."
                               required
                               minlength="6">
                        <button type="button" class="toggle-password" onclick="togglePw('password', 'eye1')">
                            <i class="fa-solid fa-eye" id="eye1"></i>
                        </button>
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">
                        <i class="fa-solid fa-lock"></i> Xác nhận mật khẩu <span style="color:red">*</span>
                    </label>
                    <div class="password-wrapper">
                        <input type="password"
                               id="confirm_password"
                               name="confirm_password"
                               placeholder="Nhập lại mật khẩu..."
                               required>
                        <button type="button" class="toggle-password" onclick="togglePw('confirm_password', 'eye2')">
                            <i class="fa-solid fa-eye" id="eye2"></i>
                        </button>
                    </div>
                </div>
                <div class="form-options" style="justify-content:flex-start;">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" id="terms" required>
                        <span>Tôi đồng ý với <a href="#" style="color:var(--primary);">Điều khoản sử dụng</a></span>
                    </label>
                </div>
                <button type="submit" class="btn-login">
                    <i class="fa-solid fa-user-plus"></i>
                    Đăng ký
                </button>
            </form>

            <div class="auth-divider">
                <span>đã có tài khoản?</span>
            </div>
            <div class="auth-footer">
                <a href="login.php">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Đăng nhập ngay
                </a>
            </div>

        </div>
    </div>

</div>

<script>
function togglePw(inputId, iconId) {
    const pw = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        pw.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

document.getElementById('registerForm').addEventListener('submit', function(e) {
    const hoten   = document.getElementById('hoten').value.trim();
    const email   = document.getElementById('email').value.trim();
    const pw      = document.getElementById('password').value;
    const confirm = document.getElementById('confirm_password').value;

    if (!hoten || !email || !pw || !confirm) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Thiếu thông tin',
            text: 'Vui lòng nhập đầy đủ các trường bắt buộc!',
            confirmButtonColor: '#2563eb'
        });
        return;
    }

    if (pw.length < 6) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Mật khẩu quá ngắn',
            text: 'Mật khẩu phải có ít nhất 6 ký tự!',
            confirmButtonColor: '#2563eb'
        });
        return;
    }

    if (pw !== confirm) {
        e.preventDefault();
        Swal.fire({
            icon: 'error',
            title: 'Mật khẩu không khớp',
            text: 'Vui lòng nhập lại mật khẩu xác nhận cho chính xác!',
            confirmButtonColor: '#2563eb'
        });
        return;
    }

    const btn = this.querySelector('.btn-login');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang đăng ký...';
    btn.disabled = true;
});
</script>
</body>
</html>