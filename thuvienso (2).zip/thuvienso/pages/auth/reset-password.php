<?php
session_start();
require_once "../../connect.php";

$thongbao = "";
$is_success = false;
$token_hop_le = false;
$email_reset = "";

$token = trim($_GET['token'] ?? '');

if (!empty($token)) {
    $stmt = $conn->prepare("
        SELECT * FROM PasswordResets 
        WHERE Token = ? AND DaSuDung = 0 AND HetHan > NOW()
        LIMIT 1
    ");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $email_reset = $row['Email'];
        $token_hop_le = true;
    } else {
        $thongbao = "Link đặt lại mật khẩu không hợp lệ hoặc đã hết hạn!";
    }
    $stmt->close();
} else {
    $thongbao = "Không tìm thấy token trong URL!";
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && $token_hop_le) {
    $matkhaumoi = $_POST["matkhaumoi"] ?? "";
    $xacnhan    = $_POST["xacnhan"] ?? "";

    if (empty($matkhaumoi)) {
        $thongbao = "Vui lòng nhập mật khẩu mới!";
    } elseif (strlen($matkhaumoi) < 6) {
        $thongbao = "Mật khẩu phải có ít nhất 6 ký tự!";
    } elseif ($matkhaumoi !== $xacnhan) {
        $thongbao = "Mật khẩu xác nhận không khớp!";
    } else {
        $hash = password_hash($matkhaumoi, PASSWORD_DEFAULT);

        $stmt_up = $conn->prepare("UPDATE nguoidung SET MatKhau = ? WHERE Email = ?");
        $stmt_up->bind_param("ss", $hash, $email_reset);

        if ($stmt_up->execute()) {
            $stmt_mark = $conn->prepare("UPDATE PasswordResets SET DaSuDung = 1 WHERE Token = ?");
            $stmt_mark->bind_param("s", $token);
            $stmt_mark->execute();
            $stmt_mark->close();

            $is_success = true;
            $token_hop_le = false;
            $thongbao = "Đổi mật khẩu thành công! Bạn có thể đăng nhập bằng mật khẩu mới.";
        } else {
            $thongbao = "Đã xảy ra lỗi. Vui lòng thử lại!";
        }
        $stmt_up->close();
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt lại mật khẩu — Thư viện số</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="../../assets/css/auth.css">
</head>
<body>

<div class="auth-wrapper">

    <div class="auth-left">
        <div class="auth-left-content">
            <a href="../../index.php" class="brand">
                <i class="fa-solid fa-book-open-reader"></i>
                <h1>THƯ VIỆN SỐ</h1>
            </a>
            <p class="brand-subtitle">Đặt lại mật khẩu cho tài khoản thư viện của bạn.</p>

            <ul class="feature-list">
                <li><i class="fa-solid fa-shield-halved"></i> Token bảo mật 64 ký tự</li>
                <li><i class="fa-solid fa-clock"></i> Chỉ dùng được 1 lần</li>
                <li><i class="fa-solid fa-lock"></i> Yêu cầu mật khẩu ≥ 6 ký tự</li>
                <li><i class="fa-solid fa-circle-check"></i> Đổi xong có thể đăng nhập ngay</li>
            </ul>
        </div>
        <div class="auth-left-footer">
            © <?= date('Y') ?> Thư viện số — Đại học Phan Thiết
        </div>
    </div>

    <div class="auth-right">
        <div class="auth-form-container">

            <div class="auth-header">
                <h2>Đặt lại mật khẩu</h2>
                <p>Nhập mật khẩu mới cho tài khoản của bạn</p>
            </div>

            <?php if ($thongbao != ""): ?>
                <div class="alert <?= $is_success ? 'alert-success' : 'alert-danger' ?>">
                    <i class="fa-solid <?= $is_success ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                    <span><?= $thongbao ?></span>
                </div>
            <?php endif; ?>

            <?php if ($token_hop_le): ?>
                <div class="form-group" style="margin-bottom:16px;">
                    <label><i class="fa-solid fa-envelope"></i> Email</label>
                    <input type="text" value="<?= htmlspecialchars($email_reset) ?>" disabled style="background:#f1f5f9; color:#64748b;">
                </div>

                <form method="POST">
                    <div class="form-group">
                        <label for="matkhaumoi">
                            <i class="fa-solid fa-lock"></i> Mật khẩu mới
                        </label>
                        <div class="password-wrapper">
                            <input type="password" id="matkhaumoi" name="matkhaumoi"
                                   placeholder="Ít nhất 6 ký tự" required minlength="6" autofocus>
                            <button type="button" class="toggle-password" onclick="togglePassword('matkhaumoi', this)">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="xacnhan">
                            <i class="fa-solid fa-lock"></i> Xác nhận mật khẩu
                        </label>
                        <div class="password-wrapper">
                            <input type="password" id="xacnhan" name="xacnhan"
                                   placeholder="Nhập lại mật khẩu mới" required minlength="6">
                            <button type="button" class="toggle-password" onclick="togglePassword('xacnhan', this)">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="btn-login">
                        <i class="fa-solid fa-key"></i> Đặt lại mật khẩu
                    </button>
                </form>
            <?php elseif (!$is_success): ?>
                <div style="text-align:center; padding:20px;">
                    <a href="forgot-password.php" class="btn-login" style="display:inline-flex; text-decoration:none;">
                        <i class="fa-solid fa-rotate-left"></i> Yêu cầu link mới
                    </a>
                </div>
            <?php else: ?>
                <div style="text-align:center; padding:20px;">
                    <a href="login.php" class="btn-login" style="display:inline-flex; text-decoration:none;">
                        <i class="fa-solid fa-right-to-bracket"></i> Đăng nhập ngay
                    </a>
                </div>
            <?php endif; ?>

            <div class="auth-divider">
                <span>hoặc</span>
            </div>

            <div class="auth-footer">
                <a href="login.php">← Quay lại đăng nhập</a>
            </div>

        </div>
    </div>

</div>

<script>
function togglePassword(id, btn) {
    const pw = document.getElementById(id);
    const icon = btn.querySelector('i');
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        pw.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}
</script>

</body>
</html>