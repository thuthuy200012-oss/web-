<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/audit.php";
if (isset($_SESSION['MaND'])) {
    header('Location: ../home/index.php');
    exit();
}

$error = '';
$success = '';
$email_input = $_COOKIE['remember_email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    $email_input = $email;

    if (empty($email) || empty($password)) {
        $error = "Vui lòng nhập đầy đủ Email và Mật khẩu!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email không hợp lệ!";
    } else {
        $stmt = $conn->prepare("
            SELECT nd.*, vt.TenVaiTro
            FROM nguoidung nd
            LEFT JOIN vaitro vt ON nd.MaVaiTro = vt.MaVaiTro
            WHERE nd.Email = ?
            LIMIT 1
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if ((int)$user['TrangThai'] !== 1) {
                $error = "Tài khoản của bạn đã bị khóa. Vui lòng liên hệ thủ thư!";
            }
            elseif (password_verify($password, $user['MatKhau'])) {
                session_regenerate_id(true);

                $_SESSION['MaND']          = $user['MaND'];
                $_SESSION['HoTen']         = $user['HoTen'];
                $_SESSION['Email']         = $user['Email'];
                $_SESSION['MaVaiTro']      = $user['MaVaiTro'];
                $_SESSION['TenVaiTro']     = $user['TenVaiTro'];
                $_SESSION['MaPB']          = $user['MaPB'];
                $_SESSION['login_time']    = time();
                $_SESSION['last_activity'] = time();
                $login_note = ($user['MaVaiTro'] === 'ADMIN' || $user['MaVaiTro'] === 'THUTHU')
                    ? 'Đăng nhập trang quản trị'
                    : 'Đăng nhập hệ thống';
                ghi_log($conn, 'LOGIN', $login_note);

               
                $stmt_update = $conn->prepare("UPDATE nguoidung SET LastLogin = NOW() WHERE MaND = ?");
                $stmt_update->bind_param("s", $user['MaND']);
                $stmt_update->execute();
                $stmt_update->close();
                if ($remember) {
                 
                    $stmt_del = $conn->prepare("DELETE FROM remember_tokens WHERE MaND = ?");
                    $stmt_del->bind_param("s", $user['MaND']);
                    $stmt_del->execute();
                    $stmt_del->close();

                    $rawToken = bin2hex(random_bytes(32));              
                    $hash     = hash('sha256', $rawToken);
                    $expires  = time() + 60 * 60 * 24 * 30;            
                    $ip       = $_SERVER['REMOTE_ADDR'] ?? '';
                    $ua       = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

                    $stmt_tok = $conn->prepare("
                        INSERT INTO remember_tokens (MaND, TokenHash, HetHan, IP, UserAgent)
                        VALUES (?, ?, FROM_UNIXTIME(?), ?, ?)
                    ");
                    $stmt_tok->bind_param("ssiss", $user['MaND'], $hash, $expires, $ip, $ua);
                    $stmt_tok->execute();
                    $stmt_tok->close();

                    setcookie('remember_token', $rawToken, [
                        'expires'  => $expires,
                        'path'     => '/',
                        'httponly' => true,
                        'secure'   => !empty($_SERVER['HTTPS']),
                        'samesite' => 'Lax',
                    ]);

                    setcookie('remember_email', $email, [
                        'expires'  => $expires,
                        'path'     => '/',
                        'httponly' => true,
                        'samesite' => 'Strict',
                    ]);
                } else {
                    $stmt_del = $conn->prepare("DELETE FROM remember_tokens WHERE MaND = ?");
                    $stmt_del->bind_param("s", $user['MaND']);
                    $stmt_del->execute();
                    $stmt_del->close();

                    setcookie('remember_token', '', time() - 3600, '/');
                    setcookie('remember_email', '', time() - 3600, '/');
                }
                header('Location: ../home/index.php');
                exit();
            }
            else {
                $error = "Email hoặc mật khẩu không đúng.";
            }
        } else {
            $error = "Email hoặc mật khẩu không đúng.";
        }
        $stmt->close();
    }
}

if (isset($_SESSION['flash_msg'])) {
    $success = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập — Thư viện số</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../../assets/css/auth.css">
</head>
<body>

<div class="auth-wrapper">

    <div class="auth-left">
        <div class="auth-left-content">
            <div class="brand">
                <i class="fa-solid fa-book-open-reader"></i>
                <h1>THƯ VIỆN SỐ</h1>
            </div>
            <p class="brand-subtitle">Hệ thống quản lý và khai thác tài liệu nội sinh</p>

            <ul class="feature-list">
                <li><i class="fa-solid fa-circle-check"></i> Tra cứu hàng nghìn tài liệu</li>
                <li><i class="fa-solid fa-circle-check"></i> Đọc trực tuyến mọi lúc, mọi nơi</li>
                <li><i class="fa-solid fa-circle-check"></i> Trích dẫn tự động APA / IEEE</li>
                <li><i class="fa-solid fa-circle-check"></i> Lưu tài liệu yêu thích</li>
            </ul>
        </div>
        <div class="auth-left-footer">
            © <?= date('Y') ?> Thư viện số — Đại học Phan Thiết
        </div>
    </div>

    <div class="auth-right">
        <div class="auth-form-container">

            <div class="auth-header">
                <h2>Đăng nhập</h2>
                <p>Chào mừng bạn quay trở lại!</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fa-solid fa-circle-check"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="loginForm" autocomplete="off">

                <div class="form-group">
                    <label for="email">
                        <i class="fa-solid fa-envelope"></i> Email
                    </label>
                    <input type="email"
                           id="email"
                           name="email"
                           placeholder="example@thuvienso.edu.vn"
                           value="<?= htmlspecialchars($email_input) ?>"
                           required
                           autofocus>
                </div>

                <div class="form-group">
                    <label for="password">
                        <i class="fa-solid fa-lock"></i> Mật khẩu
                    </label>
                    <div class="password-wrapper">
                        <input type="password"
                               id="password"
                               name="password"
                               placeholder="Nhập mật khẩu..."
                               required>
                        <button type="button" class="toggle-password" onclick="togglePassword()">
                            <i class="fa-solid fa-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <div class="form-options">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" name="remember" id="remember" <?= !empty($email_input) ? 'checked' : '' ?>>
                        <span>Ghi nhớ đăng nhập</span>
                    </label>
                    <a href="forgot-password.php" class="forgot-link">
                        Quên mật khẩu?
                    </a>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Đăng nhập
                </button>
            </form>

            <div class="auth-divider">
                <span>hoặc</span>
            </div>

            <div class="auth-footer">
                Chưa có tài khoản?
                <a href="register.php">Đăng ký ngay</a>
            </div>

        </div>
    </div>

</div>

<script>
function togglePassword() {
    const pw = document.getElementById('password');
    const icon = document.getElementById('eyeIcon');
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        pw.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

document.getElementById('loginForm').addEventListener('submit', function(e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    if (!email || !password) {
        e.preventDefault();
        Swal.fire({
            icon: 'warning',
            title: 'Thiếu thông tin',
            text: 'Vui lòng nhập đầy đủ Email và Mật khẩu!',
            confirmButtonColor: '#2563eb'
        });
        return;
    }

    const btn = this.querySelector('.btn-login');
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang đăng nhập...';
    btn.disabled = true;
});
</script>

</body>
</html>