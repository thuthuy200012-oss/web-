<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/audit.php";
if (isset($_SESSION['MaND'])) {
    ghi_log($conn, 'LOGOUT', 'Đăng xuất hệ thống');
}

if (!empty($_COOKIE['remember_token'])) {
    $hash = hash('sha256', $_COOKIE['remember_token']);

    $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE TokenHash = ?");
    $stmt->bind_param("s", $hash);
    $stmt->execute();
    $stmt->close();
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();
setcookie('remember_token', '', time() - 3600, '/');
setcookie('remember_email', '', time() - 3600, '/');
setcookie('remember_user',  '', time() - 3600, '/');

header('Location: login.php');
exit();