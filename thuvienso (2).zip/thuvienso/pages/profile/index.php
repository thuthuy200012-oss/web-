<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để xem hồ sơ!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd        = $_SESSION['MaND'];
$base_url     = '/thuvienso/';
$current_page = 'profile';
$page_title   = "Hồ sơ cá nhân";

$msg = '';
$msg_type = '';

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ============================================================
// XỬ LÝ CẬP NHẬT THÔNG TIN
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'update_info') {
            $ho_ten = trim($_POST['ho_ten'] ?? '');
            $sdt    = trim($_POST['sdt'] ?? '');
            $ma_so  = trim($_POST['ma_so'] ?? '');

            if (empty($ho_ten)) {
                $msg = "Vui lòng nhập họ tên!";
                $msg_type = 'danger';
            } elseif (!empty($sdt) && !preg_match('/^[0-9]{10,11}$/', $sdt)) {
                $msg = "Số điện thoại phải là 10-11 chữ số!";
                $msg_type = 'danger';
            } else {
                $stmt = $conn->prepare("UPDATE nguoidung SET HoTen = ?, SoDienThoai = ?, MaSo = ? WHERE MaND = ?");
                $stmt->bind_param("ssss", $ho_ten, $sdt, $ma_so, $ma_nd);
                if ($stmt->execute()) {
                    $_SESSION['HoTen'] = $ho_ten;
                    $msg = "Đã cập nhật thông tin cá nhân!";
                    $msg_type = 'success';
                } else {
                    error_log("profile update error: " . $conn->error);
                    $msg = "Có lỗi xảy ra, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        } elseif ($action === 'change_password') {
            $old_pass = $_POST['old_pass'] ?? '';
            $new_pass = $_POST['new_pass'] ?? '';
            $confirm  = $_POST['confirm_pass'] ?? '';

            // Lấy mật khẩu hiện tại
            $stmt = $conn->prepare("SELECT MatKhau FROM nguoidung WHERE MaND = ?");
            $stmt->bind_param("s", $ma_nd);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!password_verify($old_pass, $row['MatKhau'])) {
                $msg = "Mật khẩu hiện tại không đúng!";
                $msg_type = 'danger';
            } elseif (strlen($new_pass) < 6) {
                $msg = "Mật khẩu mới phải có ít nhất 6 ký tự!";
                $msg_type = 'danger';
            } elseif ($new_pass !== $confirm) {
                $msg = "Mật khẩu xác nhận không khớp!";
                $msg_type = 'danger';
            } else {
                $hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE nguoidung SET MatKhau = ? WHERE MaND = ?");
                $stmt->bind_param("ss", $hash, $ma_nd);
                if ($stmt->execute()) {
                    $msg = "Đã đổi mật khẩu thành công!";
                    $msg_type = 'success';
                } else {
                    error_log("profile changepass error: " . $conn->error);
                    $msg = "Có lỗi xảy ra, vui lòng thử lại!";
                    $msg_type = 'danger';
                }
                $stmt->close();
            }
        }
    }
}

// ============================================================
// LẤY THÔNG TIN USER
// ============================================================
$stmt = $conn->prepare("
    SELECT nd.*, vt.TenVaiTro, pb.TenPhongBan
    FROM nguoidung nd
    LEFT JOIN vaitro vt ON nd.MaVaiTro = vt.MaVaiTro
    LEFT JOIN phong_ban pb ON nd.MaPB = pb.MaPB
    WHERE nd.MaND = ?
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<style>
    .pf-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 28px;
        margin-bottom: 24px;
    }
    .pf-card h2 {
        font-size: 16px;
        font-weight: 800;
        color: #0c1e3e;
        margin: 0 0 20px;
        padding-bottom: 14px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .pf-card h2 i {
        color: #0d9488;
    }
    .pf-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        margin-bottom: 18px;
    }
    .pf-field label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: #64748b;
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .pf-field input, .pf-field select {
        width: 100%;
        padding: 11px 14px;
        border: 1.5px solid #cbd5e1;
        border-radius: 9px;
        font-size: 14px;
        box-sizing: border-box;
        transition: border-color 0.2s;
        font-family: inherit;
    }
    .pf-field input:focus {
        outline: none;
        border-color: #0d9488;
    }
    .pf-field input:disabled {
        background: #f8fafc;
        color: #64748b;
        cursor: not-allowed;
    }
    .pf-btn {
        padding: 12px 24px;
        background: linear-gradient(135deg, #0c1e3e, #1e3a5f);
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.2s;
        font-family: inherit;
    }
    .pf-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(12, 30, 62, 0.25);
    }
    .pf-msg {
        padding: 12px 20px;
        border-radius: 10px;
        font-size: 13.5px;
        font-weight: 600;
        margin-bottom: 20px;
    }
    .pf-msg-success { background: #dcfce7; border: 1px solid #86efac; color: #15803d; }
    .pf-msg-danger  { background: #fee2e2; border: 1px solid #fecaca; color: #b91c1c; }
    @media (max-width: 640px) {
        .pf-grid { grid-template-columns: 1fr; }
    }
</style>

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head">
            <h1>Hồ sơ cá nhân</h1>
            <p>Quản lý thông tin tài khoản và mật khẩu</p>
        </div>

        <?php if ($msg): ?>
            <div class="pf-msg pf-msg-<?= $msg_type ?>">
                <i class="fa-solid <?= $msg_type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- THÔNG TIN TÀI KHOẢN -->
        <div class="pf-card">
            <h2><i class="fa-solid fa-user-circle"></i> Thông tin tài khoản</h2>
            <div class="pf-grid">
                <div class="pf-field">
                    <label>Mã người dùng</label>
                    <input type="text" value="<?= htmlspecialchars($user['MaND']) ?>" disabled>
                </div>
                <div class="pf-field">
                    <label>Email</label>
                    <input type="email" value="<?= htmlspecialchars($user['Email']) ?>" disabled>
                </div>
                <div class="pf-field">
                    <label>Vai trò</label>
                    <input type="text" value="<?= htmlspecialchars($user['TenVaiTro'] ?? $user['MaVaiTro']) ?>" disabled>
                </div>
                <div class="pf-field">
                    <label>Khoa / Phòng ban</label>
                    <input type="text" value="<?= htmlspecialchars($user['TenPhongBan'] ?? '—') ?>" disabled>
                </div>
                <div class="pf-field">
                    <label>Ngày tạo</label>
                    <input type="text" value="<?= date('d/m/Y H:i', strtotime($user['NgayTao'])) ?>" disabled>
                </div>
                <div class="pf-field">
                    <label>Đăng nhập cuối</label>
                    <input type="text" value="<?= !empty($user['LastLogin']) ? date('d/m/Y H:i', strtotime($user['LastLogin'])) : 'Chưa đăng nhập' ?>" disabled>
                </div>
            </div>
        </div>

        <!-- CẬP NHẬT THÔNG TIN -->
        <form method="POST" class="pf-card">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="update_info">
            <h2><i class="fa-solid fa-pen-to-square"></i> Cập nhật thông tin</h2>

            <div class="pf-grid">
                <div class="pf-field">
                    <label>Họ và tên <span style="color: #dc2626;">*</span></label>
                    <input type="text" name="ho_ten" value="<?= htmlspecialchars($user['HoTen']) ?>" required>
                </div>
                <div class="pf-field">
                    <label>Mã số</label>
                    <input type="text" name="ma_so" value="<?= htmlspecialchars($user['MaSo'] ?? '') ?>" placeholder="VD: SV001...">
                </div>
                <div class="pf-field">
                    <label>Số điện thoại</label>
                    <input type="tel" name="sdt" value="<?= htmlspecialchars($user['SoDienThoai'] ?? '') ?>" placeholder="0912345678">
                </div>
            </div>

            <button type="submit" class="pf-btn">
                <i class="fa-solid fa-floppy-disk"></i> Lưu thay đổi
            </button>
        </form>

        <!-- ĐỔI MẬT KHẨU -->
        <form method="POST" class="pf-card">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">
            <input type="hidden" name="action" value="change_password">
            <h2><i class="fa-solid fa-lock"></i> Đổi mật khẩu</h2>

            <div class="pf-grid" style="grid-template-columns: 1fr;">
                <div class="pf-field">
                    <label>Mật khẩu hiện tại <span style="color: #dc2626;">*</span></label>
                    <input type="password" name="old_pass" required placeholder="Nhập mật khẩu đang dùng">
                </div>
                <div class="pf-field">
                    <label>Mật khẩu mới <span style="color: #dc2626;">*</span></label>
                    <input type="password" name="new_pass" required minlength="6" placeholder="Ít nhất 6 ký tự">
                </div>
                <div class="pf-field">
                    <label>Xác nhận mật khẩu mới <span style="color: #dc2626;">*</span></label>
                    <input type="password" name="confirm_pass" required placeholder="Nhập lại mật khẩu mới">
                </div>
            </div>

            <button type="submit" class="pf-btn">
                <i class="fa-solid fa-key"></i> Đổi mật khẩu
            </button>
        </form>

    </main>
</div>

<?php include "../../includes/footer_public.php"; ?>