<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để xem lịch sử!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd        = $_SESSION['MaND'];
$base_url     = '/thuvienso/';
$current_page = 'history';
$page_title   = "Lịch sử đọc";

// ============================================================
// XỬ LÝ XOÁ LỊCH SỬ
// ============================================================
$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['remove_one'])) {
        $ma_ls = (int)($_POST['ma_ls'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM lichsudoc WHERE MaLS = ? AND MaND = ?");
        $stmt->bind_param("is", $ma_ls, $ma_nd);
        $stmt->execute();
        $stmt->close();
        $msg = "Đã xoá khỏi lịch sử!";
        $msg_type = 'success';
    } elseif (isset($_POST['clear_all'])) {
        $stmt = $conn->prepare("DELETE FROM lichsudoc WHERE MaND = ?");
        $stmt->bind_param("s", $ma_nd);
        $stmt->execute();
        $stmt->close();
        $msg = "Đã xoá toàn bộ lịch sử!";
        $msg_type = 'success';
    }
}

// ============================================================
// LẤY LỊCH SỬ — 50 gần nhất
// ============================================================
$history = $conn->prepare("
    SELECT ls.MaLS, ls.HanhDong, ls.ThoiGian,
           tl.MaTL, tl.TenTaiLieu, tl.AnhBia, tl.LoaiTaiLieu,
           dm.TenDanhMuc
    FROM lichsudoc ls
    JOIN tai_lieu tl ON ls.MaTL = tl.MaTL
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    WHERE ls.MaND = ?
    ORDER BY ls.ThoiGian DESC
    LIMIT 50
");
$history->bind_param("s", $ma_nd);
$history->execute();
$result = $history->get_result();
$total  = $result->num_rows;

// Đếm tổng để hiển thị
$count_stmt = $conn->prepare("SELECT COUNT(*) AS c FROM lichsudoc WHERE MaND = ?");
$count_stmt->bind_param("s", $ma_nd);
$count_stmt->execute();
$total_all = $count_stmt->get_result()->fetch_assoc()['c'] ?? 0;
$count_stmt->close();

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head" style="display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; flex-wrap: wrap;">
            <div>
                <h1><span><?= $total_all ?></span> lượt đọc gần đây</h1>
                <p>Lịch sử các tài liệu bạn đã xem</p>
            </div>
            <?php if ($total_all > 0): ?>
                <form method="POST" onsubmit="return confirm('Xoá TOÀN BỘ lịch sử đọc? Hành động này không thể hoàn tác!');">
                    <button type="submit" name="clear_all"
                            style="padding: 10px 18px; background: #fff; border: 1.5px solid #fecaca; color: #dc2626; border-radius: 10px; font-size: 13px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s;"
                            onmouseover="this.style.background='#fee2e2'"
                            onmouseout="this.style.background='#fff'">
                        <i class="fa-solid fa-trash"></i> Xoá toàn bộ
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <?php if ($msg): ?>
            <div style="padding: 12px 20px; background: #dcfce7; border: 1px solid #86efac; border-radius: 10px; color: #15803d; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
                <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($total > 0): ?>
            <div class="ud-activity-list">
                <?php while ($row = $result->fetch_assoc()):
                    // Icon + label theo hành động
                    $icon = 'fa-eye'; $label = 'Xem'; $color = 'navy';
                    if ($row['HanhDong'] === 'tai') { $icon = 'fa-download'; $label = 'Tải'; $color = 'teal'; }
                    elseif ($row['HanhDong'] === 'doc') { $icon = 'fa-book-open'; $label = 'Đọc'; $color = 'amber'; }

                    // Thời gian tương đối
                    $diff = time() - strtotime($row['ThoiGian']);
                    if ($diff < 60)          $time_str = 'Vừa xong';
                    elseif ($diff < 3600)    $time_str = floor($diff / 60) . ' phút trước';
                    elseif ($diff < 86400)   $time_str = floor($diff / 3600) . ' giờ trước';
                    elseif ($diff < 604800)  $time_str = floor($diff / 86400) . ' ngày trước';
                    else                     $time_str = date('d/m/Y H:i', strtotime($row['ThoiGian']));
                ?>
                    <div style="position: relative;">
                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= htmlspecialchars($row['MaTL']) ?>" class="ud-activity-item">
                            <div class="ud-activity-icon ud-activity-<?= $color ?>">
                                <i class="fa-solid <?= $icon ?>"></i>
                            </div>
                            <div class="ud-activity-body">
                                <div class="ud-activity-action"><?= $label ?> tài liệu · <?= htmlspecialchars($row['LoaiTaiLieu'] ?? 'Khác') ?></div>
                                <div class="ud-activity-title"><?= htmlspecialchars($row['TenTaiLieu']) ?></div>
                                <div class="ud-activity-time">
                                    <?= $time_str ?>
                                    <?php if ($row['TenDanhMuc']): ?>
                                        · <i class="fa-solid fa-folder" style="font-size: 10px;"></i> <?= htmlspecialchars($row['TenDanhMuc']) ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                        <form method="POST" style="position: absolute; top: 50%; right: 14px; transform: translateY(-50%);" onsubmit="return confirm('Xoá khỏi lịch sử?');">
                            <input type="hidden" name="ma_ls" value="<?= (int)$row['MaLS'] ?>">
                            <button type="submit" name="remove_one" title="Xoá khỏi lịch sử"
                                    style="width: 32px; height: 32px; border-radius: 8px; background: transparent; color: #94a3b8; border: 1px solid #e2e8f0; cursor: pointer; transition: all 0.2s;"
                                    onmouseover="this.style.background='#fee2e2'; this.style.color='#dc2626'; this.style.borderColor='#fecaca';"
                                    onmouseout="this.style.background='transparent'; this.style.color='#94a3b8'; this.style.borderColor='#e2e8f0';">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="ud-empty">
                <i class="fa-solid fa-clock-rotate-left"></i>
                <h3>Chưa có lịch sử đọc</h3>
                <p>Bắt đầu đọc tài liệu để xem lịch sử tại đây</p>
                <a href="<?= $base_url ?>pages/documents/index.php" class="ud-section-link" style="margin-top: 20px; display: inline-flex;">
                    Khám phá tài liệu <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php include "../../includes/footer_public.php"; ?>