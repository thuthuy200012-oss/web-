<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để xem tài liệu yêu thích!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd        = $_SESSION['MaND'];
$base_url     = '/thuvienso/';
$current_page = 'favorites';
$page_title   = "Tài liệu yêu thích";

// ============================================================
// XỬ LÝ XOÁ YÊU THÍCH
// ============================================================
$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_fav'])) {
    $ma_tl = $_POST['ma_tl'] ?? '';
    if (!empty($ma_tl)) {
        $stmt = $conn->prepare("DELETE FROM yeuthich WHERE MaND = ? AND MaTL = ?");
        $stmt->bind_param("ss", $ma_nd, $ma_tl);
        if ($stmt->execute()) {
            $msg = "Đã bỏ khỏi danh sách yêu thích!";
            $msg_type = 'success';
        }
        $stmt->close();
    }
}

// ============================================================
// LẤY DANH SÁCH YÊU THÍCH
// ============================================================
$favorites = $conn->prepare("
    SELECT tl.MaTL, tl.TenTaiLieu, tl.AnhBia, tl.LoaiTaiLieu, tl.SoLuotXem,
           tl.NamXuatBan,
           dm.TenDanhMuc,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia,
           yt.NgayThem
    FROM yeuthich yt
    JOIN tai_lieu tl ON yt.MaTL = tl.MaTL
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    WHERE yt.MaND = ? AND tl.TrangThai = 'Đã duyệt'
    GROUP BY tl.MaTL
    ORDER BY yt.NgayThem DESC
");
$favorites->bind_param("s", $ma_nd);
$favorites->execute();
$result = $favorites->get_result();
$total  = $result->num_rows;

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head">
            <h1><span><?= $total ?></span> tài liệu yêu thích</h1>
            <p>Những tài liệu bạn đã lưu để đọc lại sau</p>
        </div>

        <?php if ($msg): ?>
            <div style="padding: 12px 20px; background: #dcfce7; border: 1px solid #86efac; border-radius: 10px; color: #15803d; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
                <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($total > 0): ?>
            <div class="ud-suggested-grid">
                <?php while ($doc = $result->fetch_assoc()): ?>
                    <div class="ud-suggest-card" style="position: relative;">
                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= $doc['MaTL'] ?>" style="text-decoration: none; color: inherit; display: flex; flex-direction: column; flex: 1;">
                            <div class="ud-suggest-cover">
                                <?php if (!empty($doc['AnhBia']) && file_exists("../../" . $doc['AnhBia'])): ?>
                                    <img src="<?= $base_url . htmlspecialchars($doc['AnhBia']) ?>" alt="">
                                <?php else: ?>
                                    <div class="ud-suggest-cover-placeholder">
                                        <i class="fa-solid fa-file-lines"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="ud-suggest-type"><?= htmlspecialchars($doc['LoaiTaiLieu'] ?? 'Tài liệu') ?></span>
                            </div>
                            <div class="ud-suggest-body">
                                <h3><?= htmlspecialchars($doc['TenTaiLieu']) ?></h3>
                                <p class="ud-suggest-author">
                                    <i class="fa-solid fa-user-pen"></i>
                                    <?= htmlspecialchars($doc['TenTacGia'] ?? 'Chưa rõ tác giả') ?>
                                </p>
                                <div class="ud-suggest-meta">
                                    <span><i class="fa-solid fa-folder"></i> <?= htmlspecialchars($doc['TenDanhMuc'] ?? 'Chưa phân loại') ?></span>
                                    <span><i class="fa-solid fa-eye"></i> <?= number_format($doc['SoLuotXem']) ?></span>
                                </div>
                                <div class="ud-suggest-cta">
                                    Đọc ngay <i class="fa-solid fa-arrow-right"></i>
                                </div>
                            </div>
                        </a>

                        <form method="POST" style="position: absolute; top: 12px; right: 12px;" onsubmit="return confirm('Bỏ tài liệu này khỏi yêu thích?');">
                            <input type="hidden" name="ma_tl" value="<?= htmlspecialchars($doc['MaTL']) ?>">
                            <button type="submit" name="remove_fav" title="Bỏ yêu thích"
                                    style="width: 36px; height: 36px; border-radius: 50%; background: rgba(220, 38, 38, 0.95); color: #fff; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.2); transition: all 0.2s;"
                                    onmouseover="this.style.transform='scale(1.1)'"
                                    onmouseout="this.style.transform='scale(1)'">
                                <i class="fa-solid fa-heart-crack"></i>
                            </button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="ud-empty">
                <i class="fa-solid fa-heart"></i>
                <h3>Chưa có tài liệu yêu thích</h3>
                <p>Hãy bấm vào biểu tượng <i class="fa-solid fa-heart" style="color: #dc2626;"></i> ở trang chi tiết tài liệu để lưu lại</p>
                <a href="<?= $base_url ?>pages/documents/index.php" class="ud-section-link" style="margin-top: 20px; display: inline-flex;">
                    Khám phá tài liệu <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php include "../../includes/footer_public.php"; ?>