<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/audit.php";
require_once "../../includes/auth.php";
require_once "../../includes/functions.php";

check_session_timeout();
try_remember_login($conn);


if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để nộp tài liệu!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd        = $_SESSION['MaND'];
$base_url     = '/thuvienso/';
$current_page = 'submission_create';
$page_title   = "Nộp tài liệu mới";

// CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$msg = '';
$msg_type = '';
$form_data = [
    'ten_tl'       => '',
    'ma_dm'        => '',
    'ma_nam'       => '',
    'loai_tl'      => '',
    'nam_xb'       => date('Y'),
    'so_trang'     => '',
    'ngon_ngu'     => 'Tiếng Việt',
    'tom_tat'      => '',
    'tu_khoa'      => '',
    'muc_truy_cap' => 'Công khai',
    'tac_gia_text' => '',
    'gvhd_text'    => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf'] ?? '')) {
        $msg = "Phiên làm việc không hợp lệ. Vui lòng tải lại trang!";
        $msg_type = 'danger';
    } else {
        $ten_tl       = trim($_POST['ten_tl'] ?? '');
        $ma_dm        = $_POST['ma_dm'] ?? '';
        $ma_nam       = trim($_POST['ma_nam'] ?? '');
        $loai_tl      = trim($_POST['loai_tl'] ?? '');
        $nam_xb       = (int)($_POST['nam_xb'] ?? 0);
        $so_trang     = (int)($_POST['so_trang'] ?? 0);
        $ngon_ngu     = trim($_POST['ngon_ngu'] ?? 'Tiếng Việt');
        $tom_tat      = trim($_POST['tom_tat'] ?? '');
        $tu_khoa      = trim($_POST['tu_khoa'] ?? '');
        $muc_truy_cap = $_POST['muc_truy_cap'] ?? 'Công khai';
        $tac_gia_text = trim($_POST['tac_gia_text'] ?? '');
        $gvhd_text    = trim($_POST['gvhd_text'] ?? '');

        if ($ma_nam === '') {
            $ma_nam = null;
        }

        $form_data = compact('ten_tl', 'ma_dm', 'ma_nam', 'loai_tl', 'nam_xb', 'so_trang',
                             'ngon_ngu', 'tom_tat', 'tu_khoa', 'muc_truy_cap',
                             'tac_gia_text', 'gvhd_text');

        
        if (empty($ten_tl) || empty($ma_dm)) {
            $msg = "Vui lòng nhập Tên tài liệu và chọn Danh mục!";
            $msg_type = 'danger';
        } elseif (empty($tac_gia_text)) {
            $msg = "Vui lòng nhập ít nhất 1 tác giả!";
            $msg_type = 'danger';
        } else {
            
            try {
                $ma_tl = generate_unique_id($conn, 'tai_lieu', 'MaTL', 'TL');
            } catch (Exception $e) {
                error_log("submission/create generate_id error: " . $e->getMessage());
                $ma_tl = null;
                $msg = "Hệ thống đang bận, vui lòng thử lại!";
                $msg_type = 'danger';
            }

            $duong_dan_file = null;
            $duong_dan_anh  = null;
            $MAX_FILE_SIZE = 20 * 1024 * 1024;

            if ($ma_tl !== null && isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] === UPLOAD_ERR_OK && !empty($_FILES['file_pdf']['name'])) {
                $file = $_FILES['file_pdf'];

                if ($file['size'] > $MAX_FILE_SIZE) {
                    $msg = "File quá lớn! Tối đa " . ($MAX_FILE_SIZE / 1024 / 1024) . " MB.";
                    $msg_type = 'danger';
                }
                elseif (!in_array(strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)), ['pdf', 'doc', 'docx'])) {
                    $msg = "Định dạng không hợp lệ! Chỉ chấp nhận PDF, DOC, DOCX.";
                    $msg_type = 'danger';
                }
                else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $real_mime = finfo_file($finfo, $file['tmp_name']);
                    finfo_close($finfo);

                    $allowed_mimes = [
                        'application/pdf',
                        'application/msword',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/octet-stream',
                    ];

                    if (!in_array($real_mime, $allowed_mimes)) {
                        $msg = "Nội dung file không hợp lệ!";
                        $msg_type = 'danger';
                    } else {
                        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $filename = $ma_tl . '_' . time() . '.' . $ext;
                        $target = "../../uploads/documents/" . $filename;
                        if (!is_dir("../../uploads/documents/")) {
                            mkdir("../../uploads/documents/", 0755, true);
                        }
                        if (move_uploaded_file($file['tmp_name'], $target)) {
                            $duong_dan_file = 'uploads/documents/' . $filename;
                        } else {
                            $msg = "Không thể lưu file tài liệu!";
                            $msg_type = 'danger';
                        }
                    }
                }
            }
            $MAX_IMAGE_SIZE = 5 * 1024 * 1024;

            if ($ma_tl !== null && $msg_type !== 'danger' && isset($_FILES['anh_bia']) && $_FILES['anh_bia']['error'] === UPLOAD_ERR_OK && !empty($_FILES['anh_bia']['name'])) {
                $file = $_FILES['anh_bia'];

                if ($file['size'] > $MAX_IMAGE_SIZE) {
                    $msg = "Ảnh bìa quá lớn! Tối đa " . ($MAX_IMAGE_SIZE / 1024 / 1024) . " MB.";
                    $msg_type = 'danger';
                }
                elseif (!in_array(strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp'])) {
                    $msg = "Ảnh bìa không hợp lệ! Chỉ chấp nhận JPG, PNG, WEBP.";
                    $msg_type = 'danger';
                }
                else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $real_mime = finfo_file($finfo, $file['tmp_name']);
                    finfo_close($finfo);

                    $allowed_img_mimes = ['image/jpeg', 'image/png', 'image/webp'];

                    if (!in_array($real_mime, $allowed_img_mimes)) {
                        $msg = "Ảnh bìa không hợp lệ!";
                        $msg_type = 'danger';
                    }
                    elseif (!@getimagesize($file['tmp_name'])) {
                        $msg = "File không phải là ảnh hợp lệ!";
                        $msg_type = 'danger';
                    }
                    else {
                        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $filename = 'cover_' . $ma_tl . '_' . time() . '.' . $ext;
                        $target = "../../uploads/covers/" . $filename;
                        if (!is_dir("../../uploads/covers/")) {
                            mkdir("../../uploads/covers/", 0755, true);
                        }
                        if (move_uploaded_file($file['tmp_name'], $target)) {
                            $duong_dan_anh = 'uploads/covers/' . $filename;
                        }
                    }
                }
            }

           
            if ($ma_tl !== null && $msg_type !== 'danger') {
                $trang_thai = 'Chờ duyệt';

                $conn->begin_transaction();

                try {
                    $stmt = $conn->prepare("
                        INSERT INTO tai_lieu
                        (MaTL, TenTaiLieu, MaDM, MaNam, MaND, LoaiTaiLieu, NamXuatBan, SoTrang, NgonNgu,
                         TomTat, TuKhoa, FileTaiLieu, AnhBia, TrangThai, MucTruyCap)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");

                    if (!$stmt) {
                        throw new Exception("Prepare failed: " . $conn->error);
                    }

                    $stmt->bind_param(
                        "ssssssiisssssss",
                        $ma_tl, $ten_tl, $ma_dm, $ma_nam, $ma_nd, $loai_tl, $nam_xb, $so_trang, $ngon_ngu,
                        $tom_tat, $tu_khoa, $duong_dan_file, $duong_dan_anh, $trang_thai, $muc_truy_cap
                    );

                    if (!$stmt->execute()) {
                        throw new Exception("Execute failed: " . $stmt->error);
                    }
                    $stmt->close();

                    $arr_tg = array_map('trim', explode(',', $tac_gia_text));
                    foreach ($arr_tg as $tg_name) {
                        if ($tg_name === '') continue;

                        $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                        $stmt_check->bind_param("s", $tg_name);
                        $stmt_check->execute();
                        $existing = $stmt_check->get_result()->fetch_assoc();
                        $stmt_check->close();

                        if ($existing) {
                            $ma_tg = $existing['MaTG'];
                        } else {
                            $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                            $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                            $stmt_new->bind_param("ss", $ma_tg, $tg_name);
                            if (!$stmt_new->execute()) {
                                throw new Exception("Không thể lưu tác giả: " . $stmt_new->error);
                            }
                            $stmt_new->close();
                        }

                        $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'Tác giả')");
                        $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                        if (!$stmt_link->execute()) {
                            throw new Exception("Không thể liên kết tác giả: " . $stmt_link->error);
                        }
                        $stmt_link->close();
                    }

                    if ($gvhd_text !== '') {
                        $arr_gv = array_map('trim', explode(',', $gvhd_text));
                        foreach ($arr_gv as $gv_name) {
                            if ($gv_name === '') continue;

                            $stmt_check = $conn->prepare("SELECT MaTG FROM tac_gia WHERE HoTen = ? LIMIT 1");
                            $stmt_check->bind_param("s", $gv_name);
                            $stmt_check->execute();
                            $existing = $stmt_check->get_result()->fetch_assoc();
                            $stmt_check->close();

                            if ($existing) {
                                $ma_tg = $existing['MaTG'];
                            } else {
                                $ma_tg = taoMa($conn, 'tac_gia', 'MaTG', 'TG');
                                $stmt_new = $conn->prepare("INSERT INTO tac_gia (MaTG, HoTen, TrangThai) VALUES (?, ?, 1)");
                                $stmt_new->bind_param("ss", $ma_tg, $gv_name);
                                if (!$stmt_new->execute()) {
                                    throw new Exception("Không thể lưu GVHD: " . $stmt_new->error);
                                }
                                $stmt_new->close();
                            }

                            $stmt_link = $conn->prepare("INSERT INTO tailieutacgia (MaTL, MaTG, VaiTro) VALUES (?, ?, 'GVHD')");
                            $stmt_link->bind_param("ss", $ma_tl, $ma_tg);
                            if (!$stmt_link->execute()) {
                                throw new Exception("Không thể liên kết GVHD: " . $stmt_link->error);
                            }
                            $stmt_link->close();
                        }
                    }

                    $conn->commit();

                    ghi_log($conn, 'CREATE',
                        "Nộp tài liệu: $ten_tl (Mã: $ma_tl)",
                        'tai_lieu', $ma_tl);

                    $_SESSION['flash_msg'] = "Đã nộp tài liệu <b>" . htmlspecialchars($ten_tl) . "</b>! Vui lòng chờ kiểm duyệt.";
                    $_SESSION['flash_type'] = 'success';
                    header("Location: index.php");
                    exit();

                } catch (Exception $e) {
                    $conn->rollback();
                    if (!empty($duong_dan_file) && file_exists("../../" . $duong_dan_file)) {
                        @unlink("../../" . $duong_dan_file);
                    }
                    if (!empty($duong_dan_anh) && file_exists("../../" . $duong_dan_anh)) {
                        @unlink("../../" . $duong_dan_anh);
                    }
                    error_log("submission/create transaction error: " . $e->getMessage());
                    $msg = "Đã xảy ra lỗi: " . htmlspecialchars($e->getMessage());
                    $msg_type = 'danger';
                }
            }
        }
    }
}


$danh_muc_list = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");
$loai_list     = $conn->query("SELECT TenLoai FROM loaitailieu ORDER BY ThuTu");

$nam_hoc_data = [];
$current_nam_hoc = null;
$res_nh = $conn->query("
    SELECT MaNam, TenNam, NamBatDau, NamKetThuc 
    FROM namhoc 
    ORDER BY NamBatDau DESC
");
if ($res_nh) {
    $current_year = (int)date('Y');
    while ($nh = $res_nh->fetch_assoc()) {
        $nam_hoc_data[] = $nh;
        if ($current_year >= $nh['NamBatDau'] && $current_year <= $nh['NamKetThuc']) {
            $current_nam_hoc = $nh['MaNam'];
        }
    }
}

$existing_authors = [];
$res = $conn->query("SELECT HoTen FROM tac_gia WHERE TrangThai=1 ORDER BY HoTen");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $existing_authors[] = $row['HoTen'];
    }
}

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<style>
    .sf-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 28px;
        margin-bottom: 24px;
    }
    .sf-card h3 {
        font-size: 14px;
        font-weight: 800;
        color: #0c1e3e;
        margin: 0 0 20px;
        padding-bottom: 14px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        align-items: center;
        gap: 10px;
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }
    .sf-card h3 i { color: #0d9488; font-size: 16px; }
    .sf-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; margin-bottom: 18px; }
    .sf-field { margin-bottom: 18px; }
    .sf-field label {
        display: block; font-size: 12px; font-weight: 700; color: #475569;
        margin-bottom: 8px; letter-spacing: 0.3px;
    }
    .sf-field label .req { color: #dc2626; margin-left: 3px; }
    .sf-field label .optional { color: #94a3b8; font-weight: 400; font-size: 11px; }
    .sf-field input, .sf-field select, .sf-field textarea {
        width: 100%; padding: 11px 14px; border: 1.5px solid #cbd5e1;
        border-radius: 9px; font-size: 14px; box-sizing: border-box;
        transition: border-color 0.2s; font-family: inherit; background: #fff;
    }
    .sf-field input:focus, .sf-field select:focus, .sf-field textarea:focus {
        outline: none; border-color: #0d9488;
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }
    .sf-field textarea { resize: vertical; min-height: 90px; }
    .sf-hint { font-size: 12px; color: #94a3b8; margin-top: 6px; font-style: italic; }
    .sf-alert {
        padding: 14px 20px; border-radius: 10px; font-size: 13.5px;
        font-weight: 600; margin-bottom: 22px; display: flex;
        align-items: flex-start; gap: 10px;
    }
    .sf-alert i { font-size: 16px; margin-top: 1px; }
    .sf-alert-success { background: #dcfce7; border: 1px solid #86efac; color: #15803d; }
    .sf-alert-danger  { background: #fee2e2; border: 1px solid #fecaca; color: #b91c1c; }
    .sf-alert-info    { background: #dbeafe; border: 1px solid #93c5fd; color: #1d4ed8; }
    .sf-actions { display: flex; gap: 12px; justify-content: flex-end; padding-top: 8px; }
    .sf-btn {
        padding: 12px 24px; border: none; border-radius: 10px;
        font-size: 14px; font-weight: 700; cursor: pointer;
        display: inline-flex; align-items: center; gap: 8px;
        transition: all 0.2s; text-decoration: none; font-family: inherit;
    }
    .sf-btn-primary { background: linear-gradient(135deg, #0d9488, #14b8a6); color: #fff; }
    .sf-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(13, 148, 136, 0.3); }
    .sf-btn-secondary { background: #f1f5f9; color: #475569; }
    .sf-btn-secondary:hover { background: #e2e8f0; }
    @media (max-width: 768px) { .sf-grid { grid-template-columns: 1fr; } }
</style>

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head">
            <h1>Nộp tài liệu mới</h1>
            <p>Chia sẻ tài liệu học tập của bạn với cộng đồng — Admin sẽ kiểm duyệt trước khi công khai</p>
        </div>

        <?php if ($msg): ?>
            <div class="sf-alert sf-alert-<?= $msg_type ?>">
                <i class="fa-solid <?= $msg_type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                <div><?= $msg ?></div>
            </div>
        <?php endif; ?>

        <div class="sf-alert sf-alert-info">
            <i class="fa-solid fa-circle-info"></i>
            <div>
                Sau khi nộp, tài liệu của bạn sẽ có trạng thái <b>"Chờ duyệt"</b>.
                Admin/Thủ thư sẽ kiểm tra và duyệt trong vòng 1-2 ngày làm việc.
            </div>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES) ?>">

            <div class="sf-card">
                <h3><i class="fa-solid fa-circle-info"></i> Thông tin cơ bản</h3>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>Tên tài liệu <span class="req">*</span></label>
                        <input type="text" name="ten_tl" required
                               value="<?= htmlspecialchars($form_data['ten_tl']) ?>"
                               placeholder="VD: Giáo trình Lập trình PHP">
                    </div>
                    <div class="sf-field">
                        <label>Danh mục <span class="req">*</span></label>
                        <select name="ma_dm" required>
                            <option value="">-- Chọn danh mục --</option>
                            <?php if ($danh_muc_list): while ($dm = $danh_muc_list->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($dm['MaDM']) ?>"
                                    <?= $form_data['ma_dm'] === $dm['MaDM'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($dm['TenDanhMuc']) ?>
                                </option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>
                </div>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>Năm học <span class="optional">(nếu có)</span></label>
                        <select name="ma_nam">
                            <option value="">-- Chọn năm học --</option>
                            <?php foreach ($nam_hoc_data as $nh): ?>
                                <option value="<?= htmlspecialchars($nh['MaNam']) ?>"
                                    <?= ($form_data['ma_nam'] === $nh['MaNam'] || (empty($form_data['ma_nam']) && $current_nam_hoc === $nh['MaNam'])) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($nh['TenNam']) ?> (<?= (int)$nh['NamBatDau'] ?>-<?= (int)$nh['NamKetThuc'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="sf-hint">Chọn năm học tài liệu thuộc về (nếu có)</div>
                    </div>
                    <div class="sf-field">
                        <label>Loại tài liệu</label>
                        <select name="loai_tl">
                            <option value="">-- Chọn loại --</option>
                            <?php if ($loai_list): while ($l = $loai_list->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($l['TenLoai']) ?>"
                                    <?= $form_data['loai_tl'] === $l['TenLoai'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($l['TenLoai']) ?>
                                </option>
                            <?php endwhile; endif; ?>
                        </select>
                    </div>
                </div>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>Năm xuất bản</label>
                        <input type="number" name="nam_xb" min="1900" max="<?= date('Y') + 1 ?>"
                               value="<?= htmlspecialchars($form_data['nam_xb']) ?>">
                    </div>
                    <div class="sf-field">
                        <label>Số trang</label>
                        <input type="number" name="so_trang" min="0"
                               value="<?= htmlspecialchars($form_data['so_trang']) ?>"
                               placeholder="VD: 120">
                    </div>
                </div>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>Ngôn ngữ</label>
                        <input type="text" name="ngon_ngu"
                               value="<?= htmlspecialchars($form_data['ngon_ngu']) ?>">
                    </div>
                    <div class="sf-field">
                        <label>Mức truy cập</label>
                        <select name="muc_truy_cap">
                            <option value="Công khai" <?= $form_data['muc_truy_cap'] === 'Công khai' ? 'selected' : '' ?>>Công khai</option>
                            <option value="Nội bộ"    <?= $form_data['muc_truy_cap'] === 'Nội bộ'    ? 'selected' : '' ?>>Nội bộ</option>
                        </select>
                    </div>
                </div>

                <div class="sf-field">
                    <label>Từ khóa</label>
                    <input type="text" name="tu_khoa"
                           value="<?= htmlspecialchars($form_data['tu_khoa']) ?>"
                           placeholder="Cách nhau dấu phẩy: PHP, Lập trình, Web">
                </div>

                <div class="sf-field">
                    <label>Tóm tắt</label>
                    <textarea name="tom_tat" placeholder="Mô tả ngắn về nội dung tài liệu..."><?= htmlspecialchars($form_data['tom_tat']) ?></textarea>
                </div>
            </div>

            <div class="sf-card">
                <h3><i class="fa-solid fa-user-pen"></i> Tác giả & Người hướng dẫn</h3>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>Nhóm tác giả <span class="req">*</span></label>
                        <input type="text" name="tac_gia_text" required
                               value="<?= htmlspecialchars($form_data['tac_gia_text']) ?>"
                               placeholder="VD: Nguyễn Văn An, Trần Thị Bình"
                               list="tacGiaList">
                        <datalist id="tacGiaList">
                            <?php foreach ($existing_authors as $author): ?>
                                <option value="<?= htmlspecialchars($author) ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <div class="sf-hint">Nhiều tác giả cách nhau dấu phẩy</div>
                    </div>
                    <div class="sf-field">
                        <label>Giảng viên hướng dẫn <span class="optional">(nếu có)</span></label>
                        <input type="text" name="gvhd_text"
                               value="<?= htmlspecialchars($form_data['gvhd_text']) ?>"
                               placeholder="VD: TS. Nguyễn Văn C"
                               list="gvhdList">
                        <datalist id="gvhdList">
                            <?php foreach ($existing_authors as $author): ?>
                                <option value="<?= htmlspecialchars($author) ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <div class="sf-hint">Áp dụng cho Khóa luận / Luận văn / Đề tài NCKH</div>
                    </div>
                </div>
            </div>

            <div class="sf-card">
                <h3><i class="fa-solid fa-file-arrow-up"></i> File tài liệu & Ảnh bìa</h3>

                <div class="sf-grid">
                    <div class="sf-field">
                        <label>File tài liệu (PDF/DOC/DOCX) <span class="optional">(không bắt buộc)</span></label>
                        <input type="file" name="file_pdf" accept=".pdf,.doc,.docx">
                        <div class="sf-hint">Dung lượng tối đa 20MB. Có thể bỏ trống nếu chỉ muốn giới thiệu tài liệu.</div>
                    </div>
                    <div class="sf-field">
                        <label>Ảnh bìa (JPG/PNG/WEBP) <span class="optional">(không bắt buộc)</span></label>
                        <input type="file" name="anh_bia" accept=".jpg,.jpeg,.png,.webp">
                        <div class="sf-hint">Ảnh 600x800px (tỷ lệ 3:4). Tối đa 5MB.</div>
                    </div>
                </div>
            </div>

            <div class="sf-actions">
                <a href="index.php" class="sf-btn sf-btn-secondary">
                    <i class="fa-solid fa-xmark"></i> Huỷ
                </a>
                <button type="submit" class="sf-btn sf-btn-primary">
                    <i class="fa-solid fa-cloud-arrow-up"></i> Nộp tài liệu
                </button>
            </div>
        </form>

    </main>
</div>

<?php include "../../includes/footer_public.php"; ?>