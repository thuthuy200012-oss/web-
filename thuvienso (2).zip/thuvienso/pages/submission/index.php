<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

if (empty($_SESSION['MaND'])) {
    $_SESSION['flash_msg'] = "Vui lòng đăng nhập để xem bài đã nộp!";
    header('Location: ../auth/login.php');
    exit;
}

$ma_nd        = $_SESSION['MaND'];
$base_url     = '/thuvienso/';
$current_page = 'submission';
$page_title   = "Bài đã nộp";

$msg = '';
$msg_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_submission'])) {
    $ma_tl = $_POST['ma_tl'] ?? '';

    $stmt = $conn->prepare("SELECT FileTaiLieu, AnhBia, TrangThai FROM tai_lieu WHERE MaTL = ? AND MaND = ?");
    $stmt->bind_param("ss", $ma_tl, $ma_nd);
    $stmt->execute();
    $doc = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$doc) {
        $msg = "Không tìm thấy tài liệu!";
        $msg_type = 'danger';
    } elseif (!in_array($doc['TrangThai'], ['Chờ duyệt', 'Từ chối'])) {
        $msg = "Chỉ có thể xoá tài liệu ở trạng thái 'Chờ duyệt' hoặc 'Từ chối'!";
        $msg_type = 'danger';
    } else {
        $conn->prepare("DELETE FROM tailieutacgia WHERE MaTL = ?")->execute();
        $stmt = $conn->prepare("DELETE FROM tai_lieu WHERE MaTL = ? AND MaND = ?");
        $stmt->bind_param("ss", $ma_tl, $ma_nd);
        if ($stmt->execute()) {
            if (!empty($doc['FileTaiLieu']) && file_exists("../../" . $doc['FileTaiLieu'])) {
                @unlink("../../" . $doc['FileTaiLieu']);
            }
            if (!empty($doc['AnhBia']) && file_exists("../../" . $doc['AnhBia'])) {
                @unlink("../../" . $doc['AnhBia']);
            }
            $msg = "Đã xoá tài liệu!";
            $msg_type = 'success';
        } else {
            $msg = "Không thể xoá, vui lòng thử lại!";
            $msg_type = 'danger';
        }
        $stmt->close();
    }
}
$stmt = $conn->prepare("
    SELECT tl.MaTL, tl.TenTaiLieu, tl.AnhBia, tl.LoaiTaiLieu, tl.TrangThai,
           tl.LyDoTuChoi, tl.NgayDang, tl.SoLuotXem,
           dm.TenDanhMuc
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    WHERE tl.MaND = ?
    ORDER BY tl.NgayDang DESC
");
$stmt->bind_param("s", $ma_nd);
$stmt->execute();
$result = $stmt->get_result();
$total  = $result->num_rows;

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<style>
    .sb-table {
        width: 100%;
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        overflow: hidden;
    }
    .sb-table table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13.5px;
    }
    .sb-table thead {
        background: #f8fafc;
        border-bottom: 2px solid #e2e8f0;
    }
    .sb-table th {
        padding: 14px 16px;
        text-align: left;
        font-size: 11.5px;
        font-weight: 800;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.6px;
    }
    .sb-table td {
        padding: 16px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
    }
    .sb-table tr:last-child td {
        border-bottom: none;
    }
    .sb-table tr:hover td {
        background: #f8fafc;
    }
    .sb-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 12px;
        border-radius: 999px;
        font-size: 11.5px;
        font-weight: 700;
        letter-spacing: 0.3px;
    }
    .sb-badge-warning { background: #fef3c7; color: #92400e; }
    .sb-badge-success { background: #dcfce7; color: #15803d; }
    .sb-badge-danger  { background: #fee2e2; color: #b91c1c; }
    .sb-actions {
        display: flex;
        gap: 6px;
    }
    .sb-icon-btn {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        text-decoration: none;
        transition: all 0.15s;
    }
    .sb-icon-view { background: #e0e7ff; color: #4338ca; }
    .sb-icon-del  { background: #fee2e2; color: #dc2626; }
    .sb-icon-btn:hover { transform: translateY(-2px); }
    .sb-reject-reason {
        padding: 10px 14px;
        background: #fef3c7;
        border-left: 3px solid #f59e0b;
        border-radius: 6px;
        font-size: 12.5px;
        color: #92400e;
        margin-top: 8px;
        line-height: 1.5;
    }
</style>

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head" style="display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; flex-wrap: wrap;">
            <div>
                <h1><span><?= $total ?></span> tài liệu đã nộp</h1>
                <p>Quản lý tài liệu bạn đã gửi lên hệ thống</p>
            </div>
            <a href="<?= $base_url ?>pages/submission/create.php" class="pf-btn" style="padding: 12px 22px; background: linear-gradient(135deg, #0d9488, #14b8a6); text-decoration: none; color: #fff; border-radius: 10px; font-size: 14px; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-plus-circle"></i> Nộp tài liệu mới
            </a>
        </div>

        <?php if ($msg): ?>
            <div class="pf-msg pf-msg-<?= $msg_type ?>" style="padding: 12px 20px; border-radius: 10px; font-size: 13.5px; font-weight: 600; margin-bottom: 20px;">
                <i class="fa-solid <?= $msg_type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($total > 0): ?>
            <div class="sb-table">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 60px;">Mã</th>
                            <th>Tên tài liệu</th>
                            <th style="width: 140px;">Danh mục</th>
                            <th style="width: 130px;">Loại</th>
                            <th style="width: 130px;">Trạng thái</th>
                            <th style="width: 130px;">Ngày nộp</th>
                            <th style="width: 110px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()):
                            $trang_thai = $row['TrangThai'];
                            $badge_class = 'sb-badge-warning';
                            $badge_icon = 'fa-clock';
                            if ($trang_thai === 'Đã duyệt') { $badge_class = 'sb-badge-success'; $badge_icon = 'fa-circle-check'; }
                            elseif ($trang_thai === 'Từ chối') { $badge_class = 'sb-badge-danger'; $badge_icon = 'fa-circle-xmark'; }

                            $can_delete = in_array($trang_thai, ['Chờ duyệt', 'Từ chối']);
                        ?>
                            <tr>
                                <td>
                                    <span style="font-family: monospace; font-weight: 700; color: #1d4ed8; background: #eff6ff; padding: 3px 8px; border-radius: 4px; font-size: 11.5px;">
                                        <?= htmlspecialchars($row['MaTL']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: #0c1e3e; margin-bottom: 4px;">
                                        <?= htmlspecialchars($row['TenTaiLieu']) ?>
                                    </div>
                                    <?php if ($trang_thai === 'Từ chối' && !empty($row['LyDoTuChoi'])): ?>
                                        <div class="sb-reject-reason">
                                            <b>Lý do từ chối:</b> <?= htmlspecialchars($row['LyDoTuChoi']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['TenDanhMuc'] ?? '—') ?></td>
                                <td><?= htmlspecialchars($row['LoaiTaiLieu'] ?? '—') ?></td>
                                <td>
                                    <span class="sb-badge <?= $badge_class ?>">
                                        <i class="fa-solid <?= $badge_icon ?>"></i>
                                        <?= htmlspecialchars($trang_thai) ?>
                                    </span>
                                </td>
                                <td>
                                    <small style="color: #64748b;">
                                        <?= date('d/m/Y', strtotime($row['NgayDang'])) ?>
                                        <br>
                                        <span style="color: #94a3b8; font-size: 11px;"><?= date('H:i', strtotime($row['NgayDang'])) ?></span>
                                    </small>
                                </td>
                                <td>
                                    <div class="sb-actions">
                                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= htmlspecialchars($row['MaTL']) ?>"
                                           class="sb-icon-btn sb-icon-view" title="Xem chi tiết">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <?php if ($can_delete): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Xoá tài liệu này? Hành động không thể hoàn tác!');">
                                                <input type="hidden" name="ma_tl" value="<?= htmlspecialchars($row['MaTL']) ?>">
                                                <button type="submit" name="delete_submission" class="sb-icon-btn sb-icon-del" title="Xoá">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <button type="button" class="sb-icon-btn" disabled
                                                    style="background: #f1f5f9; color: #cbd5e1; cursor: not-allowed;"
                                                    title="Không thể xoá khi đã duyệt">
                                                <i class="fa-solid fa-lock"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="ud-empty">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <h3>Chưa có tài liệu nào được nộp</h3>
                <p>Bắt đầu chia sẻ tài liệu học tập của bạn với cộng đồng</p>
                <a href="<?= $base_url ?>pages/submission/create.php" class="ud-section-link" style="margin-top: 20px; display: inline-flex;">
                    Nộp tài liệu đầu tiên <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        <?php endif; ?>

    </main>
</div>

<?php include "../../includes/footer_public.php"; ?>