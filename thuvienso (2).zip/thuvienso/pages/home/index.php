<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

$base_url     = '/thuvienso/';
$current_page = 'home';
$is_logged_in = isset($_SESSION['MaND']);
$vai_tro      = $_SESSION['MaVaiTro'] ?? null;

// Stats
$total_tai_lieu = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai='Đã duyệt'")->fetch_assoc()['c'] ?? 0;
$total_noi_sinh = $conn->query("SELECT COUNT(*) AS c FROM tai_lieu WHERE TrangThai='Đã duyệt' AND LoaiTaiLieu IN ('Khóa Luận','Luận Văn','Đề Tài NCKH')")->fetch_assoc()['c'] ?? 0;
$total_tac_gia = $conn->query("SELECT COUNT(*) AS c FROM tac_gia")->fetch_assoc()['c'] ?? 0;
$total_truy_cap = $conn->query("SELECT SUM(SoLuotXem) AS c FROM tai_lieu")->fetch_assoc()['c'] ?? 0;

// Danh mục tài liệu
$loai_list = $conn->query("
    SELECT MaLoai, TenLoai
    FROM loaitailieu
    ORDER BY ThuTu ASC, TenLoai ASC
");

/**
 * Bộ SVG icon dùng chung — không cần FontAwesome
 */
function svg_icon(string $name, string $size = '20'): string
{
    $icons = [
        'search'       => '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
        'graduation'   => '<path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',
        'user-grad'    => '<circle cx="12" cy="7" r="3"/><path d="M12 4l3 1.5-3 1.5-3-1.5z"/><path d="M6 22v-4a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v4"/>',
        'flask'        => '<path d="M9 3h6v6l4 10a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L9 9z"/><line x1="9" y1="3" x2="15" y2="3"/>',
        'microscope'   => '<path d="M6 18h8"/><path d="M3 22h18"/><path d="M14 22a7 7 0 1 0 0-14h-1"/><path d="M9 14h2"/><path d="M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2z"/><path d="M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3"/>',
        'book'         => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
        'book-open'    => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
        'file-lines'   => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
        'users'        => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'folder'       => '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
        'folder-open'  => '<path d="M6 14l1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2"/>',
        'layers'       => '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
        'clock'        => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
        'fire'         => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
        'arrow-right'  => '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
        'user'         => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'building'     => '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
        'calendar'     => '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
        'sliders'      => '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
        'user-tie'     => '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v2"/><path d="M12 15l-2 6 2-1 2 1z"/>',
        'inbox'        => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    ];
    $path = $icons[$name] ?? '<circle cx="12" cy="12" r="10"/>';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

/**
 * Map icon theo tên loại tài liệu
 */
function icon_for_loai(string $ten_loai): string
{
    $map = [
        'khóa luận'  => 'graduation',
        'luận văn'   => 'user-grad',
        'đề tài'     => 'microscope',
        'nghiên cứu' => 'flask',
        'giáo trình' => 'book',
        'bài báo'    => 'file-lines',
        'kỷ yếu'     => 'users',
        'hội thảo'   => 'users',
        'báo cáo'    => 'file-lines',
        'tạp chí'    => 'book-open',
    ];
    $lower = mb_strtolower($ten_loai, 'UTF-8');
    foreach ($map as $key => $icon) {
        if (mb_strpos($lower, $key) !== false) return $icon;
    }
    return 'folder';
}

// Tài liệu mới
$latest_docs = $conn->query("
    SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.NamXuatBan, tl.AnhBia,
           dm.TenDanhMuc, pb.TenPhongBan,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    LEFT JOIN phong_ban pb ON tg.MaPB = pb.MaPB
    WHERE tl.TrangThai = 'Đã duyệt'
    GROUP BY tl.MaTL
    ORDER BY tl.NgayDang DESC
    LIMIT 4
");

// Tài liệu quan tâm
$top_docs = $conn->query("
    SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.NamXuatBan, tl.AnhBia,
           dm.TenDanhMuc, pb.TenPhongBan,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    LEFT JOIN phong_ban pb ON tg.MaPB = pb.MaPB
    WHERE tl.TrangThai = 'Đã duyệt'
    GROUP BY tl.MaTL
    ORDER BY tl.SoLuotXem DESC
    LIMIT 4
");

$page_title = "Thư viện số — Đại học Phan Thiết";
include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/home.css">

<div class="home-page">

    <!-- HERO -->
    <section class="home-hero">
        <div class="home-hero-inner">

            <h1 class="home-hero-title">
                THƯ VIỆN SỐ<br>
                TRƯỜNG ĐẠI HỌC PHAN THIẾT
            </h1>

            <p class="home-hero-desc">
                Kho tri thức số phục vụ học tập, nghiên cứu và đổi mới sáng tạo.
            </p>

            <form method="GET" action="<?= $base_url ?>pages/documents/index.php" class="home-search">
                <span class="search-ico"><?= svg_icon('search', '20') ?></span>
                <input type="text" name="q" placeholder="Tìm kiếm tài liệu, tác giả, từ khóa...">
                <button type="submit">Tìm kiếm</button>
            </form>

            <div class="home-quick">
                <a href="<?= $base_url ?>pages/documents/index.php?loai=Khóa%20Luận">
                    <?= svg_icon('graduation', '16') ?>
                    Tài liệu nội sinh
                </a>
                <a href="<?= $base_url ?>pages/documents/index.php">
                    <?= svg_icon('sliders', '16') ?>
                    Tìm kiếm nâng cao
                </a>
                <a href="<?= $base_url ?>pages/documents/authors.php">
                    <?= svg_icon('user-tie', '16') ?>
                    Tác giả
                </a>
            </div>

            <div class="home-stats">
                <div class="home-stat">
                    <div class="home-stat-num"><?= number_format($total_tai_lieu) ?>+</div>
                    <div class="home-stat-lbl">Tài liệu</div>
                </div>
                <div class="home-stat">
                    <div class="home-stat-num"><?= number_format($total_noi_sinh) ?>+</div>
                    <div class="home-stat-lbl">Tài liệu nội sinh</div>
                </div>
                <div class="home-stat">
                    <div class="home-stat-num"><?= number_format($total_tac_gia) ?>+</div>
                    <div class="home-stat-lbl">Tác giả</div>
                </div>
                <div class="home-stat">
                    <div class="home-stat-num"><?= number_format($total_truy_cap) ?>+</div>
                    <div class="home-stat-lbl">Lượt truy cập</div>
                </div>
            </div>

        </div>
    </section>

    <!-- DANH MỤC TÀI LIỆU -->
    <section class="home-categories">
        <div class="home-categories-inner">

            <div class="home-sec-head">
                <div class="home-sec-icon">
                    <?= svg_icon('layers', '20') ?>
                </div>
                <h2 class="home-sec-title">Danh mục tài liệu nội sinh</h2>
            </div>

            <div class="home-cat-grid">
                <?php if ($loai_list && $loai_list->num_rows > 0): ?>
                    <?php while ($loai = $loai_list->fetch_assoc()): ?>
                        <a href="<?= $base_url ?>pages/documents/index.php?loai=<?= urlencode($loai['TenLoai']) ?>" class="home-cat-card">
                            <div class="home-cat-card-icon">
                                <?= svg_icon(icon_for_loai($loai['TenLoai']), '32') ?>
                            </div>
                            <div class="home-cat-card-name"><?= htmlspecialchars($loai['TenLoai']) ?></div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="home-empty" style="grid-column: 1 / -1;">
                        <?= svg_icon('folder-open', '56') ?>
                        <h3>Chưa có danh mục nào</h3>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </section>

    <!-- TÀI LIỆU MỚI CẬP NHẬT -->
    <section class="home-docs alt">
        <div class="home-docs-inner">

            <div class="home-sec-head-row">
                <div class="home-sec-head">
                    <div class="home-sec-icon">
                        <?= svg_icon('clock', '20') ?>
                    </div>
                    <h2 class="home-sec-title">Tài liệu mới cập nhật</h2>
                </div>
                <a href="<?= $base_url ?>pages/documents/index.php?sort=newest" class="home-sec-link">
                    Xem tất cả <?= svg_icon('arrow-right', '14') ?>
                </a>
            </div>

            <div class="home-doc-grid">
                <?php if ($latest_docs && $latest_docs->num_rows > 0): ?>
                    <?php while ($doc = $latest_docs->fetch_assoc()): ?>
                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= urlencode($doc['MaTL']) ?>" class="home-doc-card">
                            <div class="home-doc-cover">
                                <?php if (!empty($doc['AnhBia'])): ?>
                                    <img src="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>&type=cover"
                                         alt="<?= htmlspecialchars($doc['TenTaiLieu']) ?>"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="home-doc-cover-placeholder" style="display:none;">
                                        <?= svg_icon('file-lines', '48') ?>
                                    </div>
                                <?php else: ?>
                                    <div class="home-doc-cover-placeholder">
                                        <?= svg_icon('file-lines', '48') ?>
                                    </div>
                                <?php endif; ?>
                                <span class="home-doc-badge">Nội sinh</span>
                            </div>
                            <div class="home-doc-body">
                                <h3 class="home-doc-title"><?= htmlspecialchars($doc['TenTaiLieu']) ?></h3>
                                <div class="home-doc-meta">
                                    <span>
                                        <?= svg_icon('user', '14') ?>
                                        <?= htmlspecialchars($doc['TenTacGia'] ?? 'Chưa rõ') ?>
                                    </span>
                                    <?php if (!empty($doc['LoaiTaiLieu'])): ?>
                                        <span>
                                            <?= svg_icon('file-lines', '14') ?>
                                            <?= htmlspecialchars($doc['LoaiTaiLieu']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($doc['TenPhongBan'])): ?>
                                        <span>
                                            <?= svg_icon('building', '14') ?>
                                            <?= htmlspecialchars($doc['TenPhongBan']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($doc['NamXuatBan'])): ?>
                                        <span>
                                            <?= svg_icon('calendar', '14') ?>
                                            <?= (int)$doc['NamXuatBan'] ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="home-empty">
                        <?= svg_icon('inbox', '56') ?>
                        <h3>Chưa có tài liệu nào</h3>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </section>

    <!-- TÀI LIỆU ĐƯỢC QUAN TÂM -->
    <section class="home-docs">
        <div class="home-docs-inner">

            <div class="home-sec-head-row">
                <div class="home-sec-head">
                    <div class="home-sec-icon">
                        <?= svg_icon('fire', '20') ?>
                    </div>
                    <h2 class="home-sec-title">Tài liệu được quan tâm</h2>
                </div>
                <a href="<?= $base_url ?>pages/documents/index.php?sort=views" class="home-sec-link">
                    Xem tất cả <?= svg_icon('arrow-right', '14') ?>
                </a>
            </div>

            <div class="home-doc-grid">
                <?php if ($top_docs && $top_docs->num_rows > 0): ?>
                    <?php while ($doc = $top_docs->fetch_assoc()): ?>
                        <a href="<?= $base_url ?>pages/documents/detail.php?id=<?= urlencode($doc['MaTL']) ?>" class="home-doc-card">
                            <div class="home-doc-cover">
                                <?php if (!empty($doc['AnhBia'])): ?>
                                    <img src="<?= $base_url ?>pages/documents/stream.php?id=<?= urlencode($doc['MaTL']) ?>&type=cover"
                                         alt="<?= htmlspecialchars($doc['TenTaiLieu']) ?>"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="home-doc-cover-placeholder" style="display:none;">
                                        <?= svg_icon('file-lines', '48') ?>
                                    </div>
                                <?php else: ?>
                                    <div class="home-doc-cover-placeholder">
                                        <?= svg_icon('file-lines', '48') ?>
                                    </div>
                                <?php endif; ?>
                                <span class="home-doc-badge">Nội sinh</span>
                            </div>
                            <div class="home-doc-body">
                                <h3 class="home-doc-title"><?= htmlspecialchars($doc['TenTaiLieu']) ?></h3>
                                <div class="home-doc-meta">
                                    <span>
                                        <?= svg_icon('user', '14') ?>
                                        <?= htmlspecialchars($doc['TenTacGia'] ?? 'Chưa rõ') ?>
                                    </span>
                                    <?php if (!empty($doc['LoaiTaiLieu'])): ?>
                                        <span>
                                            <?= svg_icon('file-lines', '14') ?>
                                            <?= htmlspecialchars($doc['LoaiTaiLieu']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($doc['TenPhongBan'])): ?>
                                        <span>
                                            <?= svg_icon('building', '14') ?>
                                            <?= htmlspecialchars($doc['TenPhongBan']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($doc['NamXuatBan'])): ?>
                                        <span>
                                            <?= svg_icon('calendar', '14') ?>
                                            <?= (int)$doc['NamXuatBan'] ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="home-empty">
                        <?= svg_icon('inbox', '56') ?>
                        <h3>Chưa có dữ liệu</h3>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </section>

</div>

<?php include "../../includes/footer_public.php"; ?>