<?php
session_start();
require_once "../../connect.php";
require_once "../../includes/auth.php";

check_session_timeout();
try_remember_login($conn);

$base_url     = '/thuvienso/';
$current_page = 'citation';
$page_title   = "Tạo trích dẫn";

// ============================================================
// LẤY DANH SÁCH TÀI LIỆU ĐỂ CHỌN
// ============================================================
$ma_dm_filter = $_GET['ma_dm'] ?? '';
$keyword      = trim($_GET['q'] ?? '');

$where  = "WHERE tl.TrangThai = 'Đã duyệt'";
$params = [];
$types  = "";

if (!empty($ma_dm_filter)) {
    $where   .= " AND tl.MaDM = ?";
    $params[] = $ma_dm_filter;
    $types   .= "s";
}
if (!empty($keyword)) {
    $where   .= " AND (tl.TenTaiLieu LIKE ? OR tl.TuKhoa LIKE ?)";
    $kw = "%$keyword%";
    $params[] = $kw; $params[] = $kw;
    $types   .= "ss";
}

// Danh mục cho filter
$danh_muc_list = $conn->query("SELECT MaDM, TenDanhMuc FROM danh_muc WHERE TrangThai=1 ORDER BY TenDanhMuc");

// Danh sách tài liệu
$sql = "
    SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.NamXuatBan, tl.SoTrang,
           dm.TenDanhMuc,
           GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
    FROM tai_lieu tl
    LEFT JOIN danh_muc dm ON tl.MaDM = dm.MaDM
    LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
    LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
    $where
    GROUP BY tl.MaTL
    ORDER BY tl.NgayDang DESC
    LIMIT 50
";
$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// ============================================================
// HÀM TẠO TRÍCH DẪN — 4 CHUẨN
// ============================================================
function tao_trich_dan(string $chuan, array $doc): string
{
    $tac_gia_raw = $doc['TenTacGia'] ?? '';
    $tac_gia_arr = array_filter(array_map('trim', explode(',', $tac_gia_raw)));
    $nam         = $doc['NamXuatBan'] ?: date('Y');
    $ten         = $doc['TenTaiLieu'];
    $loai        = $doc['LoaiTaiLieu'] ?? 'Tài liệu';
    $url         = "http://localhost:8080/thuvienso/pages/documents/detail.php?id=" . $doc['MaTL'];
    $ngay_truy    = date('d/m/Y');

    // Format tác giả theo từng chuẩn
    switch ($chuan) {

        // ============================================
        // APA 7th: Nguyễn, V. A., & Trần, T. B. (2024). Tên tài liệu. Nhà xuất bản.
        // ============================================
        case 'apa':
            if (empty($tac_gia_arr)) {
                $tac_gia_str = '';
            } else {
                $formatted = [];
                foreach ($tac_gia_arr as $tg) {
                    $parts = explode(' ', trim($tg));
                    $ho    = array_shift($parts);
                    $dem   = implode(' ', $parts);
                    $initial = '';
                    if (!empty($dem)) {
                        $words = explode(' ', $dem);
                        foreach ($words as $w) {
                            $initial .= mb_substr($w, 0, 1) . '. ';
                        }
                    }
                    $formatted[] = $ho . ', ' . trim($initial);
                }
                if (count($formatted) === 1) {
                    $tac_gia_str = $formatted[0];
                } elseif (count($formatted) === 2) {
                    $tac_gia_str = $formatted[0] . ', & ' . $formatted[1];
                } else {
                    $last = array_pop($formatted);
                    $tac_gia_str = implode(', ', $formatted) . ', & ' . $last;
                }
            }
            $tac_gia_str .= ($tac_gia_str ? ' ' : '') . "($nam). ";
            return $tac_gia_str . $ten . ". [{$loai}]. " . $url . ". Truy cập ngày $ngay_truy.";

        // ============================================
        // IEEE: [1] N. V. An, T. T. Binh, "Tên tài liệu," Loại, 2024. [Online]. Available: URL
        // ============================================
        case 'ieee':
            if (empty($tac_gia_arr)) {
                $tac_gia_str = '';
            } else {
                $formatted = [];
                foreach ($tac_gia_arr as $tg) {
                    $parts = explode(' ', trim($tg));
                    $ho    = array_shift($parts);
                    $dem   = implode(' ', $parts);
                    $initial = '';
                    if (!empty($dem)) {
                        $words = explode(' ', $dem);
                        foreach ($words as $w) {
                            $initial .= mb_substr($w, 0, 1) . '. ';
                        }
                    }
                    $formatted[] = trim($initial . ' ' . $ho);
                }
                $tac_gia_str = implode(', ', $formatted) . ', ';
            }
            return $tac_gia_str . "\"{$ten},\" {$loai}, {$nam}. [Online]. Available: {$url}";

        // ============================================
        // MLA 9th: Nguyễn Văn An, và Trần Thị Bình. "Tên tài liệu." Loại, 2024, URL.
        // ============================================
        case 'mla':
            if (empty($tac_gia_arr)) {
                $tac_gia_str = '';
            } elseif (count($tac_gia_arr) === 1) {
                $tac_gia_str = $tac_gia_arr[0] . '. ';
            } elseif (count($tac_gia_arr) === 2) {
                $tac_gia_str = $tac_gia_arr[0] . ', và ' . $tac_gia_arr[1] . '. ';
            } else {
                $tac_gia_str = $tac_gia_arr[0] . ', et al. ';
            }
            return $tac_gia_str . "\"{$ten}.\" {$loai}, {$nam}, {$url}. Truy cập $ngay_truy.";

        // ============================================
        // Chicago 17th: Nguyễn Văn An và Trần Thị Bình. "Tên tài liệu." Loại (2024). URL.
        // ============================================
        case 'chicago':
            if (empty($tac_gia_arr)) {
                $tac_gia_str = '';
            } elseif (count($tac_gia_arr) === 1) {
                $tac_gia_str = $tac_gia_arr[0] . '. ';
            } else {
                $last = array_pop($tac_gia_arr);
                $tac_gia_str = implode(', ', $tac_gia_arr) . ' và ' . $last . '. ';
            }
            return $tac_gia_str . "\"{$ten}.\" {$loai} ({$nam}). {$url}.";

        default:
            return '';
    }
}

// ============================================================
// XỬ LÝ AJAX — trả JSON khi user chọn tài liệu
// ============================================================
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_citation') {
    header('Content-Type: application/json; charset=utf-8');

    $ma_tl = $_GET['ma_tl'] ?? '';
    $stmt = $conn->prepare("
        SELECT tl.MaTL, tl.TenTaiLieu, tl.LoaiTaiLieu, tl.NamXuatBan,
               GROUP_CONCAT(DISTINCT tg.HoTen SEPARATOR ', ') AS TenTacGia
        FROM tai_lieu tl
        LEFT JOIN tailieutacgia tltg ON tl.MaTL = tltg.MaTL
        LEFT JOIN tac_gia tg ON tltg.MaTG = tg.MaTG
        WHERE tl.MaTL = ? AND tl.TrangThai = 'Đã duyệt'
        GROUP BY tl.MaTL
    ");
    $stmt->bind_param("s", $ma_tl);
    $stmt->execute();
    $doc = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$doc) {
        echo json_encode(['ok' => false, 'msg' => 'Không tìm thấy tài liệu']);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'data' => [
            'apa'     => tao_trich_dan('apa', $doc),
            'ieee'    => tao_trich_dan('ieee', $doc),
            'mla'     => tao_trich_dan('mla', $doc),
            'chicago' => tao_trich_dan('chicago', $doc),
        ]
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

include "../../includes/navbar.php";
?>

<link rel="stylesheet" href="<?= $base_url ?>assets/css/user.css">

<style>
    .ct-grid {
        display: grid;
        grid-template-columns: 1fr 1.2fr;
        gap: 24px;
        align-items: start;
    }
    .ct-card {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 24px;
        position: sticky;
        top: 90px;
    }
    .ct-card h3 {
        font-size: 14px;
        font-weight: 800;
        color: #0c1e3e;
        margin: 0 0 18px;
        padding-bottom: 14px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        align-items: center;
        gap: 10px;
        text-transform: uppercase;
        letter-spacing: 0.4px;
    }
    .ct-card h3 i {
        color: #0d9488;
        font-size: 16px;
    }
    .ct-field {
        margin-bottom: 16px;
    }
    .ct-field label {
        display: block;
        font-size: 12px;
        font-weight: 700;
        color: #475569;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    .ct-field input,
    .ct-field select {
        width: 100%;
        padding: 11px 14px;
        border: 1.5px solid #cbd5e1;
        border-radius: 9px;
        font-size: 14px;
        box-sizing: border-box;
        font-family: inherit;
        background: #fff;
        transition: border-color 0.2s;
    }
    .ct-field input:focus,
    .ct-field select:focus {
        outline: none;
        border-color: #0d9488;
        box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.1);
    }
    .ct-btn {
        padding: 12px 22px;
        background: linear-gradient(135deg, #0d9488, #14b8a6);
        color: #fff;
        border: none;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.2s;
        font-family: inherit;
        width: 100%;
    }
    .ct-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(13, 148, 136, 0.3);
    }
    .ct-btn:disabled {
        background: #cbd5e1;
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    .ct-result {
        background: #fff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 24px;
        min-height: 400px;
    }
    .ct-empty {
        text-align: center;
        padding: 80px 20px;
        color: #94a3b8;
    }
    .ct-empty i {
        font-size: 56px;
        color: #cbd5e1;
        display: block;
        margin-bottom: 16px;
    }
    .ct-empty h3 {
        font-size: 15px;
        font-weight: 700;
        color: #475569;
        margin: 0 0 6px;
    }
    .ct-empty p {
        font-size: 13px;
        margin: 0;
    }
    .ct-style {
        margin-bottom: 20px;
        padding: 18px 20px;
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        position: relative;
    }
    .ct-style-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
    }
    .ct-style-label {
        font-size: 11px;
        font-weight: 800;
        color: #0d9488;
        letter-spacing: 1.2px;
        text-transform: uppercase;
    }
    .ct-style-copy {
        padding: 6px 14px;
        background: #fff;
        border: 1.5px solid #cbd5e1;
        border-radius: 7px;
        font-size: 12px;
        font-weight: 600;
        color: #475569;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s;
        font-family: inherit;
    }
    .ct-style-copy:hover {
        background: #0d9488;
        color: #fff;
        border-color: #0d9488;
    }
    .ct-style-copy.copied {
        background: #16a34a;
        color: #fff;
        border-color: #16a34a;
    }
    .ct-style-text {
        font-size: 13.5px;
        color: #1e293b;
        line-height: 1.65;
        padding: 12px 14px;
        background: #fff;
        border-radius: 8px;
        border-left: 3px solid #0d9488;
        word-break: break-word;
    }
    @media (max-width: 900px) {
        .ct-grid { grid-template-columns: 1fr; }
        .ct-card { position: static; }
    }
</style>

<div class="layout-user">
    <?php include "../../includes/sidebar_user.php"; ?>

    <main class="main-user">

        <div class="ud-head">
            <h1>Tạo trích dẫn</h1>
            <p>Tự động tạo trích dẫn tài liệu theo chuẩn APA, IEEE, MLA, Chicago</p>
        </div>

        <div class="ct-grid">

            <!-- BỘ CHỌN TÀI LIỆU -->
            <div class="ct-card">
                <h3><i class="fa-solid fa-magnifying-glass"></i> Chọn tài liệu</h3>

                <div class="ct-field">
                    <label>Tìm kiếm</label>
                    <input type="text" id="ctSearch" placeholder="Nhập tên tài liệu, từ khóa..."
                           value="<?= htmlspecialchars($keyword) ?>">
                </div>

                <div class="ct-field">
                    <label>Danh mục</label>
                    <select id="ctDanhMuc">
                        <option value="">-- Tất cả --</option>
                        <?php $danh_muc_list->data_seek(0); while ($dm = $danh_muc_list->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($dm['MaDM']) ?>"
                                <?= $ma_dm_filter === $dm['MaDM'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($dm['TenDanhMuc']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="ct-field">
                    <label>Chọn tài liệu cần trích dẫn</label>
                    <select id="ctDoc" size="10" style="height: auto; min-height: 280px;">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($doc = $result->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($doc['MaTL']) ?>">
                                    <?= htmlspecialchars($doc['TenTaiLieu']) ?>
                                    <?= $doc['NamXuatBan'] ? '(' . $doc['NamXuatBan'] . ')' : '' ?>
                                </option>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <option disabled>Không có tài liệu nào</option>
                        <?php endif; ?>
                    </select>
                </div>

                <button type="button" class="ct-btn" id="ctGenBtn" onclick="generateCitation()">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Tạo trích dẫn
                </button>
            </div>

            <!-- KẾT QUẢ -->
            <div class="ct-result" id="ctResult">
                <div class="ct-empty">
                    <i class="fa-solid fa-quote-right"></i>
                    <h3>Chưa có trích dẫn nào</h3>
                    <p>Chọn 1 tài liệu ở cột bên trái và bấm <b>"Tạo trích dẫn"</b></p>
                </div>
            </div>

        </div>

    </main>
</div>

<script>
const baseUrl = '<?= $base_url ?>';

// Filter tài liệu khi đổi danh mục
document.getElementById('ctDanhMuc').addEventListener('change', function() {
    const ma_dm = this.value;
    const q     = document.getElementById('ctSearch').value.trim();
    const url   = new URL(window.location.href);
    if (ma_dm) url.searchParams.set('ma_dm', ma_dm);
    else       url.searchParams.delete('ma_dm');
    if (q) url.searchParams.set('q', q);
    else   url.searchParams.delete('q');
    window.location.href = url.toString();
});

// Filter tài liệu khi enter ở ô search
document.getElementById('ctSearch').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        document.getElementById('ctDanhMuc').dispatchEvent(new Event('change'));
    }
});

function generateCitation() {
    const ma_tl = document.getElementById('ctDoc').value;
    if (!ma_tl) {
        Swal.fire({
            icon: 'warning',
            title: 'Chưa chọn tài liệu',
            text: 'Vui lòng chọn 1 tài liệu để tạo trích dẫn!',
            confirmButtonColor: '#2563eb'
        });
        return;
    }

    const btn = document.getElementById('ctGenBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang tạo...';

    fetch('<?= $base_url ?>pages/citation/index.php?ajax=get_citation&ma_tl=' + encodeURIComponent(ma_tl))
        .then(r => r.json())
        .then(data => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Tạo trích dẫn';

            if (!data.ok) {
                document.getElementById('ctResult').innerHTML = `
                    <div class="ct-empty">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <h3>Không tìm thấy tài liệu</h3>
                        <p>${data.msg || 'Vui lòng thử lại'}</p>
                    </div>
                `;
                return;
            }

            const styles = [
                { key: 'apa',     label: 'APA 7th Edition' },
                { key: 'ieee',    label: 'IEEE' },
                { key: 'mla',     label: 'MLA 9th Edition' },
                { key: 'chicago', label: 'Chicago 17th Edition' }
            ];

            let html = '';
            styles.forEach((s, idx) => {
                html += `
                    <div class="ct-style">
                        <div class="ct-style-head">
                            <span class="ct-style-label">${s.label}</span>
                            <button type="button" class="ct-style-copy" onclick="copyText(this, 'cite-${idx}')">
                                <i class="fa-regular fa-copy"></i> Sao chép
                            </button>
                        </div>
                        <div class="ct-style-text" id="cite-${idx}">${escapeHtml(data.data[s.key])}</div>
                    </div>
                `;
            });

            document.getElementById('ctResult').innerHTML = html;
        })
        .catch(err => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Tạo trích dẫn';
            console.error(err);
            alert('Có lỗi xảy ra, vui lòng thử lại!');
        });
}

function copyText(btn, id) {
    const text = document.getElementById(id).textContent;
    navigator.clipboard.writeText(text).then(() => {
        btn.classList.add('copied');
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Đã chép!';
        setTimeout(() => {
            btn.classList.remove('copied');
            btn.innerHTML = '<i class="fa-regular fa-copy"></i> Sao chép';
        }, 1800);
    }).catch(() => {
        alert('Không thể sao chép, vui lòng copy thủ công!');
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php include "../../includes/footer_public.php"; ?>