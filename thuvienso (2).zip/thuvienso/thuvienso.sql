-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Oct 19, 2026 at 06:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thuvienso`
--

-- --------------------------------------------------------

--
-- Table structure for table `cau_hinh`
--

CREATE TABLE `cau_hinh` (
  `MaCH` int(11) NOT NULL,
  `Khoa` varchar(100) NOT NULL,
  `GiaTri` text DEFAULT NULL,
  `Nhom` varchar(50) DEFAULT 'chung',
  `MoTa` varchar(255) DEFAULT NULL,
  `NgayCapNhat` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cau_hinh`
--

INSERT INTO `cau_hinh` (`MaCH`, `Khoa`, `GiaTri`, `Nhom`, `MoTa`, `NgayCapNhat`) VALUES
(1, 'site_name', 'Thư viện số', 'chung', 'Tên website', '2026-10-15 14:08:31'),
(2, 'site_short', 'TVS', 'chung', 'Tên viết tắt', '2026-10-15 14:08:31'),
(3, 'site_slogan', '', 'chung', 'Slogan', '2026-10-15 14:08:31'),
(4, 'site_desc', '', 'chung', 'Mô tả website', '2026-10-15 14:08:31'),
(5, 'site_logo', 'assets/images/logo.svg', 'chung', 'Logo', '2026-10-15 14:08:31'),
(6, 'site_favicon', 'assets/images/logo.svg', 'chung', 'Favicon', '2026-10-15 14:08:31'),
(7, 'contact_email', '', 'lien_he', 'Email liên hệ', '2026-10-15 14:08:31'),
(8, 'contact_hotline', '', 'lien_he', 'Hotline', '2026-10-15 14:08:31'),
(9, 'contact_address', '', 'lien_he', 'Địa chỉ', '2026-10-15 14:08:31'),
(10, 'contact_website', '', 'lien_he', 'Website trường', '2026-10-15 14:08:31'),
(11, 'contact_facebook', '', 'lien_he', 'Facebook', '2026-10-15 14:08:31'),
(12, 'contact_youtube', '', 'lien_he', 'YouTube', '2026-10-15 14:08:31'),
(13, 'contact_copyright', '© 2026 Thư viện số', 'lien_he', 'Copyright', '2026-10-15 14:08:31'),
(14, 'smtp_host', '', 'smtp', 'SMTP Host', '2026-10-15 14:08:31'),
(15, 'smtp_port', '587', 'smtp', 'SMTP Port', '2026-10-15 14:08:31'),
(16, 'smtp_user', '', 'smtp', 'SMTP Username', '2026-10-15 14:08:31'),
(17, 'smtp_pass', '', 'smtp', 'SMTP Password', '2026-10-15 14:08:31'),
(18, 'smtp_encryption', 'TLS', 'smtp', 'Encryption: TLS/SSL', '2026-10-15 14:08:31'),
(19, 'smtp_from_email', '', 'smtp', 'From Email', '2026-10-15 14:08:31'),
(20, 'smtp_from_name', '', 'smtp', 'From Name', '2026-10-15 14:08:31'),
(21, 'seo_title', '', 'seo', 'SEO Title', '2026-10-15 14:08:31'),
(22, 'seo_description', '', 'seo', 'Meta Description', '2026-10-15 14:08:31'),
(23, 'seo_keywords', '', 'seo', 'Meta Keywords', '2026-10-15 14:08:31'),
(24, 'seo_ga_id', '', 'seo', 'Google Analytics ID', '2026-10-15 14:08:31'),
(25, 'lib_per_page', '15', 'thu_vien', 'Số tài liệu/trang', '2026-10-15 14:41:15'),
(26, 'lib_allow_download', '0', 'thu_vien', 'Cho phép tải xuống', '2026-10-15 14:41:27'),
(27, 'lib_allow_register', '1', 'thu_vien', 'Cho phép tự đăng ký', '2026-10-15 14:08:31'),
(28, 'lib_approval_mode', 'auto', 'thu_vien', 'Chế độ duyệt tài liệu', '2026-10-15 14:08:31'),
(29, 'lib_preview_pages', '20', 'thu_vien', 'Số trang xem trước PDF', '2026-10-15 14:08:31'),
(238, 'ai_api_key', 'AQ.Ab8RN6JXk88rgSRmDwdKt8ujKVMWkWcLVwtg3bSmG6s6WvMiIw', 'ai', NULL, '2026-10-15 17:18:26'),
(239, 'ai_enabled', '1', 'ai', NULL, '2026-10-15 17:18:38'),
(240, 'ai_voice_enabled', '0', 'ai', NULL, '2026-10-15 17:18:38'),
(241, 'ai_provider', 'Google Gemini', 'ai', NULL, '2026-10-15 17:18:38'),
(242, 'ai_model', 'gemini-3.5-flash-lite', 'ai', NULL, '2026-10-15 17:18:38');

-- --------------------------------------------------------

--
-- Table structure for table `danh_muc`
--

CREATE TABLE `danh_muc` (
  `MaDM` varchar(10) NOT NULL,
  `TenDanhMuc` varchar(150) NOT NULL,
  `MaDMCha` varchar(10) DEFAULT NULL,
  `MoTa` text DEFAULT NULL,
  `Icon` varchar(100) DEFAULT NULL,
  `ThuTu` int(11) DEFAULT 0,
  `TrangThai` tinyint(4) DEFAULT 1,
  `NgayTao` datetime DEFAULT current_timestamp(),
  `NgayCapNhat` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `danh_muc`
--

INSERT INTO `danh_muc` (`MaDM`, `TenDanhMuc`, `MaDMCha`, `MoTa`, `Icon`, `ThuTu`, `TrangThai`, `NgayTao`, `NgayCapNhat`) VALUES
('DM001', 'Lập trình', NULL, 'devdevfevfevf', NULL, 0, 1, '2026-10-07 10:55:58', '2026-10-07 10:55:58'),
('DM002', 'CNTT', NULL, 'Tài liệu về lập trình từ cơ bản đến nâng cao', NULL, 0, 1, '2026-10-09 20:30:31', '2026-10-09 20:30:31');

-- --------------------------------------------------------

--
-- Table structure for table `lichsudoc`
--

CREATE TABLE `lichsudoc` (
  `MaLS` int(11) NOT NULL,
  `MaND` varchar(15) NOT NULL,
  `MaTL` varchar(15) NOT NULL,
  `HanhDong` varchar(20) DEFAULT 'xem',
  `ThoiGian` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lichsudoc`
--

INSERT INTO `lichsudoc` (`MaLS`, `MaND`, `MaTL`, `HanhDong`, `ThoiGian`) VALUES
(10, 'ND1791373500', 'TL1791184887', 'xem', '2026-10-07 09:03:34'),
(12, 'ND1790581637', 'TL1791381435', 'xem', '2026-10-08 15:24:14'),
(13, 'ND1790581637', 'TL1791381435', 'tai', '2026-10-08 15:24:30'),
(14, 'ND1790581637', 'TL1791381435', 'xem', '2026-10-08 15:30:24'),
(15, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-08 15:43:17'),
(16, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-08 15:43:19'),
(17, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-08 15:44:27'),
(18, 'ND1790581637', 'TL1791381435', 'xem', '2026-10-08 15:52:55'),
(19, 'ND1791373500', 'TL1791448468', 'xem', '2026-10-08 18:18:06'),
(20, 'ND1791373500', 'TL1791448468', 'xem', '2026-10-08 18:18:11'),
(21, 'ND1791373500', 'TL1791448468', 'xem', '2026-10-08 18:18:12'),
(22, 'ND001', 'TL08484A2EC8', 'xem', '2026-10-12 12:40:47'),
(23, 'ND001', 'TL08484A2EC8', 'xem', '2026-10-12 12:40:48'),
(24, 'ND001', 'TL08484A2EC8', 'xem', '2026-10-12 12:45:08'),
(25, 'ND001', 'TL08484A2EC8', 'xem', '2026-10-12 12:45:45'),
(26, 'ND1790581637', 'TL5681BDF6EC', 'xem', '2026-10-12 14:03:13'),
(27, 'ND1790581637', 'TL5681BDF6EC', 'xem', '2026-10-12 14:03:15'),
(28, 'ND1790581637', 'TL5681BDF6EC', 'xem', '2026-10-12 14:55:31'),
(29, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-12 14:55:38'),
(30, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-12 15:00:49'),
(31, 'ND1790581637', 'TL5681BDF6EC', 'xem', '2026-10-12 15:12:22'),
(32, 'ND1790581637', 'TL1791448468', 'xem', '2026-10-12 15:38:14'),
(33, 'ND001', 'TL5681BDF6EC', 'xem', '2026-10-12 16:10:54'),
(34, 'ND001', 'TL5681BDF6EC', 'xem', '2026-10-12 16:11:42'),
(35, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:39'),
(36, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:42'),
(37, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:42'),
(38, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:43'),
(39, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:48'),
(40, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:50'),
(41, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:50'),
(42, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:50'),
(43, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:50'),
(44, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:12:50'),
(45, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:15:00'),
(46, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:15:23'),
(47, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:15:28'),
(48, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:15:32'),
(49, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:15'),
(50, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:18'),
(51, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:19'),
(52, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:27'),
(53, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:31'),
(54, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:32'),
(55, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:45'),
(56, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:19:47'),
(57, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:20:06'),
(58, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:20:45'),
(59, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:20:57'),
(60, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:27:04'),
(61, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:27:06'),
(62, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:27:07'),
(63, 'ND1790581637', 'TLE52E776E18', 'xem', '2026-10-12 16:27:07'),
(64, 'ND001', 'TL32158289BB', 'xem', '2026-10-15 14:03:23'),
(65, 'ND1790581637', 'TL1791381435', 'xem', '2026-10-15 15:49:07');

-- --------------------------------------------------------

--
-- Table structure for table `loaitailieu`
--

CREATE TABLE `loaitailieu` (
  `MaLoai` varchar(10) NOT NULL,
  `TenLoai` varchar(100) NOT NULL,
  `Slug` varchar(100) DEFAULT NULL,
  `MoTa` text DEFAULT NULL,
  `ThuTu` int(11) DEFAULT 0,
  `TrangThai` tinyint(1) NOT NULL DEFAULT 1,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loaitailieu`
--

INSERT INTO `loaitailieu` (`MaLoai`, `TenLoai`, `Slug`, `MoTa`, `ThuTu`, `TrangThai`, `NgayTao`) VALUES
('LT001', 'Khóa Luận', '', 'Khóa luận tốt nghiệp', 1, 0, '2026-10-01 14:31:09'),
('LT002', 'Luận Văn', 'luận-văn', 'Luận văn thạc sĩ', 2, 1, '2026-10-01 14:31:09'),
('LT003', 'Đề Tài NCKH', 'đề-tài-nckh', 'Đề tài nghiên cứu khoa học', 3, 1, '2026-10-01 14:31:09'),
('LT004', 'Giáo Trình', 'giao-trình', 'Giáo trình giảng dạy', 4, 1, '2026-10-01 14:31:09'),
('LT005', 'Bài Báo', 'bài-bao', 'Bài báo khoa học', 5, 1, '2026-10-01 14:31:09'),
('LT006', 'Kỷ Yếu', 'kỷ-yếu', 'Kỷ yếu hội thảo', 6, 1, '2026-10-01 14:31:09');

-- --------------------------------------------------------

--
-- Table structure for table `luot_truy_cap`
--

CREATE TABLE `luot_truy_cap` (
  `MaLog` int(11) NOT NULL,
  `MaND` varchar(15) DEFAULT NULL,
  `IPAddress` varchar(45) DEFAULT NULL,
  `UserAgent` varchar(255) DEFAULT NULL,
  `TrangTruyCap` varchar(255) DEFAULT NULL,
  `ThoiGian` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `luot_truy_cap`
--

INSERT INTO `luot_truy_cap` (`MaLog`, `MaND`, `IPAddress`, `UserAgent`, `TrangTruyCap`, `ThoiGian`) VALUES
(1, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 14:03:19'),
(2, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/documents/detail.php?id=TL32158289BB', '2026-10-15 14:03:23'),
(3, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 15:47:22'),
(4, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/dashboard/index.php', '2026-10-15 15:48:26'),
(5, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/documents/index.php', '2026-10-15 15:48:28'),
(6, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/documents/authors.php', '2026-10-15 15:48:34'),
(7, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/documents/detail.php?id=TL1791381435', '2026-10-15 15:49:07'),
(8, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 15:56:27'),
(9, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 16:21:56'),
(10, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 16:23:12'),
(11, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 16:24:21'),
(12, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 16:24:36'),
(13, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 16:36:50'),
(14, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 17:18:19'),
(15, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-15 17:18:57'),
(16, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '/thuvienso/pages/dashboard/index.php', '2026-10-15 17:22:46'),
(17, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-18 20:39:24'),
(18, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-19 11:29:17'),
(19, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/index.php?q=english', '2026-10-19 11:29:32'),
(20, 'ND001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-19 11:30:04'),
(21, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-19 11:30:48'),
(22, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/index.php', '2026-10-19 11:31:04'),
(23, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/authors.php', '2026-10-19 11:31:05'),
(24, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/departments.php', '2026-10-19 11:31:07'),
(25, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/dashboard/index.php', '2026-10-19 11:31:47'),
(26, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-19 11:31:52'),
(27, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/profile/index.php', '2026-10-19 11:31:56'),
(28, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/profile/history.php', '2026-10-19 11:31:59'),
(29, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/index.php', '2026-10-19 11:32:02'),
(30, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/favorites/index.php', '2026-10-19 11:32:08'),
(31, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/citation/index.php', '2026-10-19 11:32:14'),
(32, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/submission/index.php', '2026-10-19 11:32:19'),
(33, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/dashboard/index.php', '2026-10-19 11:32:22'),
(34, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/favorites/index.php', '2026-10-19 11:34:23'),
(35, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/index.php', '2026-10-19 11:34:25'),
(36, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/home/index.php', '2026-10-19 11:34:28'),
(37, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/authors.php', '2026-10-19 11:34:30'),
(38, 'ND1790581637', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '/thuvienso/pages/documents/departments.php', '2026-10-19 11:34:31');

-- --------------------------------------------------------

--
-- Table structure for table `namhoc`
--

CREATE TABLE `namhoc` (
  `MaNam` varchar(10) NOT NULL,
  `TenNam` varchar(50) NOT NULL,
  `NamBatDau` int(11) DEFAULT NULL,
  `NamKetThuc` int(11) DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `namhoc`
--

INSERT INTO `namhoc` (`MaNam`, `TenNam`, `NamBatDau`, `NamKetThuc`, `NgayTao`) VALUES
('NH001', 'Năm học 2023-2024', 2023, 2024, '2026-10-01 14:31:09'),
('NH002', 'Năm học 2024-2025', 2024, 2025, '2026-10-01 14:31:09'),
('NH003', 'Năm học 2022-2023', 2000, 2001, '2026-10-09 20:34:29');

-- --------------------------------------------------------

--
-- Table structure for table `nganh`
--

CREATE TABLE `nganh` (
  `MaNganh` varchar(10) NOT NULL,
  `TenNganh` varchar(100) NOT NULL,
  `MaPB` varchar(10) DEFAULT NULL,
  `Slug` varchar(100) DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nganh`
--

INSERT INTO `nganh` (`MaNganh`, `TenNganh`, `MaPB`, `Slug`, `NgayTao`) VALUES
('N3A17DEC5C', 'Công nghệ thông tin', 'PB001', NULL, '2026-10-15 13:36:17'),
('NAF88A8536', 'Kỹ thuật', 'PB005', 'ky-thuat', '2026-10-15 13:40:38');

-- --------------------------------------------------------

--
-- Table structure for table `nguoidung`
--

CREATE TABLE `nguoidung` (
  `MaND` varchar(15) NOT NULL,
  `HoTen` varchar(150) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `MatKhau` varchar(255) NOT NULL,
  `MaVaiTro` varchar(10) NOT NULL,
  `MaPB` varchar(10) DEFAULT NULL,
  `MaSo` varchar(30) DEFAULT NULL,
  `SoDienThoai` varchar(20) DEFAULT NULL,
  `TrangThai` tinyint(4) DEFAULT 1,
  `NgayTao` datetime DEFAULT current_timestamp(),
  `LastLogin` datetime DEFAULT NULL,
  `NgayCapNhat` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ThoiGianDocThongBao` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nguoidung`
--

INSERT INTO `nguoidung` (`MaND`, `HoTen`, `Email`, `MatKhau`, `MaVaiTro`, `MaPB`, `MaSo`, `SoDienThoai`, `TrangThai`, `NgayTao`, `LastLogin`, `NgayCapNhat`, `ThoiGianDocThongBao`) VALUES
('ND001', 'Quản trị viên', 'admin@gmail.com', '$2y$10$nS.6ECcwIgPFfj/idxaVjeS07cBUWRKeJYlZ3qNzp.j944Tl/d7fm', 'ADMIN', NULL, 'ND002', '0901111111', 1, '2026-09-28 14:38:44', '2026-10-19 11:30:03', '2026-10-19 11:30:03', NULL),
('ND1790581637', 'Lê Thị Thu Thúy', 'thuy123@gmail.com', '$2y$10$rhwbscwQKtYp64OZO19/JukFfDHuks.DqM1wNrQnqQO4ySRUWAXdS', 'SV', 'PB001', '', '0344116614', 1, '2026-09-28 14:47:17', '2026-10-19 11:30:48', '2026-10-19 11:30:48', '2026-10-12 17:07:31'),
('ND1791373500', 'Lê Thị Thu Thúy', 'thuthuy200012@gmail.com', '$2y$10$b9WxAEMfyy2lNjoY4bqoY.HclytTuKsRQ9i/ZaejUcyIVAkir6o62', 'SV', NULL, 'K15KDO0024', '0344116614', 1, '2026-10-07 08:45:00', '2026-10-08 18:14:29', '2026-10-08 18:14:29', NULL),
('ND1791376093', 'Hacker Test', 'hacker1@test.com', '$2y$10$8cBepb8oCDhs6XV9jSH.xemgUyCUMuPyf3MBmlhtup5w8xjcs2p7O', 'SV', NULL, '', '', 1, '2026-10-07 09:28:13', NULL, '2026-10-07 09:34:22', NULL),
('ND9C8993528E', 'Nguyên B', 'b@gmail.com', '$2y$10$ffZZTXCEppkPIUjvRRASw.FzM7XiYboYaPcWqrhD8iROPXRuOWCTi', 'SV', NULL, '', '', 1, '2026-10-09 13:16:18', NULL, '2026-10-09 13:16:18', NULL),
('TEST_ADMIN', 'Admin Test', 'admin@test.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdBmzVpEDzIYcW3W.', 'ADMIN', NULL, NULL, NULL, 1, '2026-10-07 09:22:21', NULL, '2026-10-07 09:22:21', NULL),
('TEST_SV', 'Sinh viên Test', 'sv@test.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdBmzVpEDzIYcW3W.', 'SV', NULL, NULL, NULL, 1, '2026-10-07 09:22:21', NULL, '2026-10-07 09:22:21', NULL),
('TEST_THUTHU', 'Thủ thư Test', 'thuthu@test.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1HlCS4bZJ18JuywdBmzVpEDzIYcW3W.', 'THUTHU', NULL, NULL, NULL, 1, '2026-10-07 09:22:21', NULL, '2026-10-07 09:22:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `nhatkyhoatdong`
--

CREATE TABLE `nhatkyhoatdong` (
  `MaLog` int(11) NOT NULL,
  `MaND` varchar(50) DEFAULT NULL,
  `HoTen` varchar(100) DEFAULT NULL,
  `HanhDong` varchar(50) NOT NULL,
  `MoTa` varchar(500) DEFAULT NULL,
  `DoiTuong` varchar(50) DEFAULT NULL,
  `MaDoiTuong` varchar(50) DEFAULT NULL,
  `IPAddress` varchar(45) DEFAULT NULL,
  `UserAgent` varchar(500) DEFAULT NULL,
  `ThoiGian` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nhatkyhoatdong`
--

INSERT INTO `nhatkyhoatdong` (`MaLog`, `MaND`, `HoTen`, `HanhDong`, `MoTa`, `DoiTuong`, `MaDoiTuong`, `IPAddress`, `UserAgent`, `ThoiGian`) VALUES
(15, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-07 21:25:49'),
(16, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-07 21:25:58'),
(17, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 14:55:43'),
(18, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:00:27'),
(19, 'ND001', 'Quản trị viên', 'VIEW', 'Xem tài liệu: Giáo trình CNTT', 'tai_lieu', 'TL1791381435', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:19:57'),
(20, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:23:51'),
(21, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:24:02'),
(22, 'ND1790581637', 'Lê Thị Thu Thúy', 'VIEW', 'Xem tài liệu: Giáo trình CNTT', 'tai_lieu', 'TL1791381435', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:24:23'),
(23, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:30:28'),
(24, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:30:38'),
(25, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: wfwf (Mã: TL1791448468, có file PDF)', 'tai_lieu', 'TL1791448468', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:34:28'),
(26, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm danh mục Du Lịch (DM002)', 'danh_muc', 'DM002', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:38:19'),
(27, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật tài liệu TL1791448468 (wfwf)', 'tai_lieu', 'TL1791448468', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:40:02'),
(28, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:41:53'),
(29, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:42:02'),
(30, 'ND1790581637', 'Lê Thị Thu Thúy', 'VIEW', 'Xem tài liệu: Giáo trình CNTT', 'tai_lieu', 'TL1791381435', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:52:59'),
(31, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:53:48'),
(32, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:54:00'),
(33, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: Giáo trình english (Mã: TL1791449856, có file PDF)', 'tai_lieu', 'TL1791449856', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 15:57:36'),
(34, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa tài liệu TL1791449856 (Giáo trình english)', 'tai_lieu', 'TL1791449856', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 16:06:50'),
(35, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa tài liệu TL1791170304 (Giáo trình CNTT)', 'tai_lieu', 'TL1791170304', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 16:08:59'),
(36, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa tài liệu TL1791170832 (wfwf)', 'tai_lieu', 'TL1791170832', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 16:11:53'),
(37, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa danh mục DM002 (Du Lịch)', 'danh_muc', 'DM002', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 16:17:56'),
(38, 'ND1791373500', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 18:14:29'),
(39, 'ND1791459267', 'Lê quốc cường', 'REGISTER', 'Đăng ký tài khoản mới: cuong123@gmail.com', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 18:34:27'),
(40, 'ND1791459267', 'Lê quốc cường', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 18:34:40'),
(41, 'ND1791459267', 'Lê quốc cường', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 18:35:16'),
(42, 'ND1791373500', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-08 19:36:59'),
(43, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 11:50:31'),
(44, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:05:01'),
(45, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:05:33'),
(46, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:06:33'),
(47, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:13:18'),
(48, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:15:58'),
(49, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 12:20:26'),
(50, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:06:01'),
(51, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:09:02'),
(52, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:15:52'),
(53, 'ND9C8993528E', 'Nguyên B', 'REGISTER', 'Đăng ký tài khoản mới: b@gmail.com', NULL, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:16:18'),
(54, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:20:29'),
(55, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa tài khoản ND1791459267 (Lê quốc cường - cuong123@gmail.com)', 'nguoidung', 'ND1791459267', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:21:26'),
(56, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: Giáo trình CNTT (Mã: TL37CE7956BB, có file PDF)', 'tai_lieu', 'TL37CE7956BB', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 13:22:29'),
(57, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa năm học NH004 (Năm học 2026-2027)', 'nam_hoc', 'NH004', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:26:17'),
(58, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa năm học NH003 (Năm học 2025-2026)', 'nam_hoc', 'NH003', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:26:21'),
(59, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa năm học NH005 (Năm học 2022-2023)', 'nam_hoc', 'NH005', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:26:33'),
(60, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa năm học NH005 (NH005)', 'nam_hoc', 'NH005', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:26:37'),
(61, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa khoa/phòng ban PB005 (du)', 'phong_ban', 'PB005', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:27:04'),
(62, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm danh mục CNTT (DM002)', 'danh_muc', 'DM002', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:30:31'),
(63, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm khoa/phòng ban Kỹ thuật (PB005)', 'phong_ban', 'PB005', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:32:14'),
(64, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa khoa/phòng ban PB003 (Khoa Ngoại ngữ)', 'phong_ban', 'PB003', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:32:26'),
(65, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa tác giả TG004 (Lê Thị Ánh)', 'tac_gia', 'TG004', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:34:16'),
(66, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm năm học Năm học 2022-2023 (2000-2001)', 'nam_hoc', 'NH003', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:34:29'),
(67, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: Giáo trình CNTT (Mã: TL8BD73AB385, chưa có file)', 'tai_lieu', 'TL8BD73AB385', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:37:37'),
(68, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: Tài liệu năm 2025 (Mã: TL08484A2EC8, chưa có file)', 'tai_lieu', 'TL08484A2EC8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:38:28'),
(69, 'ND001', 'Quản trị viên', 'CREATE', 'Nộp tài liệu: Giáo trình english (Mã: TL5681BDF6EC)', 'tai_lieu', 'TL5681BDF6EC', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 12:53:27'),
(70, 'ND001', 'Quản trị viên', 'UPDATE', 'Duyệt tài liệu TL5681BDF6EC (Giáo trình english)', 'tai_lieu', 'TL5681BDF6EC', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 12:53:59'),
(71, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 13:00:37'),
(72, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 13:02:18'),
(73, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 13:06:07'),
(74, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 14:02:28'),
(75, 'ND1790581637', 'Lê Thị Thu Thúy', 'CREATE', 'Nộp tài liệu: Tài liệu năm 2024 (Mã: TLE52E776E18)', 'tai_lieu', 'TLE52E776E18', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:10:00'),
(76, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:10:14'),
(77, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:10:24'),
(78, 'ND001', 'Quản trị viên', 'UPDATE', 'Duyệt tài liệu TLE52E776E18 (Tài liệu năm 2024)', 'tai_lieu', 'TLE52E776E18', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:11:20'),
(79, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:12:18'),
(80, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:12:30'),
(81, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:27:52'),
(82, 'ND1790581637', 'Lê Thị Thu Thúy', 'CREATE', 'Nộp tài liệu: test (Mã: TL32158289BB)', 'tai_lieu', 'TL32158289BB', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:48:31'),
(83, 'ND001', 'Quản trị viên', 'UPDATE', 'Duyệt tài liệu TL32158289BB (test)', 'tai_lieu', 'TL32158289BB', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 16:50:53'),
(84, 'ND001', 'Quản trị viên', 'CREATE', 'Import tài liệu từ file: mau_import_tai_lieu_20261012.xlsx - Thành công: 0, Lỗi: 2', 'tai_lieu', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 17:04:57'),
(85, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-12 17:07:39'),
(86, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:03:33'),
(87, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật thể loại: Khóa Luận (LT001)', 'loaitailieu', 'LT001', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:19:15'),
(88, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm thể loại: HH (L315E5F3877)', 'loaitailieu', 'L315E5F3877', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:19:37'),
(89, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật thể loại: HH (L315E5F387)', 'loaitailieu', 'L315E5F387', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:19:44'),
(90, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật thể loại: HH (L315E5F387)', 'loaitailieu', 'L315E5F387', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:22:25'),
(91, 'ND001', 'Quản trị viên', 'DELETE', 'Xóa thể loại: HH (L315E5F387)', 'loaitailieu', 'L315E5F387', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:23:01'),
(92, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm ngành: CNTT (N3A17DEC5C5)', 'nganh', 'N3A17DEC5C5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:36:17'),
(93, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm ngành: Kỹ thuật (NAF88A8536D)', 'nganh', 'NAF88A8536D', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:40:38'),
(94, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: wfwf (Mã: TL53578D9FBA, chưa có file)', 'tai_lieu', 'TL53578D9FBA', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:47:32'),
(95, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật phân quyền', 'vai_tro_quyen', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:57:20'),
(96, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật phân quyền', 'vai_tro_quyen', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 13:57:23'),
(97, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: Tài liệu năm 2024 (Mã: TL26A241149D, chưa có file)', 'tai_lieu', 'TL26A241149D', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:14:37'),
(98, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: xdwdw (Mã: TLBA7D859181, chưa có file)', 'tai_lieu', 'TLBA7D859181', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:14:47'),
(99, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: ữdwwcwc (Mã: TL32E70AD5BA, chưa có file)', 'tai_lieu', 'TL32E70AD5BA', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:14:58'),
(100, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả aaa (TG011)', 'tac_gia', 'TG011', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:21:49'),
(101, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả c (TG012)', 'tac_gia', 'TG012', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:21:54'),
(102, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả v (TG013)', 'tac_gia', 'TG013', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:21:58'),
(103, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả d (TG014)', 'tac_gia', 'TG014', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:21:59'),
(104, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả f (TG015)', 'tac_gia', 'TG015', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:22:01'),
(105, 'ND001', 'Quản trị viên', 'CREATE', 'Thêm tác giả e (TG016)', 'tac_gia', 'TG016', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:22:05'),
(106, 'ND001', 'Quản trị viên', 'DELETE', 'Bulk xóa 6 tác giả: TG016, TG015, TG014, TG013, TG012... (và 1 tác giả khác)', 'tac_gia', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:22:23'),
(107, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: a (Mã: TLC5F0393A25, chưa có file)', 'tai_lieu', 'TLC5F0393A25', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:24:08'),
(108, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: b (Mã: TLA5175219C5, chưa có file)', 'tai_lieu', 'TLA5175219C5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:24:19'),
(109, 'ND001', 'Quản trị viên', 'CREATE', 'Upload tài liệu: ư (Mã: TL95436DC0BA, chưa có file)', 'tai_lieu', 'TL95436DC0BA', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:24:29'),
(110, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật thể loại: Luận Văn (LT002)', 'loaitailieu', 'LT002', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:32:53'),
(111, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật thể loại: Khóa Luận (LT001)', 'loaitailieu', 'LT001', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:35:03'),
(112, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'thu_vien\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:41:15'),
(113, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'thu_vien\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:41:27'),
(114, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:50:46'),
(115, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:51:31'),
(116, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:57:18'),
(117, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:57:31'),
(118, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:58:56'),
(119, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 14:59:11'),
(120, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:00:42'),
(121, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:03:02'),
(122, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:03:53'),
(123, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:07:40'),
(124, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:47:08'),
(125, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:47:22'),
(126, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:56:17'),
(127, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:56:26'),
(128, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:56:55'),
(129, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:58:10'),
(130, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 15:58:27'),
(131, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:09:06'),
(132, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:09:15'),
(133, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:09:34'),
(134, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:12:08'),
(135, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:21:09'),
(136, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:21:46'),
(137, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:21:56'),
(138, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:23:12'),
(139, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:06'),
(140, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:16'),
(141, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:25'),
(142, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:36'),
(143, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:46'),
(144, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:24:53'),
(145, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:26:12'),
(146, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:28:13'),
(147, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:28:16'),
(148, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:18'),
(149, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:21'),
(150, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:24'),
(151, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:27'),
(152, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:29'),
(153, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:32:50'),
(154, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:33:56'),
(155, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:33:59'),
(156, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:34:18'),
(157, 'ND001', 'Quản trị viên', 'LOGOUT', 'Đăng xuất hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:36:40'),
(158, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:36:50'),
(159, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:37:59'),
(160, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:38:06'),
(161, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:40:02'),
(162, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 16:41:28'),
(163, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 17:18:26'),
(164, 'ND001', 'Quản trị viên', 'UPDATE', 'Cập nhật cấu hình tab \'ai\'', 'cau_hinh', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-15 17:18:38'),
(165, 'ND001', 'Quản trị viên', 'LOGIN', 'Đăng nhập trang quản trị', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 11:30:03'),
(166, 'ND1790581637', 'Lê Thị Thu Thúy', 'LOGIN', 'Đăng nhập hệ thống', '', '', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 11:30:48');

-- --------------------------------------------------------

--
-- Table structure for table `passwordresets`
--

CREATE TABLE `passwordresets` (
  `MaReset` int(11) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Token` varchar(64) NOT NULL,
  `HetHan` datetime NOT NULL,
  `DaSuDung` tinyint(4) DEFAULT 0,
  `IP` varchar(45) DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passwordresets`
--

INSERT INTO `passwordresets` (`MaReset`, `Email`, `Token`, `HetHan`, `DaSuDung`, `IP`, `NgayTao`) VALUES
(2, 'thuthuy200012@gmail.com', '0f5cab2813ed655f49aa95005325f91c291c579304033603679f93f92fcde83c', '2026-10-07 14:01:29', 1, '::1', '2026-10-07 08:46:29');

-- --------------------------------------------------------

--
-- Table structure for table `phienbanfile`
--

CREATE TABLE `phienbanfile` (
  `MaPhienBan` int(11) NOT NULL,
  `MaTL` varchar(15) NOT NULL,
  `TenFile` varchar(255) NOT NULL,
  `DungLuong` int(11) DEFAULT NULL,
  `PhienBan` int(11) DEFAULT 1,
  `GhiChu` text DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phong_ban`
--

CREATE TABLE `phong_ban` (
  `MaPB` varchar(10) NOT NULL,
  `TenPhongBan` varchar(150) NOT NULL,
  `TenVietTat` varchar(30) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `SoDienThoai` varchar(20) DEFAULT NULL,
  `MoTa` text DEFAULT NULL,
  `TrangThai` tinyint(4) DEFAULT 1,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phong_ban`
--

INSERT INTO `phong_ban` (`MaPB`, `TenPhongBan`, `TenVietTat`, `Email`, `SoDienThoai`, `MoTa`, `TrangThai`, `NgayTao`) VALUES
('PB001', 'Khoa Công nghệ thông tin', 'CNTT', 'cntt@thuvienso.edu.vn', '0281234567', NULL, 1, '2026-10-01 12:35:43'),
('PB004', 'Du Lịch', 'đw', 'thuthuy200012@gmail.com', '', NULL, 1, '2026-10-07 10:44:25'),
('PB005', 'Kỹ thuật', 'kt', 'thuthuy200012@gmail.com', '0584773583', NULL, 1, '2026-10-09 20:32:14');

-- --------------------------------------------------------

--
-- Table structure for table `quyen`
--

CREATE TABLE `quyen` (
  `MaQuyen` varchar(50) NOT NULL,
  `TenQuyen` varchar(100) NOT NULL,
  `MoTa` varchar(255) DEFAULT NULL,
  `ThuTu` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quyen`
--

INSERT INTO `quyen` (`MaQuyen`, `TenQuyen`, `MoTa`, `ThuTu`) VALUES
('quan_ly_cau_hinh', 'Quản lý cấu hình', 'Cấu hình hệ thống', 4),
('quan_ly_danh_muc', 'Quản lý danh mục', 'Quản lý danh mục/thể loại', 3),
('quan_ly_nguoi_dung', 'Quản lý người dùng', 'Thêm/sửa/xóa người dùng', 2),
('quan_ly_tai_lieu', 'Quản lý tài liệu', 'Thêm/sửa/xóa tài liệu', 1),
('xem_thong_ke', 'Xem thống kê', 'Xem báo cáo, thống kê', 5);

-- --------------------------------------------------------

--
-- Table structure for table `remember_tokens`
--

CREATE TABLE `remember_tokens` (
  `MaToken` int(11) NOT NULL,
  `MaND` varchar(15) NOT NULL,
  `TokenHash` char(64) NOT NULL,
  `HetHan` datetime NOT NULL,
  `IP` varchar(45) DEFAULT NULL,
  `UserAgent` varchar(500) DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `remember_tokens`
--

INSERT INTO `remember_tokens` (`MaToken`, `MaND`, `TokenHash`, `HetHan`, `IP`, `UserAgent`, `NgayTao`) VALUES
(14, 'ND001', '48642076f9e31e3fbec9b6b67fb611c33a1be5f1c4fcac039e93d92efe38a290', '2026-11-18 11:30:03', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 11:30:03'),
(15, 'ND1790581637', '38af38fec810a0ce859f60f5e3ebed1819c1030fe8a59f10c7eb2048781402bf', '2026-11-18 11:30:48', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 11:30:48');

-- --------------------------------------------------------

--
-- Table structure for table `tac_gia`
--

CREATE TABLE `tac_gia` (
  `MaTG` varchar(10) NOT NULL,
  `HoTen` varchar(150) NOT NULL,
  `MaPB` varchar(10) DEFAULT NULL,
  `HocVi` varchar(100) DEFAULT NULL,
  `ChucVu` varchar(100) DEFAULT NULL,
  `Email` varchar(150) DEFAULT NULL,
  `SoDienThoai` varchar(20) DEFAULT NULL,
  `MoTa` text DEFAULT NULL,
  `TrangThai` tinyint(4) DEFAULT 1,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tac_gia`
--

INSERT INTO `tac_gia` (`MaTG`, `HoTen`, `MaPB`, `HocVi`, `ChucVu`, `Email`, `SoDienThoai`, `MoTa`, `TrangThai`, `NgayTao`) VALUES
('TG001', 'Nguyễn Văn An', 'PB001', 'Thạc sĩ', 'Giảng viênn', 'an@thuvienso.edu.vn', '0901111111', NULL, 1, '2026-10-01 12:35:43'),
('TG002', 'Trần Thị Bình', 'PB001', 'Tiến sĩ', 'Trưởng khoa', 'binh@thuvienso.edu.vn', '0901111112', NULL, 1, '2026-10-01 12:35:43'),
('TG003', 'Nguyễn Văn Ann', 'PB004', 'Thạc sĩ', 'Giảng viênn', 'thuthuy200012@gmail.com', '', NULL, 1, '2026-10-07 10:56:44'),
('TG004', 'Lê Thị Thu', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-12 12:53:27'),
('TG005', 'b', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-12 16:10:00'),
('TG006', 'a', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-12 16:48:31'),
('TG007', 'cswcsw', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 13:47:32'),
('TG008', 'sqsq', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 14:14:37'),
('TG009', 'ữdw', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 14:14:47'),
('TG010', 'wx', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 14:14:58'),
('TG011', 'q', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 14:24:19'),
('TG012', 'ư', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2026-10-15 14:24:29');

-- --------------------------------------------------------

--
-- Table structure for table `tailieutacgia`
--

CREATE TABLE `tailieutacgia` (
  `MaTL` varchar(15) NOT NULL,
  `MaTG` varchar(10) NOT NULL,
  `VaiTro` varchar(50) DEFAULT 'Tác giả'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tailieutacgia`
--

INSERT INTO `tailieutacgia` (`MaTL`, `MaTG`, `VaiTro`) VALUES
('TL08484A2EC8', 'TG002', 'Tác giả'),
('TL1791381435', 'TG002', 'Tác giả'),
('TL1791381435', 'TG003', 'GVHD'),
('TL26A241149D', 'TG008', 'Tác giả'),
('TL32158289BB', 'TG006', 'Tác giả'),
('TL32E70AD5BA', 'TG010', 'Tác giả'),
('TL53578D9FBA', 'TG007', 'Tác giả'),
('TL5681BDF6EC', 'TG002', 'GVHD'),
('TL5681BDF6EC', 'TG004', 'Tác giả'),
('TL8BD73AB385', 'TG002', 'Tác giả'),
('TL95436DC0BA', 'TG012', 'Tác giả'),
('TLA5175219C5', 'TG011', 'Tác giả'),
('TLBA7D859181', 'TG009', 'Tác giả'),
('TLC5F0393A25', 'TG006', 'Tác giả'),
('TLE52E776E18', 'TG005', 'Tác giả');

-- --------------------------------------------------------

--
-- Table structure for table `tai_lieu`
--

CREATE TABLE `tai_lieu` (
  `MaTL` varchar(15) NOT NULL,
  `TenTaiLieu` varchar(255) NOT NULL,
  `MaTG` varchar(10) DEFAULT NULL,
  `MaDM` varchar(10) DEFAULT NULL,
  `MaNganh` varchar(10) DEFAULT NULL,
  `MaNam` varchar(20) DEFAULT NULL,
  `MaND` varchar(15) DEFAULT NULL,
  `LoaiTaiLieu` varchar(100) DEFAULT NULL,
  `NamXuatBan` year(4) DEFAULT NULL,
  `SoTrang` int(11) DEFAULT NULL,
  `SoTrangDuocXem` int(11) DEFAULT 0,
  `NgonNgu` varchar(50) DEFAULT NULL,
  `TomTat` text DEFAULT NULL,
  `NoiDungVanBan` longtext DEFAULT NULL,
  `NoiDungText` longtext DEFAULT NULL,
  `TuKhoa` text DEFAULT NULL,
  `FileTaiLieu` varchar(255) DEFAULT NULL,
  `AnhBia` varchar(255) DEFAULT NULL,
  `SoLuotXem` int(11) DEFAULT 0,
  `SoLuotTai` int(11) DEFAULT 0,
  `TrangThai` varchar(30) DEFAULT 'Chờ duyệt',
  `MucTruyCap` varchar(20) DEFAULT 'Công khai',
  `LyDoTuChoi` text DEFAULT NULL,
  `NgayDuyet` datetime DEFAULT NULL,
  `NgayDang` datetime DEFAULT current_timestamp(),
  `NgayCapNhat` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tai_lieu`
--

INSERT INTO `tai_lieu` (`MaTL`, `TenTaiLieu`, `MaTG`, `MaDM`, `MaNganh`, `MaNam`, `MaND`, `LoaiTaiLieu`, `NamXuatBan`, `SoTrang`, `SoTrangDuocXem`, `NgonNgu`, `TomTat`, `NoiDungVanBan`, `NoiDungText`, `TuKhoa`, `FileTaiLieu`, `AnhBia`, `SoLuotXem`, `SoLuotTai`, `TrangThai`, `MucTruyCap`, `LyDoTuChoi`, `NgayDuyet`, `NgayDang`, `NgayCapNhat`) VALUES
('TL08484A2EC8', 'Tài liệu năm 2025', NULL, 'DM001', NULL, NULL, 'ND001', 'Đề tài NCKH', '2026', 0, 0, 'Tiếng Việt', '', NULL, NULL, '', NULL, NULL, 1, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-09 20:38:28', '2026-10-09 20:38:28', '2026-10-15 15:24:53'),
('TL1791381435', 'Giáo trình CNTT', NULL, 'DM001', 'N3A17DEC5C', NULL, 'ND001', 'Luận văn', '2026', 0, 0, 'Tiếng Việt', 'scs', NULL, NULL, '', 'uploads/documents/TL1791381435_1791448310.pdf', NULL, 3, 1, 'Đã duyệt', 'Công khai', NULL, '2026-10-07 10:57:15', '2026-10-07 10:57:15', '2026-10-15 15:49:07'),
('TL1791448468', 'wfwf', NULL, 'DM001', NULL, NULL, 'ND001', 'Luận văn', '2027', 0, 0, 'Tiếng Việt', 'rfhyedhyeegegeehh', NULL, NULL, '', 'uploads/documents/TL1791448468_1791448468.pdf', 'uploads/covers/cover_TL1791448468_1791448802.png', 3, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-08 15:34:28', '2026-10-08 15:34:28', '2026-10-15 15:24:53'),
('TL205', 'Tài liệu năm 2025', NULL, 'DM001', NULL, NULL, NULL, 'Giáo trình', '2025', 0, 0, '', '', NULL, NULL, '', 'uploads/documents/TL205_1791448274.pdf', NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, NULL, '2026-10-05 14:10:34', '2026-10-15 15:40:28'),
('TL26A241149D', 'Tài liệu năm 2024', NULL, 'DM002', NULL, NULL, 'ND001', 'Kỷ yếu', '2026', 0, 0, 'Tiếng Việt', 'ứdwd', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:14:37', '2026-10-15 14:14:37', '2026-10-15 15:40:28'),
('TL32158289BB', 'test', NULL, 'DM002', NULL, 'NH002', 'ND1790581637', 'Luận văn', '2026', 0, 0, 'Tiếng Việt', 'bdcbdbdbg', NULL, NULL, '', NULL, NULL, 1, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-12 16:50:53', '2026-10-12 16:48:31', '2026-10-15 15:24:53'),
('TL32E70AD5BA', 'ữdwwcwc', NULL, 'DM001', NULL, NULL, 'ND001', 'Luận văn', '2026', 0, 0, 'Tiếng Việt', 'ucwc', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:14:58', '2026-10-15 14:14:58', '2026-10-15 15:24:53'),
('TL37CE7956BB', 'Giáo trình CNTT', NULL, 'DM001', 'N3A17DEC5C', NULL, 'ND001', 'Luận văn', '2000', 0, 0, 'Tiếng Việt', 'fcfvgh', NULL, NULL, '', 'uploads/documents/TL37CE7956BB_1791526949.pdf', NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-09 13:22:29', '2026-10-09 13:22:29', '2026-10-15 15:31:33'),
('TL53578D9FBA', 'wfwf', NULL, 'DM002', 'NAF88A8536', NULL, 'ND001', '', '2026', 0, 0, 'Tiếng Việt', 'dxswd', NULL, NULL, 'Ngoại Ngữ', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 13:47:32', '2026-10-15 13:47:32', '2026-10-15 13:47:32'),
('TL5681BDF6EC', 'Giáo trình english', NULL, 'DM001', NULL, NULL, 'ND001', 'Luận văn', '2021', 0, 0, 'Tiếng Việt', 'rgrgedg', NULL, NULL, 'Giáo trình CNTT', 'uploads/documents/TL5681BDF6EC_1791784407.pdf', NULL, 2, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-12 12:53:59', '2026-10-12 12:53:27', '2026-10-15 15:24:53'),
('TL8BD73AB385', 'Giáo trình CNTT', NULL, 'DM002', 'N3A17DEC5C', NULL, 'ND001', 'Luận văn', '2026', 0, 0, 'Tiếng Việt', 'ưad', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-09 20:37:37', '2026-10-09 20:37:37', '2026-10-15 15:31:33'),
('TL95436DC0BA', 'ư', NULL, 'DM002', NULL, NULL, 'ND001', '', '2026', 0, 0, 'Tiếng Việt', '', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:24:29', '2026-10-15 14:24:29', '2026-10-15 14:24:29'),
('TLA5175219C5', 'b', NULL, 'DM002', NULL, NULL, 'ND001', '', '2026', 0, 0, 'Tiếng Việt', '', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:24:19', '2026-10-15 14:24:19', '2026-10-15 14:24:19'),
('TLBA7D859181', 'xdwdw', NULL, 'DM001', 'NAF88A8536', NULL, 'ND001', '', '2026', 0, 0, 'Tiếng Việt', 'ww', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:14:47', '2026-10-15 14:14:47', '2026-10-15 14:14:47'),
('TLC5F0393A25', 'a', NULL, 'DM002', NULL, NULL, 'ND001', '', '2026', 0, 0, 'Tiếng Việt', '', NULL, NULL, '', NULL, NULL, 0, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-15 14:24:08', '2026-10-15 14:24:08', '2026-10-15 14:24:08'),
('TLE52E776E18', 'Tài liệu năm 2024', NULL, 'DM002', NULL, NULL, 'ND1790581637', 'Luận văn', '2024', 0, 0, 'Tiếng Việt', 'aaaaaaaaa', NULL, NULL, '', NULL, NULL, 1, 0, 'Đã duyệt', 'Công khai', NULL, '2026-10-12 16:11:20', '2026-10-12 16:10:00', '2026-10-15 15:24:53');

-- --------------------------------------------------------

--
-- Table structure for table `tukhoa`
--

CREATE TABLE `tukhoa` (
  `MaTK` varchar(10) NOT NULL,
  `TenTuKhoa` varchar(150) NOT NULL,
  `SoLanDung` int(11) DEFAULT 0,
  `MoTa` text DEFAULT NULL,
  `NgayTao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tukhoa`
--

INSERT INTO `tukhoa` (`MaTK`, `TenTuKhoa`, `SoLanDung`, `MoTa`, `NgayTao`) VALUES
('TK001', 'Công nghệ thông tin', 0, NULL, '2026-10-01 14:31:09'),
('TK006', 'Ngoại ngữ', 0, NULL, '2026-10-01 14:31:09');

-- --------------------------------------------------------

--
-- Table structure for table `vaitro`
--

CREATE TABLE `vaitro` (
  `MaVaiTro` varchar(10) NOT NULL,
  `TenVaiTro` varchar(50) NOT NULL,
  `MoTa` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaitro`
--

INSERT INTO `vaitro` (`MaVaiTro`, `TenVaiTro`, `MoTa`) VALUES
('ADMIN', 'Quản trị viên', 'Quản lý hệ thống'),
('GV', 'Giảng viên', 'Giảng viên'),
('SV', 'Sinh viên', 'Sinh viên'),
('THUTHU', 'Thủ thư', 'Quản lý thư viện');

-- --------------------------------------------------------

--
-- Table structure for table `vai_tro_quyen`
--

CREATE TABLE `vai_tro_quyen` (
  `MaVaiTro` varchar(20) NOT NULL,
  `MaQuyen` varchar(50) NOT NULL,
  `ChoPhep` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vai_tro_quyen`
--

INSERT INTO `vai_tro_quyen` (`MaVaiTro`, `MaQuyen`, `ChoPhep`) VALUES
('ADMIN', 'quan_ly_cau_hinh', 1),
('ADMIN', 'quan_ly_danh_muc', 1),
('ADMIN', 'quan_ly_nguoi_dung', 1),
('ADMIN', 'quan_ly_tai_lieu', 1),
('ADMIN', 'xem_thong_ke', 1),
('THUTHU', 'quan_ly_danh_muc', 1),
('THUTHU', 'quan_ly_tai_lieu', 1),
('THUTHU', 'xem_thong_ke', 1);

-- --------------------------------------------------------

--
-- Table structure for table `yeuthich`
--

CREATE TABLE `yeuthich` (
  `MaND` varchar(15) NOT NULL,
  `MaTL` varchar(15) NOT NULL,
  `NgayThem` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `yeuthich`
--

INSERT INTO `yeuthich` (`MaND`, `MaTL`, `NgayThem`) VALUES
('ND001', 'TL08484A2EC8', '2026-10-12 12:40:48'),
('ND1790581637', 'TL1791448468', '2026-10-08 15:43:19'),
('ND1790581637', 'TL5681BDF6EC', '2026-10-12 14:03:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cau_hinh`
--
ALTER TABLE `cau_hinh`
  ADD PRIMARY KEY (`MaCH`),
  ADD UNIQUE KEY `Khoa` (`Khoa`);

--
-- Indexes for table `danh_muc`
--
ALTER TABLE `danh_muc`
  ADD PRIMARY KEY (`MaDM`),
  ADD KEY `fk_danhmuc_cha` (`MaDMCha`);

--
-- Indexes for table `lichsudoc`
--
ALTER TABLE `lichsudoc`
  ADD PRIMARY KEY (`MaLS`),
  ADD KEY `MaND` (`MaND`),
  ADD KEY `MaTL` (`MaTL`);

--
-- Indexes for table `loaitailieu`
--
ALTER TABLE `loaitailieu`
  ADD PRIMARY KEY (`MaLoai`);

--
-- Indexes for table `luot_truy_cap`
--
ALTER TABLE `luot_truy_cap`
  ADD PRIMARY KEY (`MaLog`),
  ADD KEY `idx_thoigian` (`ThoiGian`),
  ADD KEY `idx_mand` (`MaND`);

--
-- Indexes for table `namhoc`
--
ALTER TABLE `namhoc`
  ADD PRIMARY KEY (`MaNam`);

--
-- Indexes for table `nganh`
--
ALTER TABLE `nganh`
  ADD PRIMARY KEY (`MaNganh`),
  ADD KEY `idx_pb` (`MaPB`);

--
-- Indexes for table `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD PRIMARY KEY (`MaND`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `MaVaiTro` (`MaVaiTro`),
  ADD KEY `MaPB` (`MaPB`);

--
-- Indexes for table `nhatkyhoatdong`
--
ALTER TABLE `nhatkyhoatdong`
  ADD PRIMARY KEY (`MaLog`),
  ADD KEY `idx_thoigian` (`ThoiGian`),
  ADD KEY `idx_mand` (`MaND`);

--
-- Indexes for table `passwordresets`
--
ALTER TABLE `passwordresets`
  ADD PRIMARY KEY (`MaReset`),
  ADD UNIQUE KEY `Token` (`Token`),
  ADD KEY `idx_token` (`Token`),
  ADD KEY `idx_email` (`Email`);

--
-- Indexes for table `phienbanfile`
--
ALTER TABLE `phienbanfile`
  ADD PRIMARY KEY (`MaPhienBan`),
  ADD KEY `MaTL` (`MaTL`);

--
-- Indexes for table `phong_ban`
--
ALTER TABLE `phong_ban`
  ADD PRIMARY KEY (`MaPB`);

--
-- Indexes for table `quyen`
--
ALTER TABLE `quyen`
  ADD PRIMARY KEY (`MaQuyen`);

--
-- Indexes for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD PRIMARY KEY (`MaToken`),
  ADD UNIQUE KEY `uk_tokenhash` (`TokenHash`),
  ADD KEY `idx_mand` (`MaND`),
  ADD KEY `idx_hethan` (`HetHan`);

--
-- Indexes for table `tac_gia`
--
ALTER TABLE `tac_gia`
  ADD PRIMARY KEY (`MaTG`),
  ADD KEY `fk_tacgia_phongban` (`MaPB`);

--
-- Indexes for table `tailieutacgia`
--
ALTER TABLE `tailieutacgia`
  ADD PRIMARY KEY (`MaTL`,`MaTG`),
  ADD KEY `MaTG` (`MaTG`);

--
-- Indexes for table `tai_lieu`
--
ALTER TABLE `tai_lieu`
  ADD PRIMARY KEY (`MaTL`),
  ADD KEY `fk_tailieu_tacgia` (`MaTG`),
  ADD KEY `fk_tailieu_danhmuc` (`MaDM`),
  ADD KEY `idx_tailieu_namhoc` (`MaNam`);

--
-- Indexes for table `tukhoa`
--
ALTER TABLE `tukhoa`
  ADD PRIMARY KEY (`MaTK`);

--
-- Indexes for table `vaitro`
--
ALTER TABLE `vaitro`
  ADD PRIMARY KEY (`MaVaiTro`);

--
-- Indexes for table `vai_tro_quyen`
--
ALTER TABLE `vai_tro_quyen`
  ADD PRIMARY KEY (`MaVaiTro`,`MaQuyen`),
  ADD KEY `MaQuyen` (`MaQuyen`);

--
-- Indexes for table `yeuthich`
--
ALTER TABLE `yeuthich`
  ADD PRIMARY KEY (`MaND`,`MaTL`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cau_hinh`
--
ALTER TABLE `cau_hinh`
  MODIFY `MaCH` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=243;

--
-- AUTO_INCREMENT for table `lichsudoc`
--
ALTER TABLE `lichsudoc`
  MODIFY `MaLS` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `luot_truy_cap`
--
ALTER TABLE `luot_truy_cap`
  MODIFY `MaLog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `nhatkyhoatdong`
--
ALTER TABLE `nhatkyhoatdong`
  MODIFY `MaLog` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `passwordresets`
--
ALTER TABLE `passwordresets`
  MODIFY `MaReset` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `phienbanfile`
--
ALTER TABLE `phienbanfile`
  MODIFY `MaPhienBan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  MODIFY `MaToken` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `danh_muc`
--
ALTER TABLE `danh_muc`
  ADD CONSTRAINT `fk_danhmuc_cha` FOREIGN KEY (`MaDMCha`) REFERENCES `danh_muc` (`MaDM`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `nguoidung`
--
ALTER TABLE `nguoidung`
  ADD CONSTRAINT `nguoidung_ibfk_1` FOREIGN KEY (`MaVaiTro`) REFERENCES `vaitro` (`MaVaiTro`),
  ADD CONSTRAINT `nguoidung_ibfk_2` FOREIGN KEY (`MaPB`) REFERENCES `phong_ban` (`MaPB`);

--
-- Constraints for table `phienbanfile`
--
ALTER TABLE `phienbanfile`
  ADD CONSTRAINT `phienbanfile_ibfk_1` FOREIGN KEY (`MaTL`) REFERENCES `tai_lieu` (`MaTL`) ON DELETE CASCADE;

--
-- Constraints for table `remember_tokens`
--
ALTER TABLE `remember_tokens`
  ADD CONSTRAINT `fk_remember_nguoidung` FOREIGN KEY (`MaND`) REFERENCES `nguoidung` (`MaND`) ON DELETE CASCADE;

--
-- Constraints for table `tac_gia`
--
ALTER TABLE `tac_gia`
  ADD CONSTRAINT `fk_tacgia_phongban` FOREIGN KEY (`MaPB`) REFERENCES `phong_ban` (`MaPB`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tailieutacgia`
--
ALTER TABLE `tailieutacgia`
  ADD CONSTRAINT `tailieutacgia_ibfk_1` FOREIGN KEY (`MaTL`) REFERENCES `tai_lieu` (`MaTL`),
  ADD CONSTRAINT `tailieutacgia_ibfk_2` FOREIGN KEY (`MaTG`) REFERENCES `tac_gia` (`MaTG`);

--
-- Constraints for table `tai_lieu`
--
ALTER TABLE `tai_lieu`
  ADD CONSTRAINT `fk_tailieu_danhmuc` FOREIGN KEY (`MaDM`) REFERENCES `danh_muc` (`MaDM`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tailieu_namhoc` FOREIGN KEY (`MaNam`) REFERENCES `namhoc` (`MaNam`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tailieu_tacgia` FOREIGN KEY (`MaTG`) REFERENCES `tac_gia` (`MaTG`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `vai_tro_quyen`
--
ALTER TABLE `vai_tro_quyen`
  ADD CONSTRAINT `vai_tro_quyen_ibfk_1` FOREIGN KEY (`MaQuyen`) REFERENCES `quyen` (`MaQuyen`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
